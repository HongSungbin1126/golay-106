/-
SPDX-License-Identifier: CC-BY-4.0
AI-authored internal work. No human review is asserted.
This file verifies only the explicit witness0, not exhaustive classification.
-/
import WitnessChecks

set_option maxRecDepth 1000000
set_option maxHeartbeats 20000000

namespace Golay106.Witnesses

/-- All 105 positive-lag residuals of the explicit witness0 vanish modulo 32. -/
theorem witness0_all_positive_lags_mod32 :
    ∀ k : Fin 105, combined witness0 (k.val + 1) % 32 = 0 := by
  decide

/-- Existence of one literal binary length-106 modulo-32 witness only. -/
theorem explicit_mod32_witness_exists :
    ∃ p : LiteralPair,
      p.A.length = 106 ∧ p.B.length = 106 ∧
      BinaryList p.A ∧ BinaryList p.B ∧
      (∀ k : Fin 105, combined p (k.val + 1) % 32 = 0) := by
  exact ⟨witness0, witness0_lengths.1, witness0_lengths.2,
    witness0_binary.1, witness0_binary.2, witness0_all_positive_lags_mod32⟩

end Golay106.Witnesses
