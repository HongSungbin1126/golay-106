/-
SPDX-License-Identifier: CC-BY-4.0
AI-authored internal work. No human review is asserted.
Eight literal input pairs copied from the source JSON; no enumeration claim.
Only their binary alphabet, lengths, and lag-four residual are checked here.
-/
import TerminalArithmetic

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

namespace Golay106.Witnesses
open Golay106.Terminal

structure LiteralPair where
  A : List Int
  B : List Int

/-- Direct integer aperiodic correlation; getD is used only inside the overlap. -/
def aperiodic (a : List Int) (k : Nat) : Int :=
  ((List.range (a.length - k)).map
    (fun i => a.getD i 0 * a.getD (i + k) 0)).foldl (· + ·) 0

def combined (p : LiteralPair) (k : Nat) : Int :=
  aperiodic p.A k + aperiodic p.B k

abbrev BinaryList (a : List Int) : Prop :=
  a.all (fun x => x == 1 || x == -1) = true

/-- Source JSON row 0; q=4503599627370496, reduced assignment=0. -/
def witness0 : LiteralPair :=
  { A := [1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1],
    B := [1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1] }

theorem witness0_lengths :
    witness0.A.length = 106 ∧ witness0.B.length = 106 := by
  decide

theorem witness0_binary :
    BinaryList witness0.A ∧ BinaryList witness0.B := by
  decide

theorem witness0_lag4 : combined witness0 4 = -160 := by
  decide

theorem witness0_not_exact : ¬ ExactResidual (combined witness0) := by
  exact terminal_obstruction_not_exact (combined witness0)
    (Or.inr (Or.inl ⟨4, by decide, witness0_lag4⟩))

/-- Source JSON row 1; q=4503599627370496, reduced assignment=1. -/
def witness1 : LiteralPair :=
  { A := [1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1],
    B := [1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1] }

theorem witness1_lengths :
    witness1.A.length = 106 ∧ witness1.B.length = 106 := by
  decide

theorem witness1_binary :
    BinaryList witness1.A ∧ BinaryList witness1.B := by
  decide

theorem witness1_lag4 : combined witness1 4 = -160 := by
  decide

theorem witness1_not_exact : ¬ ExactResidual (combined witness1) := by
  exact terminal_obstruction_not_exact (combined witness1)
    (Or.inr (Or.inl ⟨4, by decide, witness1_lag4⟩))

/-- Source JSON row 2; q=4503599627370496, reduced assignment=2. -/
def witness2 : LiteralPair :=
  { A := [1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, -1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1],
    B := [1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1] }

theorem witness2_lengths :
    witness2.A.length = 106 ∧ witness2.B.length = 106 := by
  decide

theorem witness2_binary :
    BinaryList witness2.A ∧ BinaryList witness2.B := by
  decide

theorem witness2_lag4 : combined witness2 4 = -160 := by
  decide

theorem witness2_not_exact : ¬ ExactResidual (combined witness2) := by
  exact terminal_obstruction_not_exact (combined witness2)
    (Or.inr (Or.inl ⟨4, by decide, witness2_lag4⟩))

/-- Source JSON row 3; q=4503599627370496, reduced assignment=3. -/
def witness3 : LiteralPair :=
  { A := [1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1],
    B := [1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1] }

theorem witness3_lengths :
    witness3.A.length = 106 ∧ witness3.B.length = 106 := by
  decide

theorem witness3_binary :
    BinaryList witness3.A ∧ BinaryList witness3.B := by
  decide

theorem witness3_lag4 : combined witness3 4 = -160 := by
  decide

theorem witness3_not_exact : ¬ ExactResidual (combined witness3) := by
  exact terminal_obstruction_not_exact (combined witness3)
    (Or.inr (Or.inl ⟨4, by decide, witness3_lag4⟩))

/-- Source JSON row 4; q=2401919801264264, reduced assignment=0. -/
def witness4 : LiteralPair :=
  { A := [1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1],
    B := [1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1] }

theorem witness4_lengths :
    witness4.A.length = 106 ∧ witness4.B.length = 106 := by
  decide

theorem witness4_binary :
    BinaryList witness4.A ∧ BinaryList witness4.B := by
  decide

theorem witness4_lag4 : combined witness4 4 = -160 := by
  decide

theorem witness4_not_exact : ¬ ExactResidual (combined witness4) := by
  exact terminal_obstruction_not_exact (combined witness4)
    (Or.inr (Or.inl ⟨4, by decide, witness4_lag4⟩))

/-- Source JSON row 5; q=2401919801264264, reduced assignment=1. -/
def witness5 : LiteralPair :=
  { A := [1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1],
    B := [1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1] }

theorem witness5_lengths :
    witness5.A.length = 106 ∧ witness5.B.length = 106 := by
  decide

theorem witness5_binary :
    BinaryList witness5.A ∧ BinaryList witness5.B := by
  decide

theorem witness5_lag4 : combined witness5 4 = -160 := by
  decide

theorem witness5_not_exact : ¬ ExactResidual (combined witness5) := by
  exact terminal_obstruction_not_exact (combined witness5)
    (Or.inr (Or.inl ⟨4, by decide, witness5_lag4⟩))

/-- Source JSON row 6; q=2401919801264264, reduced assignment=2. -/
def witness6 : LiteralPair :=
  { A := [1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, -1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1],
    B := [1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1] }

theorem witness6_lengths :
    witness6.A.length = 106 ∧ witness6.B.length = 106 := by
  decide

theorem witness6_binary :
    BinaryList witness6.A ∧ BinaryList witness6.B := by
  decide

theorem witness6_lag4 : combined witness6 4 = -160 := by
  decide

theorem witness6_not_exact : ¬ ExactResidual (combined witness6) := by
  exact terminal_obstruction_not_exact (combined witness6)
    (Or.inr (Or.inl ⟨4, by decide, witness6_lag4⟩))

/-- Source JSON row 7; q=2401919801264264, reduced assignment=3. -/
def witness7 : LiteralPair :=
  { A := [1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1],
    B := [1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, -1] }

theorem witness7_lengths :
    witness7.A.length = 106 ∧ witness7.B.length = 106 := by
  decide

theorem witness7_binary :
    BinaryList witness7.A ∧ BinaryList witness7.B := by
  decide

theorem witness7_lag4 : combined witness7 4 = -160 := by
  decide

theorem witness7_not_exact : ¬ ExactResidual (combined witness7) := by
  exact terminal_obstruction_not_exact (combined witness7)
    (Or.inr (Or.inl ⟨4, by decide, witness7_lag4⟩))

end Golay106.Witnesses
