/-
SPDX-License-Identifier: CC-BY-4.0
AI-authored internal work. No human review is asserted.
This file proves terminal arithmetic, NOT the exhaustive enumeration or its
connection to the actual length-106 candidate space.
-/
import Lean.Elab.Tactic.Omega

namespace Golay106.Terminal

/-- Integer residuals indexed by their positive aperiodic lag. -/
abbrev Residual := Nat → Int

/-- The only lags constrained by the length-106 residual specification. -/
abbrev ValidLag (k : Nat) : Prop := 1 ≤ k ∧ k ≤ 105

/-- A specification only: no sequence-to-residual reduction is assumed here. -/
def ExactResidual (r : Residual) : Prop :=
  ∀ k, ValidLag k → r k = 0

/-- Divisibility at each constrained lag; this does not assert exact zero. -/
def DivisibleAtEveryLag (m : Int) (r : Residual) : Prop :=
  ∀ k, ValidLag k → m ∣ r k

theorem positive_sixteen_not_divisible32 : ¬ (32 : Int) ∣ 16 := by
  decide

theorem negative_sixteen_not_divisible32 : ¬ (32 : Int) ∣ -16 := by
  decide

theorem pm_sixteen_not_divisible32 (r : Int)
    (residual_is_pm_sixteen : r = 16 ∨ r = -16) : ¬ (32 : Int) ∣ r := by
  rcases residual_is_pm_sixteen with rfl | rfl
  · exact positive_sixteen_not_divisible32
  · exact negative_sixteen_not_divisible32

theorem signed_sixteen_not_divisible32 (s : Int)
    (sign_is_unit : s = 1 ∨ s = -1) : ¬ (32 : Int) ∣ 16 * s := by
  rcases sign_is_unit with rfl | rfl <;> decide

theorem negative_signed_sixteen_not_divisible32 (s : Int)
    (sign_is_unit : s = 1 ∨ s = -1) : ¬ (32 : Int) ∣ -16 * s := by
  rcases sign_is_unit with rfl | rfl <;> decide

theorem negative160_not_divisible64 : ¬ (64 : Int) ∣ -160 := by
  decide

theorem negative160_remainder64 : (-160 : Int) % 64 = 32 := by
  decide

/-- Congruence means Lean's integer Euclidean remainder, with positive modulus. -/
theorem difference_congruence_obstructs_divisible32 (r24 r28 : Int)
    (difference_remainder_is_sixteen : (r24 - r28) % 32 = 16) :
    ¬ ((32 : Int) ∣ r24 ∧ (32 : Int) ∣ r28) := by
  intro both_divisible
  rcases both_divisible with ⟨⟨a, ha⟩, ⟨b, hb⟩⟩
  omega

theorem divisible32_of_divisible64 (r : Int)
    (divisible64 : (64 : Int) ∣ r) : (32 : Int) ∣ r := by
  rcases divisible64 with ⟨q, hq⟩
  exact ⟨2 * q, by omega⟩

theorem exact_implies_divisible_at_every_lag (m : Int) (r : Residual)
    (exact_residual : ExactResidual r) : DivisibleAtEveryLag m r := by
  intro k valid_lag
  rw [exact_residual k valid_lag]
  exact ⟨0, by simp⟩

theorem exact_implies_remainder64_zero (r : Residual)
    (exact_residual : ExactResidual r) :
    ∀ k, ValidLag k → r k % 64 = 0 := by
  intro k valid_lag
  rw [exact_residual k valid_lag]
  decide

/-- A supplied terminal case, NOT a verified classification of actual residuals. -/
def TerminalObstruction (r : Residual) : Prop :=
  (∃ k, ValidLag k ∧ (r k = 16 ∨ r k = -16)) ∨
  (∃ k, ValidLag k ∧ r k = -160) ∨
  ((r 24 - r 28) % 32 = 16)

theorem terminal_obstruction_not_mod64 (r : Residual)
    (supplied_terminal_case : TerminalObstruction r) :
    ¬ DivisibleAtEveryLag 64 r := by
  intro all_divisible64
  rcases supplied_terminal_case with h16 | h160 | hdiff
  · rcases h16 with ⟨k, valid_lag, residual_is_pm_sixteen⟩
    exact pm_sixteen_not_divisible32 (r k) residual_is_pm_sixteen
      (divisible32_of_divisible64 (r k) (all_divisible64 k valid_lag))
  · rcases h160 with ⟨k, valid_lag, residual_is_negative160⟩
    have h64 := all_divisible64 k valid_lag
    rw [residual_is_negative160] at h64
    exact negative160_not_divisible64 h64
  · exact difference_congruence_obstructs_divisible32 (r 24) (r 28) hdiff
      ⟨divisible32_of_divisible64 (r 24) (all_divisible64 24 (by decide)),
       divisible32_of_divisible64 (r 28) (all_divisible64 28 (by decide))⟩

theorem terminal_obstruction_not_exact (r : Residual)
    (supplied_terminal_case : TerminalObstruction r) : ¬ ExactResidual r := by
  intro exact_residual
  exact terminal_obstruction_not_mod64 r supplied_terminal_case
    (exact_implies_divisible_at_every_lag 64 r exact_residual)

/--
Conditional interface. ALL coverage and terminal-classification obligations are
explicit hypotheses. Neither is supplied for actual Golay candidates here.
-/
theorem conditional_no_exact_residual
    (Candidate : Type) (admissible : Candidate → Prop)
    (residual : Candidate → Residual)
    (exhaustive_terminal_reduction :
      ∀ c, admissible c → TerminalObstruction (residual c)) :
    ¬ ∃ c, admissible c ∧ ExactResidual (residual c) := by
  rintro ⟨c, candidate_is_admissible, candidate_is_exact⟩
  exact terminal_obstruction_not_exact (residual c)
    (exhaustive_terminal_reduction c candidate_is_admissible) candidate_is_exact

/--
An abstract target predicate needs TWO further explicit hypotheses: coverage of
targets by admissible candidates, and soundness of the supplied residual map.
No actual binary-sequence target predicate is instantiated in this file.
-/
theorem conditional_no_target
    (Candidate : Type) (admissible isTarget : Candidate → Prop)
    (residual : Candidate → Residual)
    (target_coverage : ∀ c, isTarget c → admissible c)
    (target_residual_soundness : ∀ c, isTarget c → ExactResidual (residual c))
    (exhaustive_terminal_reduction :
      ∀ c, admissible c → TerminalObstruction (residual c)) :
    ¬ ∃ c, isTarget c := by
  rintro ⟨c, target_c⟩
  exact conditional_no_exact_residual Candidate admissible residual
    exhaustive_terminal_reduction
    ⟨c, target_coverage c target_c, target_residual_soundness c target_c⟩

/-- Numeric identities only: not cardinality or orbit-normalization proofs. -/
theorem supplied_dimension_sum :
    (4 : Nat) * 2 ^ 4 + 2 * 2 ^ 20 + 2 * 2 ^ 26 = 136314944 := by
  decide

theorem supplied_dimension_sum_times_eight :
    (8 : Nat) * (4 * 2 ^ 4 + 2 * 2 ^ 20 + 2 * 2 ^ 26) = 1090519552 := by
  decide

theorem eight_times_eight : (8 : Nat) * 8 = 64 := by
  decide

theorem supplied_mod4_factor_eight : (8 : Nat) * 2 ^ 156 = 2 ^ 159 := by
  decide

theorem supplied_mod8_factor_eight :
    (8 : Nat) * (102 * 2 ^ 52) = 102 * 2 ^ 55 := by
  decide

end Golay106.Terminal
