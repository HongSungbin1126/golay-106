# License

SPDX-License-Identifier: CC-BY-4.0

The newly authored bounded formalization and documentation in this directory are made available under the Creative Commons Attribution 4.0 International license, as chosen by the user.

License: https://creativecommons.org/licenses/by/4.0/
Legal terms: https://creativecommons.org/licenses/by/4.0/legalcode

Suggested attribution: "Bounded Lean 4 terminal arithmetic for the Golay length-106 investigation, AI-authored internal work, 2026-11-05. CC BY 4.0."

This notice makes no claim of human authorship or human review. External Lean binaries, upstream source materials, and their licenses are not relicensed by this notice. Mathematical facts and copied numeric witness data are identified as provenance, not as a claim of original mathematical discovery. No public upload or publication is performed here.
