#!/bin/bash
# SPDX-License-Identifier: CC-BY-4.0
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
LEAN="${1:-${LEAN_BIN:-}}"
if [[ -z "$LEAN" ]]; then
  echo 'Usage: bash verify.sh /absolute/path/to/lean' >&2
  exit 2
fi
cd "$DIR"
export LEAN_PATH="$DIR"
{
  "$LEAN" --version
  "$LEAN" -o TerminalArithmetic.olean TerminalArithmetic.lean
  "$LEAN" -o WitnessChecks.olean WitnessChecks.lean
  "$LEAN" -o FullWitness0.olean FullWitness0.lean
  "$LEAN" Audit.lean
  printf '\nVERIFICATION COMPLETE: all requested Lean modules accepted.\n'
} 2>&1 | tee verification.log
