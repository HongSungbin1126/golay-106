# Exact fiber inverse portability diagnosis

## Confirmed root cause

Frozen source line 69 calls unqualified remainder(a,f), where both arguments are uint64_t. Apple libc++ exposes a global arithmetic-template mathematical remainder overload. That overload has exact argument matches, unlike the intended custom remainder(unsigned __int128,uint64_t), which requires a conversion of the first argument. Therefore the mathematical overload wins and returns double. Assigning a negative double result to unsigned __int128 is out-of-range floating-to-integral conversion, which is undefined behavior, not unsigned modular integer conversion.

This is an overload/header-environment portability defect, followed by UB. It occurs at both -O0 and -O3, so is not evidence of an optimization-only miscompile. No reverse, degree, or carryless multiplication error is needed to explain the observed half-domain loss.

## Minimal failing input

p=13, h=1 gives H=4097 and J=8191.

- Decltype(remainder(U(4097),U(8191))) is double, established by static_assert.
- This overload computes -4094 (ordinary IEEE remainder).
- Decltype(remainder(W(4097),U(8191))) is uint64_t. This computes polynomial remainder 4094.
- Original inverse returns false.
- Explicit-W corrected inverse returns true and inverse=2731.
- Independent GF(2) multiplication-matrix inversion also returns inverse=2731.

At p=13, every odd h has H above J/2 and therefore generates a negative ordinary remainder. Nonzero even h stays below J/2. This explains the 32 false rejections plus the genuinely nonunit zero input exactly. At p=53 the same h-parity mechanism applies.

## Correction

Minimal: change only line 69 initializer from remainder(a,f) to remainder(W(a),f).

Preferred durable correction: rename the custom function and all its call sites to a unique name such as gf2_remainder or poly_remainder, so unqualified lookup cannot select numerical remainder overloads in another standard-library environment. No original/evidence/manuscript file was edited here.

## Independent bounded validation

The reference constructs the multiplication-by-H matrix over GF(2), reduces columns by an independent bitwise polynomial remainder, then inverts it by Gaussian elimination. It uses no Euclidean inversion, no __int128, no builtin degree, and no builtin reverse.

Both O0 and O3 corrected-inverse checks:
- p=13, all 64 H inputs: 63 units, 1 nonunit, 0 mismatches versus independent matrix inversion.
- p=53, first 128 H inputs: 127 units, 1 nonunit, 0 mismatches.

No full orientation rerun was performed by this agent. This is not independent verification of all archived orientations.

## Evidence in this directory

- overload.cpp, overload.log, overload_O0.log: exact type assertions, minimal failure and correction, independent inverse comparison.
- overload.ast.txt: original line 69 has FloatingToIntegral from double returned by remainder(unsigned long long,unsigned long long), while corrected initializer calls U(*)(W,U).
- compare_ubsan.stderr: UBSan reports '-4094 is outside the range of representable values of type unsigned __int128' at original line 69.
- compare_O0.log, compare_O3.log: 32 mismatches, all odd h, at p=13.
- include_tree.log: source <algorithm> -> libc++ <atomic> -> <cmath> -> <math.h> exposes the arithmetic remainder overload.
- fixed_sanitized.cpp/log/stderr: corrected inverse plus independent checks exits 0 under -O3 -fsanitize=undefined -fno-sanitize-recover=undefined; sanitizer stderr is empty.
- original.sha256: frozen original remains 3154f3816e12d8476df26a8e736fe26cbbd520e74238f842e853b9bfc379163f.

Archived Ubuntu GCC overload selection was not separately inspected by this agent. The local source hash is unchanged, but identical source hashes do not imply identical overload sets across standard-library implementations.
