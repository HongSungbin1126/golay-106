// Four disjoint full-domain quarters. Exact result audit is a separate script.
// CC BY 4.0. Does not infer mathematical correctness from process exit alone.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const {spawn} = require('child_process');
const [binaryArg, sourceArg, outArg] = process.argv.slice(2);
if (!binaryArg || !sourceArg || !outArg) throw Error('Usage: node run_fresh_quarters.js BINARY SOURCE NEW_OUTPUT_DIR');
const binary = path.resolve(binaryArg), source = path.resolve(sourceArg), out = path.resolve(outArg);
if (fs.existsSync(out)) throw Error('Choose a new output directory; preserve old evidence');
fs.mkdirSync(out, {recursive:true});
const digest = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const sh = digest(source), bh = digest(binary), started = Date.now();
let children = [];
const timeout = setTimeout(() => {for (const c of children) c.kill('SIGTERM'); console.error('Wall budget exceeded: NO CONCLUSION'); process.exitCode = 1;}, 1200000);
const halt = () => {for (const c of children) c.kill('SIGTERM');};
process.on('SIGINT',halt); process.on('SIGTERM',halt);
fs.writeFileSync(out+'/controller.json', JSON.stringify({format:'four_disjoint_native_quarters_v1',source_filename:path.basename(source),source_sha256:sh,binary_filename:path.basename(binary),binary_sha256:bh,workers:4,cpu_limit_per_worker_seconds:1000,wall_limit_seconds:1200,ranges:[0,1,2,3].map(i=>[i*16777216,(i+1)*16777216]),platform:process.platform,arch:process.arch,started_utc:new Date().toISOString()},null,2));
Promise.all([0,1,2,3].map(i => new Promise((resolve,reject) => {
    const log = fs.openSync(out+'/part'+i+'.stderr.log','w');
    const args = ['--p','53','--seconds','1000','--h-start',String(i*16777216),'--h-limit','16777216','--output',out+'/part'+i+'.json','--orientations',out+'/part'+i+'.jsonl','--source-sha256',sh];
    const c = spawn(binary,args,{stdio:['ignore','pipe',log]}); children.push(c); let stdout='';
    c.stdout.on('data',b=>stdout+=b); c.on('error',reject);
    c.on('close',code=>{fs.closeSync(log);fs.writeFileSync(out+'/part'+i+'.stdout.log',stdout); console.log('Native quarter '+i+' exit '+code+': '+stdout.trim()); if(code!==0) return reject(Error('Native failure, no accepted conclusion'));const r=JSON.parse(fs.readFileSync(out+'/part'+i+'.json'));if(r.status!=='COMPLETE_H_PARTITION'||r.H_completed!==16777216)return reject(Error('Incomplete native quarter'));resolve(r);});
}))).then(reports=>{clearTimeout(timeout);const receipt={status:'FOUR_NATIVE_QUARTERS_COMPLETED_AUDIT_STILL_REQUIRED',covered_H_reported:67108864,source_sha256:sh,binary_sha256:bh,cpu_seconds_reported:reports.reduce((n,r)=>n+r.cpu_seconds,0),wall_seconds:(Date.now()-started)/1000};fs.writeFileSync(out+'/controller_complete.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));}).catch(e=>{clearTimeout(timeout);halt();console.error(e);process.exitCode=1;});
