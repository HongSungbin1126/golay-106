#define main archived_main
#include "exact_orientation_fibers_arm.cpp"
#undef main
int main(){U s=0x123456789abcdefULL;for(unsigned i=0;i<1000000;i++){s^=s<<13;s^=s>>7;s^=s<<17;U a=s;s^=s<<13;s^=s>>7;s^=s<<17;U b=s;if(multiply(a,b)!=multiply_portable(a,b))return 2;}for(unsigned p:{5u,13u,53u}){U count=U(1)<<((p-1)/2),lim=std::min<U>(count,4096),J=(U(1)<<p)-1;U failures=0;for(U h=0;h<lim;h++){U H=h^reverse_p(h,p),v;bool ok=inverse(H,J,v);if(!ok)failures++;else if(poly_remainder(multiply(H,v),J)!=1)return 3;}if(failures!=1)return 4;}std::cout<<"PASS 1000000 PMULL/portable products; inverse regressions p5,p13,p53; exactly H0 nonunit in tested field domains\n";}
