#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <ctime>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <sys/resource.h>
#include <utility>
#include <vector>
#if defined(__x86_64__)
#include <immintrin.h>
#endif
#if defined(__aarch64__) && defined(__ARM_FEATURE_CRYPTO)
#include <arm_neon.h>
#endif

// Complete first-parity orientation search for n=2p, p odd.
// This is NOT a full Golay solver: subsequent sign/integer equations remain.
// Port of algebra_orientation_fibers.py: folded polynomial inverse followed by
// exact ElimLin-style projection and exhaustive branching if projection stalls.
using U=std::uint64_t;
using W=unsigned __int128;
using Direction=std::pair<U,U>;

static unsigned degree(W a) {
    assert(a);
    U hi=U(a>>64);
    return hi ? 127-__builtin_clzll(hi) : 63-__builtin_clzll(U(a));
}
static U reverse64(U a) {
    a=((a&0x5555555555555555ULL)<<1)|((a>>1)&0x5555555555555555ULL);
    a=((a&0x3333333333333333ULL)<<2)|((a>>2)&0x3333333333333333ULL);
    a=((a&0x0f0f0f0f0f0f0f0fULL)<<4)|((a>>4)&0x0f0f0f0f0f0f0f0fULL);
    return __builtin_bswap64(a);
}
static U reverse_p(U a,unsigned p) {return reverse64(a)>>(64-p);}
static W reverse_w(W a,unsigned width) {
    return ((W(reverse64(U(a)))<<64)|reverse64(U(a>>64)))>>(128-width);
}
static W multiply_portable(U a,U b) {
    W out=0;
    while(b) {unsigned i=__builtin_ctzll(b);out^=W(a)<<i;b&=b-1;}
    return out;
}
#if defined(__x86_64__)
__attribute__((target("pclmul,sse2")))
static W multiply_pclmul(U a,U b) {
    __m128i x=_mm_set_epi64x(0,a),y=_mm_set_epi64x(0,b);
    __m128i r=_mm_clmulepi64_si128(x,y,0);
    U out[2];_mm_storeu_si128(reinterpret_cast<__m128i*>(out),r);
    return W(out[0])|(W(out[1])<<64);
}
#endif
static W multiply(U a,U b) {
#if defined(__aarch64__) && defined(__ARM_FEATURE_CRYPTO)
    poly128_t product=vmull_p64(poly64_t(a),poly64_t(b));
    uint64x2_t words=vreinterpretq_u64_p128(product);
    return W(vgetq_lane_u64(words,0)) | (W(vgetq_lane_u64(words,1))<<64);
#endif
#if defined(__x86_64__)
    static bool accelerated=__builtin_cpu_supports("pclmul");
    if(accelerated)return multiply_pclmul(a,b);
#endif
    return multiply_portable(a,b);
}
static U poly_remainder(W a,U f) {
    unsigned d=degree(f);
    while(a && degree(a)>=d)a^=W(f)<<(degree(a)-d);
    return U(a);
}
static bool inverse(U a,U f,U& inv) {
    W u=poly_remainder(a,f),v=f,x=1,y=0;
    while(u!=1) {
        if(!u)return false;
        int j=int(degree(u))-int(degree(v));
        if(j<0){std::swap(u,v);std::swap(x,y);j=-j;}
        u^=v<<j;x^=y<<j;
    }
    inv=poly_remainder(x,f);return true;
}
static W parity_direct(U q,U t,unsigned p) {
    W out=0;
    for(unsigned i=0;i<p;++i)for(unsigned j=i+1;j<p;++j) {
        if(((t>>i)^(t>>j))&1)continue;
        unsigned k=(((q>>i)^(q>>j))&1) ? 2*p-1-i-j : j-i;
        out^=W(1)<<(k-1);
    }
    return out;
}
static W parity_fast(U q,U t,unsigned p) {
    U J=(U(1)<<p)-1;
    U g00=(~q)&(~t)&J,g10=q&(~t)&J;
    U g01=(~q)&t&J,g11=q&t&J;
    W cross=multiply(g00,g10)^multiply(g01,g11);
    U u=q|t;
    W differences=multiply(J,u^reverse_p(u,p))
                  ^multiply(q,reverse_p(t,p))^multiply(t,reverse_p(q,p));
    // Coefficient p-1+k is the parity contribution at difference lag k.
    // The remaining constant is p-k modulo 2; p is odd in this solver.
    U baseline=((U(1)<<(p-1))-1)&0xAAAAAAAAAAAAAAAAULL;
    return reverse_w(cross,2*p-1)^(differences>>p)^baseline;
}
struct Span {
    std::array<W,128> pivot{};
    std::vector<unsigned> ordered;
    void add(W c) {
        while(c) {
            unsigned j=degree(c);
            if(pivot[j])c^=pivot[j];
            else {pivot[j]=c;return;}
        }
    }
    void finish(){for(int j=127;j>=0;--j)if(pivot[j])ordered.push_back(unsigned(j));}
    W reduce(W c)const{for(unsigned j:ordered)if((c>>j)&1)c^=pivot[j];return c;}
};
struct Preimage {bool consistent=true;U particular=0;std::vector<U> kernel;};
static Preimage affine_preimage(const std::vector<W>& columns,W target) {
    std::array<W,128> pivot{};
    std::array<U,128> combination{};
    Preimage out;
    for(unsigned i=0;i<columns.size();++i) {
        W c=columns[i];U combo=U(1)<<i;
        while(c) {
            unsigned j=degree(c);
            if(pivot[j]){c^=pivot[j];combo^=combination[j];}
            else {pivot[j]=c;combination[j]=combo;break;}
        }
        if(!c)out.kernel.push_back(combo);
    }
    while(target) {
        unsigned j=degree(target);
        if(!pivot[j]){out.consistent=false;return out;}
        target^=pivot[j];out.particular^=combination[j];
    }
    return out;
}
static Direction combine(U mask,const std::vector<Direction>& dirs) {
    Direction out{0,0};
    while(mask) {
        unsigned i=__builtin_ctzll(mask);
        out.first^=dirs[i].first;out.second^=dirs[i].second;mask&=mask-1;
    }
    return out;
}
struct Timeout {};
class Solver {
public:
    unsigned p;
    double seconds;
    std::clock_t start=std::clock();
    std::map<std::string,U> stats,stage_hist;
    std::vector<Direction> initial_directions,solutions;
    Span initial_quadratic_span;
    explicit Solver(unsigned p_,double seconds_):p(p_),seconds(seconds_) {}
    void initialize() {
        unsigned m=(p-1)/2;
        std::vector<U> sym;
        for(unsigned i=1;i<m;++i)sym.push_back((U(1)<<i)^(U(1)<<(p-1-i)));
        sym.push_back(U(1)<<m);
        for(U v:sym)initial_directions.push_back({v,0});
        for(U v:sym)initial_directions.push_back({0,v});
        W c=evaluate(0,0);
        std::vector<W> lin;
        for(Direction d:initial_directions)lin.push_back(evaluate(d.first,d.second)^c);
        for(unsigned i=0;i<lin.size();++i)for(unsigned j=0;j<i;++j) {
            Direction a=initial_directions[i],b=initial_directions[j];
            initial_quadratic_span.add(evaluate(a.first^b.first,a.second^b.second)^lin[i]^lin[j]^c);
        }
        initial_quadratic_span.finish();
    }
    double cpu()const{return double(std::clock()-start)/CLOCKS_PER_SEC;}
    W evaluate(U q,U t) {
        if((++stats["parity_evaluations"]&1023)==0 && cpu()>=seconds)throw Timeout{};
        return parity_fast(q,t,p);
    }
    void solve_space(Direction base,std::vector<Direction> dirs,bool initial=false) {
        ++stats["affine_nodes"];
        while(true) {
            U q=base.first,t=base.second;
            W c=evaluate(q,t);
            unsigned d=unsigned(dirs.size());
            if(!d) {
                if(!c){++stats["solutions"];solutions.push_back(base);}
                return;
            }
            std::vector<W> linear;
            for(Direction a:dirs)linear.push_back(evaluate(q^a.first,t^a.second)^c);
            Span quadr;
            if(initial)quadr=initial_quadratic_span;
            else {
                for(unsigned i=0;i<d;++i)for(unsigned j=0;j<i;++j) {
                    quadr.add(evaluate(q^dirs[i].first^dirs[j].first,
                                       t^dirs[i].second^dirs[j].second)^linear[i]^linear[j]^c);
                }
                quadr.finish();
            }
            initial=false;
            std::vector<W> projected;
            for(W col:linear)projected.push_back(quadr.reduce(col));
            Preimage pre=affine_preimage(projected,quadr.reduce(c));
            std::string stage=std::to_string(d)+"/"+std::to_string(quadr.ordered.size())+"/";
            if(!pre.consistent) {
                ++stats["linear_contradictions"];++stage_hist[stage+"INCONSISTENT"];return;
            }
            ++stage_hist[stage+std::to_string(pre.kernel.size())];
            if(pre.kernel.size()<d) {
                Direction offset=combine(pre.particular,dirs);
                base={q^offset.first,t^offset.second};
                std::vector<Direction> next;
                for(U v:pre.kernel)next.push_back(combine(v,dirs));
                dirs=std::move(next);++stats["affine_reductions"];continue;
            }
            if(quadr.ordered.empty()) {
                assert(c==0);
                for(W col:linear)assert(col==0);
                ++stats["free_affine_solution_spaces"];
                for(U mask=0;mask<(U(1)<<d);++mask) {
                    Direction off=combine(mask,dirs),sol{q^off.first,t^off.second};
                    W residual=evaluate(sol.first,sol.second);
                    if(residual)throw std::runtime_error("free affine space failed exact parity");
                    ++stats["solutions"];solutions.push_back(sol);
                }
                return;
            }
            ++stats["branch_nodes"];
            Direction direction=dirs.back();dirs.pop_back();
            solve_space(base,dirs);
            solve_space({q^direction.first,t^direction.second},dirs);
            return;
        }
    }
    void solve_h(U h) {
        solutions.clear();++stats["H_examined"];
        unsigned m=(p-1)/2;
        U H=h^reverse_p(h,p),J=(U(1)<<p)-1,inv;
        if(!inverse(H,J,inv)){++stats["nonunit_H"];return;}
        ++stats["unit_H"];
        U K=poly_remainder(W(H)^(W(inv)<<(p-1)),J);
        if((K>>m)&1)K^=J;
        assert(reverse_p(K,p)==K && !((K>>m)&1));
        assert(poly_remainder(multiply(H,H^K)<<1,J)==1);
        U low=(U(1)<<m)-1;
        solve_space({H^(H&low),K^(K&low)},initial_directions,true);
        for(Direction a:solutions) {
            assert(!(a.first&1) && !(a.second&1));
            assert((a.first^reverse_p(a.first,p))==H);
            assert((a.second^reverse_p(a.second,p))==K);
            assert(parity_direct(a.first,a.second,p)==0);
        }
    }
};
static void write_map(std::ostream& out,const std::map<std::string,U>& m) {
    out<<"{";bool first=true;
    for(const auto& e:m){if(!first)out<<",";first=false;out<<"\""<<e.first<<"\":"<<e.second;}
    out<<"}";
}
int main(int argc,char**argv) {
    unsigned p=0;double seconds=60;U start=0,limit=0;
    std::string output,orientations,source_hash;
    for(int i=1;i<argc;++i) {
        std::string arg=argv[i];
        if(i+1>=argc){std::cerr<<"missing value\n";return 2;}
        if(arg=="--p")p=std::stoul(argv[++i]);
        else if(arg=="--seconds")seconds=std::stod(argv[++i]);
        else if(arg=="--h-start")start=std::stoull(argv[++i]);
        else if(arg=="--h-limit")limit=std::stoull(argv[++i]);
        else if(arg=="--output")output=argv[++i];
        else if(arg=="--orientations")orientations=argv[++i];
        else if(arg=="--source-sha256")source_hash=argv[++i];
        else{std::cerr<<"unknown argument\n";return 2;}
    }
    if(p<3 || p>63 || !(p&1) || seconds<=0 || output.empty()) {
        std::cerr<<"requires odd 3<=p<=63, positive seconds, --output\n";return 2;
    }
    U total=U(1)<<((p-1)/2);
    if(start>=total){std::cerr<<"h-start out of range\n";return 2;}
    U end=limit ? start+std::min(limit,total-start) : total;
    auto wall_start=std::chrono::steady_clock::now();
    std::ofstream orient;
    if(!orientations.empty()) {
        orient.open(orientations);if(!orient){std::cerr<<"cannot write orientations\n";return 2;}
        orient<<"{\"record_type\":\"header\",\"format\":\"exact_fiber_orientations_v1\",\"n\":"<<2*p
              <<",\"h_start\":"<<start<<",\"h_end_exclusive\":"<<end
              <<",\"source_sha256\":\""<<source_hash<<"\"}\n";
    }
    Solver solver(p,seconds);
    U completed=0;
    bool timeout=false;
    try {
        solver.initialize();
        for(U h=start;h<end;++h) {
            solver.solve_h(h);
            if(!orientations.empty())for(Direction a:solver.solutions)orient<<"{\"record_type\":\"orientation\",\"n\":"<<2*p
                <<",\"h\":"<<h<<",\"q_bits_mask\":"<<a.first<<",\"t_bits_mask\":"<<a.second<<"}\n";
            ++completed;
            if(!(completed&4095)) {
                std::cerr<<"{\"H_completed\":"<<completed<<",\"cpu_seconds\":"<<solver.cpu()
                         <<",\"orientations\":"<<solver.stats["solutions"]<<"}\n";
                if(!orientations.empty()){orient.flush();if(!orient)throw std::runtime_error("orientation write failed");}
            }
        }
    } catch(Timeout&) {timeout=true;}
    std::string status=timeout ? "TIMEOUT" : ((start==0 && end==total) ? "COMPLETE_H_DOMAIN" : "COMPLETE_H_PARTITION");
    if(!orientations.empty())orient<<"{\"record_type\":\"footer\",\"status\":\""<<status<<"\",\"H_completed\":"<<completed<<"}\n";
    if(!orientations.empty()){orient.close();if(!orient){std::cerr<<"orientation output failure\n";return 3;}}
    struct rusage ru{};getrusage(RUSAGE_SELF,&ru);
    std::ofstream out(output);
    if(!out){std::cerr<<"report open failure\n";return 3;}
    out<<"{\n\"solver\":\"folded_inverse_ElimLin_v2\",\n\"scope\":\"first quad parity system only; no original Golay existence conclusion\",\n"
       <<"\"certification\":\"SOLVER_REPORT_NOT_INDEPENDENTLY_CERTIFIED\",\n"
       <<"\"status\":\""<<status<<"\",\n\"p\":"<<p<<",\n\"n\":"<<2*p
       <<",\n\"total_H_domain\":"<<total<<",\n\"h_start\":"<<start<<",\n\"h_end_exclusive\":"<<end
       <<",\n\"H_completed\":"<<completed<<",\n\"statistics\":";
    write_map(out,solver.stats);out<<",\n\"stage_histogram_dim_quadrank_nextdim\":";write_map(out,solver.stage_hist);
    out<<",\n\"cpu_seconds\":"<<solver.cpu()<<",\n\"wall_seconds\":"
       <<std::chrono::duration<double>(std::chrono::steady_clock::now()-wall_start).count()
       <<",\n\"peak_rss_kib\":"<<ru.ru_maxrss<<",\n\"source_sha256\":\""<<source_hash<<"\"\n}\n";
    out.close();if(!out){std::cerr<<"report write failure\n";return 3;}
    std::cout<<"{\"status\":\""<<status<<"\",\"n\":"<<2*p<<",\"H_completed\":"<<completed
             <<",\"orientations\":"<<solver.stats["solutions"]<<",\"cpu_seconds\":"<<solver.cpu()<<"}\n";
    return 0;
}
