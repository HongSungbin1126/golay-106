# Additional preparation validation and portability correction

The original evidence remains unchanged. This folder separates later preparation work from historical records.

## Rejected run

`fresh_primary_rejected_libcpp/` is the complete but **rejected** first Mac replay of the unmodified legacy source. Its extra nonunits and42outputs are not accepted theorem evidence. Read PORTABILITY_FINDING.md and INDEPENDENT_PORTABILITY_DIAGNOSIS.md. The failure is an overload/name collision with mathematical floating-point remainder, not an absence-of-pairs result.

## Corrected sources

- `portable_source/exact_orientation_fibers_portable.cpp`: only renames all five occurrences of the polynomial helper to poly_remainder.
- `portable_source/exact_orientation_fibers_arm.cpp`: same correction plus guarded exact AArch64 PMULL carryless multiplication. Uses software fallback on targets without the selected intrinsic.
- `portable_source/arm_arithmetic_selftest.cpp`: compares1,000,000 deterministic full64-bit products against the software shift/XOR product and tests field inversions. It must exit0. Assertions in the primary solver must remain enabled.

The corrected source hashes are recorded in PORTABILITY_FINDING.md and in actual campaign headers. Do not replace historical hashes with these new ones. These are separate executable versions.

Build from this folder in a fresh working copy:

```sh
c++ -std=c++17 -O3 -Wall -Wextra portable_source/exact_orientation_fibers_arm.cpp -o primary-corrected-arm64
c++ -std=c++17 -O3 -Wall -Wextra portable_source/arm_arithmetic_selftest.cpp -o arithmetic-selftest
./arithmetic-selftest
```

The filename of the primary binary is conventional; its architecture depends on the build target. Supplied `primary-corrected-arm64` is the actual Mac arm64 preparation build and is included only as hash-pinned evidence. Prefer rebuilding reviewed source. On macOS downloaded executables may require ordinary operating-system approval; do not treat an execution failure as a mathematical exclusion.

For a new full replay (choose an output directory that does not exist):

```sh
node run_fresh_quarters.js ./primary-corrected-arm64 portable_source/exact_orientation_fibers_arm.cpp fresh_new_replay
```

This runs four workers over disjoint quarters, with source/binary hashes and complete output framing. It records process completion only. The separately supplied strict auditor is configured for the accepted preparation output directory `fresh_primary_corrected/`. To reproduce into that name, preserve the archived directory elsewhere first and use a fresh working copy. Run:

```sh
python3 -B audit_fresh_primary.py
```

The strict auditor verifies declared ranges/target/source/binary, exactly one nonunit, header/footer and point counts, every output's literal edge parity and folded inverse, absence of duplicates, and complete equality with the archived102-candidate set. It checks execution evidence and outputs, not a formal per-fiber theorem trace. Read the actual fresh_summary.json status; no incomplete run or missing summary is success.

`direct_sign_replay.jsonl` is a distinct fresh enumeration of all136,314,944 assignments from the eight complete sign spaces in ordinary binary order, using original integer correlations. It confirms exact-zero exclusion, not the stronger modulo64 conclusion by itself.
