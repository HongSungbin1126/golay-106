#!/usr/bin/env python3
"""Strict audit of four fresh disjoint primary native partitions.
This audits execution records and emitted points, not a formal proof trace.
The frozen solver's mathematical completeness remains a separate obligation.
CC BY 4.0. No human review claimed.
"""
import hashlib
import json
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
if (here.parent / 'CLAIMS.json').exists():
    evidence = here.parent
    binary = here / 'primary-corrected-arm64'
else:
    project = Path(__file__).resolve().parents[2]
    evidence = project / 'research_bundle/golay_research'
    binary = project / '.tools/primary_arm'
sys.path.insert(0, str(evidence / 'src'))
from audit_fiber_campaign import check_orientation, read_json, require, sha, unique

root = here / 'fresh_primary_corrected'
source = here / 'portable_source/exact_orientation_fibers_arm.cpp'
source_hash = sha(source)
require(source_hash == 'bd567766ec3848c9da55d41e97f5c41766659fc0874f37ef447713b53a455b2d', 'corrected source mismatch')
controller = read_json(root / 'controller.json')
complete = read_json(root / 'controller_complete.json')
require(controller['source_sha256'] == source_hash and controller['binary_sha256'] == sha(binary), 'controller provenance')
require(complete['status'] == 'FOUR_NATIVE_QUARTERS_COMPLETED_AUDIT_STILL_REQUIRED', 'controller incomplete')
require(complete['source_sha256'] == source_hash and complete['binary_sha256'] == sha(binary), 'completion provenance')
require(controller['ranges'] == [[i*16777216, (i+1)*16777216] for i in range(4)], 'controller ranges')
parts, all_rows = [], []
for i in range(4):
    report_path = root / ('part' + str(i) + '.json')
    orientation_path = root / ('part' + str(i) + '.jsonl')
    report = read_json(report_path)
    lower, upper = i * 16777216, (i + 1) * 16777216
    require(report['status'] == 'COMPLETE_H_PARTITION', 'incomplete partition')
    require(report['p'] == 53 and report['n'] == 106 and report['total_H_domain'] == 67108864, 'report target mismatch')
    require(report['h_start'] == lower and report['h_end_exclusive'] == upper, 'wrong interval')
    require(report['H_completed'] == upper-lower == report['statistics']['H_examined'], 'coverage mismatch')
    require(report['source_sha256'] == source_hash, 'report source mismatch')
    stats = report['statistics']
    require(stats.get('nonunit_H', 0) == int(i == 0), 'nonunit mismatch')
    require(stats.get('unit_H', 0) + stats.get('nonunit_H', 0) == upper-lower, 'unit accounting')
    records = [json.loads(line, object_pairs_hook=unique) for line in orientation_path.read_text().splitlines()]
    head, tail, rows = records[0], records[-1], records[1:-1]
    require(head['record_type'] == 'header' and head['format'] == 'exact_fiber_orientations_v1', 'header schema')
    require(head['h_start'] == lower and head['h_end_exclusive'] == upper and head['n'] == 106, 'header range')
    require(head['source_sha256'] == source_hash, 'header source')
    require(tail['record_type'] == 'footer' and tail['status'] == report['status'] and tail['H_completed'] == upper-lower, 'footer')
    require(len(rows) == stats.get('solutions', 0), 'export count')
    for row in rows:
        check_orientation(row, 53, lower, upper)
    all_rows.extend(rows)
    parts.append({'report_path': report_path.name, 'report_sha256': sha(report_path),
        'orientation_path': orientation_path.name, 'orientation_sha256': sha(orientation_path),
        'range': [lower, upper], 'completed': report['H_completed'], 'cpu_seconds': report['cpu_seconds'],
        'wall_seconds': report['wall_seconds'], 'statistics': stats})

key = lambda row: (row['h'], row['q_bits_mask'], row['t_bits_mask'])
actual = set(map(key, all_rows))
raw_reference = [json.loads(line, object_pairs_hook=unique) for line in
    (evidence / 'results/campaign_n106_first_parity_orientations.jsonl').read_text().splitlines()]
reference = {key(row) for row in raw_reference if row.get('record_type') == 'orientation'}
require(len(actual) == len(all_rows) == len(reference) == 102, 'candidate cardinality or duplicates')
require(actual == reference, 'complete candidate set mismatch')
result = {'status': 'FRESH_COMPLETE_CORRECTED_PRIMARY_REPLAY_EXACT_SET_MATCH', 'n': 106,
    'covered_H': 67108864, 'unit_H': 67108863, 'nonunit_H': 1,
    'orientations': 102, 'duplicates': 0, 'gaps': [], 'overlaps': [],
    'exact_archived_primary_set_match': True, 'literal_parity_and_inverse_checked_for_every_output': True,
    'source_sha256': source_hash, 'binary_sha256': sha(binary),
    'platform': 'darwin-arm64', 'compiler': 'Apple Clang21, C++17 -O3 -Wall -Wextra, assertions enabled',
    'multiplication': 'AArch64 PMULL, checked against portable shift/XOR on1000000 products', 'workers': 4,
    'cpu_seconds_sum': sum(x['cpu_seconds'] for x in parts),
    'maximum_partition_wall_seconds': max(x['wall_seconds'] for x in parts),
    'formal_kernel': False, 'auditor_source_sha256': sha(Path(__file__)),
    'scope': 'Fresh complete primary execution plus strict range, framing, arithmetic/output and exact-set audit; mathematical implementation completeness trusted',
    'parts': parts}
(root / 'fresh_summary.json').write_text(json.dumps(result, indent=2) + '\n')
(root / 'all_orientations.jsonl').write_text(''.join(json.dumps(row, sort_keys=True)+'\n' for row in sorted(all_rows, key=key)))
print(json.dumps({k: result[k] for k in ['status', 'covered_H', 'orientations', 'cpu_seconds_sum', 'maximum_partition_wall_seconds']}))
