# Reproduce the n=106 result

Run commands from the project root. Python3 standard-library code and a C++17
compiler on Linux suffice for the accepted n106 result. The Python SAT packages
in requirements.txt are needed only for the separate earlier SAT experiments.

The quick checks below validate the archived evidence and compact certificates.
They do not redo the67,108,864-H search. The full replay instructions follow.
Keep the supplied evidence unchanged; write recheck outputs to new paths.

## 1. Quick evidence and certificate checks

~~~bash
python3 -E src/audit_fiber_campaign.py \
  --campaign results/campaign_n106_first_parity \
  --campaign results/campaign_n106_artifact_replay \
  --output /tmp/golay_primary_coverage_recheck.json

python3 -E src/audit_independent_campaign.py \
  --output /tmp/golay_independent_coverage_recheck.json

python3 -E tests/exact_sign_space_audit.py \
  --n 106 \
  --orientations results/campaign_n106_first_parity_orientations.jsonl \
  --details results/exact_signs_n106_campaign_full_signs.jsonl \
  --summary results/exact_signs_n106_campaign_full_signs.json \
  --output /tmp/golay_sign_spaces_recheck.json

python3 -E src/exact_sign_character_certificate_check.py \
  --n 106 \
  --spaces results/exact_signs_n106_campaign_kernel_inventory.jsonl \
  --certificate results/algebra_sign_character_reductions.json \
  --affine-audit results/campaign_n106_sign_space_audit.json \
  --mod32-witnesses results/algebra_mod32_witnesses.json \
  --output /tmp/golay_character_certificate_recheck.json
~~~

Expected outcomes: complete primary coverage; complete independent first-parity
coverage with exactly102 orientations; all102 sign systems covered;8 character
certificates accepted;8 modulo32 normalized witnesses and a64-element raw orbit.
The ten invalid original primary output receipts are intentionally preserved.
The primary audit reports them but accepts their intervals only through the
separate successful artifact-replay receipts.

Never run the assertion-based checkers with Python -O. They explicitly refuse
optimized mode. Python -E also ignores Python-specific environment overrides.

## 2. Rebuild the primary native engine

~~~bash
g++ -O3 -std=c++17 -Wall -Wextra \
  src/exact_orientation_fibers_v2.cpp \
  -o src/exact_orientation_fibers_v2
~~~

This engine's mathematical source is frozen in the supplied evidence. A rebuild
on another compiler may legitimately have a different executable hash. Use fresh
run tags and reports for that executable; do not alter a historical receipt to
make its binary hash match.

Run two bounded half-domain batches sequentially. Each command launches at most
four single-threaded workers and holds their live output files in private
temporary locations until the files are closed.

~~~bash
python3 -E src/run_primary_fiber_campaign.py \
  --tag reproduce_primary_half1 --h-start 0 --h-count 33554432

python3 -E src/run_primary_fiber_campaign.py \
  --tag reproduce_primary_half2 --h-start 33554432 --h-count 33554432

python3 -E src/audit_fiber_campaign.py \
  --campaign results/reproduce_primary_half1 \
  --campaign results/reproduce_primary_half2 \
  --output results/reproduced_primary_coverage.json \
  --orientations results/reproduced_primary_orientations.jsonl
~~~

Expected:64 nonoverlapping1,048,576-H partitions, exactly67,108,863 units,
one nonunit, and102 distinct orientations. Source/executable/output hashes are
checked again. If a batch exceeds the configured budget it stops incomplete;
resume only explicitly uncovered intervals under a new tag.

The recorded primary run took about59 aggregate CPU minutes before artifact
repairs. This is an observation on the recorded x86_64 environment, not a runtime
guarantee for another machine. The native code detects PCLMUL support at runtime
and otherwise uses an exact portable carryless-product implementation.

## 3. Reproduce the independent first-stage engine

Follow REPRODUCE_INDEPENDENT.md. It documents the independent source,
compilation, deterministic unit checks, complete known-length calibration,
stratified n106 calibration, and two bounded half-domain batches.

The independent engine must regenerate the candidate set, not merely verify
that the102 supplied candidates pass the parity equations. Matching only the
positive outputs does not establish the absence of omitted solutions.

The root-owned audit in src/audit_independent_campaign.py checks archived source
and binary snapshots, all64 interval reports and hashes, both half checkpoints,
every output orientation, and equality with the primary candidate set.

## 4. Reproduce the sign layer

The shortest accepted route is the independent affine-space and character
certificate checks in Section1. The latter reconstructs original integer Gram
products, verifies each necessary congruence, checks complete affine restrictions
and XOR contradictions, and explicitly validates the safe modulus64 argument.

For an additional direct replay of every remaining exact-zero sign candidate:

~~~bash
python3 -E src/run_direct_sign_replay.py \
  --audit results/campaign_n106_sign_space_audit.json \
  --tag reproduced_direct_signs --seconds 1100
~~~

This builds an independent C++ program and enumerates the8 certified spaces in
ordinary binary order. It constructs ±1 arrays and directly sums the original
integer correlations. It uses neither the native Gray traversal nor its row-norm
prefilter. Expected total:136,314,944 assignments,8 complete spaces, no pair.
The recorded run took92.3943 CPU seconds.

This exact-zero enumeration is corroboration. The modulus64 theorem requires the
separate modular certificate; a row-norm filter for exact Golay pairs would not
by itself be legitimate for classifying modulo32/64 pairs.

## 5. Inspect an explicit modulo32 witness

The full sequences and105 original residuals are in
results/algebra_mod32_witnesses.json. The representative has only

\[
(r_4,r_8,r_{12},r_{16},r_{20})=(-160,128,-96,64,-32)
\]

nonzero. All other positive-lag residuals vanish. The character checker
reconstructs all eight normalized witnesses and independently verifies their
original residuals and standard symmetry orbit.

## 6. What a successful reproduction supports

A successful full first-stage replay plus the checked sign certificate supports
the finite n106 modular classification and hence ordinary binary aperiodic
Golay nonexistence at n106. It does not prove the general length conjecture,
establish publication priority, or provide a formal theorem-kernel derivation
of every implementation step.

Supplementary proved optimizations in proof/algebra_analytic_first_stage.md and
proof/algebra_second_projection.md are not dependencies of the frozen full
replays. Any implementation of those optimizations needs its own source version,
coverage evidence, and performance measurements.
