# Reproduce the independent length-106 first-parity enumeration

This recipe rebuilds the independent executable with a fresh compiler, reruns
its unit checks and complete small-domain calibrations, and enumerates all
67,108,864 folded H values in two checkpointed half-domain batches. It then
runs the separate root-owned integrity and coverage auditor.

This is the **first-parity stage**. The original correlation and sign-certificate
checks are separate steps in the project README. The primary orientation list
is used only after each independent partition has finished, for exact set
comparison; it is never an input to search pruning.

## 1. Requirements and expected resources

Use a Linux machine with Python 3.10 or later, a C++17-capable GCC/G++ compiler,
and the ordinary Python/C++ standard libraries. No solver, NumPy, symbolic
algebra package, paid API, or external mathematical library is required.
The recorded build used G++ 13.3.0 on Linux. The compiler version and build
command for the recorded executable are in the campaign's
`compiler_manifest.json`.

On x86-64, the executable checks PCLMUL support at runtime and uses an exact
carryless-multiplication instruction when available. Its separately tested
shift/XOR fallback handles CPUs without that instruction. The fallback can
take longer; measure the calibration before committing to the same deadlines.
No `-march=native` or mandatory PCLMUL compiler flag is needed.

The supplied campaign configuration uses exactly four single-threaded solver
workers, two sequential half-domain batches, a 1,100-second wall deadline per
half, and a 7,200-second aggregate child-CPU allowance across both halves.
Each child enforces a 1 GiB address-space limit and CPU/wall deadlines. Measured
worker RSS was approximately 12 MiB, and the intended aggregate RAM envelope
is at most 4 GiB. Keep other project compute idle while these four workers run.
The separate resource watchdog stops matching solver processes at 7,000 CPU
seconds, reserving 200 seconds below the allocation.

The five-stratum calibration estimated about 1.37 aggregate CPU hours on the
recorded host. Full-run time depends on the host and concurrent load. A timeout
is an incomplete reproduction, not a negative mathematical result. The final
auditor intentionally requires all 64 partitions and both complete checkpoints.

## 2. Make a fresh working copy

Keep the supplied evidence directory unchanged. Choose a new, nonexistent
working directory. The example paths below are placeholders to replace with
your actual absolute paths:

```bash
set -eu
GOLAY_EVIDENCE_DIR=/absolute/path/to/golay_research
GOLAY_REPLAY_DIR=/absolute/path/to/golay_research_reproduction
test -d "$GOLAY_EVIDENCE_DIR"
test ! -e "$GOLAY_REPLAY_DIR"
cp -a -- "$GOLAY_EVIDENCE_DIR" "$GOLAY_REPLAY_DIR"
cd "$GOLAY_REPLAY_DIR"
mkdir -p build/independent_reproduction
```

The controller has fixed filenames for the validation reports and its default
campaign directory. Regenerate those reports **inside this fresh copy**.
Preserve the copied original campaign under another name so that the default
output directory is genuinely new. This also lets the unchanged watchdog
locate the new campaign correctly:

```bash
python3 - <<'PY'
from pathlib import Path
import shutil

root = Path.cwd()
campaign = root / 'results/campaign_n106_first_parity_independent'
archived = root / 'results/campaign_n106_first_parity_independent_from_archive'
if campaign.exists():
    if archived.exists():
        raise SystemExit('Archive destination already exists; choose a fresh working copy.')
    campaign.rename(archived)

saved = root / 'build/independent_reproduction/input_validation_reports'
saved.mkdir(parents=True, exist_ok=False)
for name in (
    'verification_folded_independent_v2_unit.json',
    'verification_folded_independent_calibration_v2_strata4096.json',
):
    path = root / 'results' / name
    if path.exists():
        shutil.copy2(path, saved / name)
print('Original evidence is preserved; reproduction outputs belong to this working copy.')
PY
```

Do not rename or delete the primary input files, particularly
`results/campaign_n106_first_parity_orientations.jsonl` and the small-domain /
stratified reference JSONL files used by the calibration script. They remain
comparison evidence. The commands below do not modify solver source files or
the frozen search controller.

## 3. Build both executables from source

```bash
g++ -std=c++17 -O3 -Wall -Wextra \
  src/verify_folded_independent_v2.cpp \
  -o build/independent_reproduction/solver

g++ -std=c++17 -O3 -Wall -Wextra \
  -DGOLAY_VERIFY_ENGINE='"../src/verify_folded_independent_v2.cpp"' \
  tests/verify_folded_independent_test.cpp \
  -o build/independent_reproduction/unit_tests
```

The quoting on `GOLAY_VERIFY_ENGINE` is intentional: the preprocessor receives
a quoted include filename. The test translation unit includes the independent
v2 engine directly and disables its command-line main function.

The source SHA256 for the recorded v2 version is
`bf6787ae84099a25d19297e4f47fe5ab0a832167c6e5d86ee1ef83b733c6e1f8`.
A different compiler may produce a different executable hash from identical
source. That is expected. The next steps generate matching fresh validation
metadata, rather than copying the recorded executable hash into a new report.

## 4. Run unit checks and write matching metadata

The campaign requires a PASS unit report whose source hash matches the source
being run. Generate that report from the newly built test executable:

```bash
python3 - <<'PY'
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

root = Path.cwd()
source = root / 'src/verify_folded_independent_v2.cpp'
test_source = root / 'tests/verify_folded_independent_test.cpp'
test_binary = root / 'build/independent_reproduction/unit_tests'
solver_binary = root / 'build/independent_reproduction/solver'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

run = subprocess.run([str(test_binary)], capture_output=True, text=True,
                     timeout=60, check=True)
result = json.loads(run.stdout)
if result.get('status') != 'PASS':
    raise SystemExit('Unit test program did not report PASS.')
result.update({
    'source_sha256': sha(source),
    'test_source_sha256': sha(test_source),
    'binary_sha256': sha(test_binary),
    'solver_binary_sha256': sha(solver_binary),
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'compiler_version_output': subprocess.run(
        ['g++', '--version'], capture_output=True, text=True, check=True).stdout,
    'compiler_flags': ['-std=c++17', '-O3', '-Wall', '-Wextra'],
    'test_engine_include': '../src/verify_folded_independent_v2.cpp',
})
destination = root / 'results/verification_folded_independent_v2_unit.json'
temporary = destination.with_name(destination.name + '.new')
temporary.write_text(json.dumps(result, indent=2) + '\n')
os.replace(temporary, destination)
print(json.dumps(result, indent=2))
PY
```

Expected checks include 450 exhaustive affine systems, 372 inverse checks,
1,200 analytic derivative checks, 100 full affine-consequence span checks,
complete small parity domains, actual branch-fallback cases, 190,464
accelerated-versus-reflection comparisons, and 126,976 carryless-product
comparisons. The program must exit successfully; copying an old PASS label
does not satisfy this step.

## 5. Calibrate the freshly compiled solver

Use the fixed tag below because the frozen campaign expects the resulting
report filename. This overwrites only the freshly copied validation outputs;
the original input directory and saved report copies remain unchanged.

```bash
python3 tests/verify_folded_independent_calibration.py \
  --source src/verify_folded_independent_v2.cpp \
  --binary "$GOLAY_REPLAY_DIR/build/independent_reproduction/solver" \
  --limit106 4096 \
  --seconds 60 \
  --tag v2_strata4096
```

This checks the entire n=34,50,58 orientation sets, then five dispersed
4,096-H partitions at n=106. The expected complete small-domain counts are
22,28,64, and all 13 original n=106 pilot orientations are covered. It writes
`results/verification_folded_independent_calibration_v2_strata4096.json` with
the newly compiled solver's actual binary hash. The campaign refuses to start
if the current source or executable does not match this calibration metadata.

Inspect the reported timing extrapolation. If this machine cannot plausibly
finish each half within the supplied wall cap and the whole replay within
the CPU allocation, stop at calibration. A separately reviewed resource
configuration is needed; do not label an incomplete run as complete or
silently alter an existing receipt.

## 6. Run both bounded halves with the watchdog

The following launcher uses the unchanged campaign and watchdog sources. It
starts the guard after the new configuration file exists, propagates campaign
failure, and stops the guard when the campaign exits. Output remains attached
to the terminal. Long-lived solver outputs go into a private `/tmp` directory;
closed, validated files are atomically copied into the new results directory.

```bash
python3 - <<'PY'
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path.cwd()
campaign_dir = root / 'results/campaign_n106_first_parity_independent'
if campaign_dir.exists():
    raise SystemExit('Campaign output directory must not exist. Use the fresh-copy preparation step.')
command = [
    sys.executable, 'tests/verify_folded_independent_campaign.py',
    '--binary', str(root / 'build/independent_reproduction/solver'),
    '--output-dir', str(campaign_dir),
    '--workers', '4',
    '--cpu-budget', '7200',
    '--batch-wall-limit', '1100',
]
campaign = subprocess.Popen(command)
guard = None
try:
    deadline = time.monotonic() + 30
    configuration = campaign_dir / 'configuration.json'
    while not configuration.exists():
        if campaign.poll() is not None:
            raise SystemExit(f'Campaign failed before configuration: exit {campaign.returncode}')
        if time.monotonic() >= deadline:
            raise SystemExit('Campaign did not create its configuration within 30 seconds.')
        time.sleep(0.1)
    guard = subprocess.Popen([sys.executable, 'tests/verify_folded_replay_watchdog.py'])
    returncode = campaign.wait()
    if returncode:
        raise SystemExit(f'Campaign incomplete or rejected: exit {returncode}')
finally:
    if campaign.poll() is None:
        # SIGINT lets the controller's exception handler stop its four children.
        campaign.send_signal(signal.SIGINT)
        try:
            campaign.wait(timeout=20)
        except subprocess.TimeoutExpired:
            campaign.kill()
            campaign.wait(timeout=5)
            raise SystemExit('Controller cleanup timed out; inspect its private worker processes before another run.')
    if guard is not None and guard.poll() is None:
        try:
            guard.wait(timeout=15)
        except subprocess.TimeoutExpired:
            guard.terminate()
            guard.wait(timeout=5)
print('Campaign process completed. Run the separate root-owned auditor next.')
PY
```

For an agent-operated run, launch this through a nonblocking execution session
and poll with waits of at most 60 seconds. Do not promise continuation after a
turn or application closes without checking that the environment supports it.

The controller first completes `[0,33,554,432)`, validates its exact interval
union, and saves `half1_checkpoint.json`. It then starts a fresh bounded batch
for `[33,554,432,67,108,864)`, while preserving cumulative CPU accounting.
Both half checkpoints and all 64 accepted partition receipts are required.
The guard supplements any environment-specific live-PID accounting limitation
using readable process metadata and closed native reports; it never bypasses
access controls.

The output directory includes immutable snapshots of the source, compiled
binary, controller, and parser dependency. The private raw directory is
recorded in `configuration.json` and retained for inspection. An error or
timeout leaves an INCOMPLETE status and must be investigated. This recipe
does not pretend to resume an unfinished interval from an unverified position.

## 7. Run the separate final auditor

Run from the fresh project root:

```bash
python3 src/audit_independent_campaign.py \
  --campaign results/campaign_n106_first_parity_independent \
  --reference results/campaign_n106_first_parity_orientations.jsonl \
  --output results/verification_independent_reproduction_root_audit.json
```

Acceptance requires
`COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY_ACCEPTED`, coverage of exactly
67,108,864 H values, one rejected nonunit H=0 and 67,108,863 unit values,
64 disjoint complete partitions, and exact agreement with the 102-orientation
primary set. The auditor rehashes the snapshots and every raw partition,
checks headers/footers and coverage counts, independently validates emitted
orientations, and verifies the final aggregate and both bounded checkpoints.

Do not replace this with a comparison of total counts alone. A new compiler's
binary hash need not equal the recorded binary hash, but its own calibration,
campaign snapshots, receipts, and audit must agree with one another.

The resulting first-stage acceptance is one component of the computational
argument. Original sign-space completeness, integer-character certificates,
the modulo-64 implication, and the scope of the mathematical conclusion are
documented and checked separately in the main project materials.
