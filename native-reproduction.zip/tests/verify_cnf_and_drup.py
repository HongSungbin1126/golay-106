"""Small independent truth-table and adversarial tests for CNF/DRUP gates."""

import hashlib
import itertools
import json
from pathlib import Path
import random
import resource
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from verify_drup import ClauseDatabase, ProofRejected, check, parse_dimacs
from verify_independent import verify_pair
from cnf_golay import Circuit, build_direct, build_quad, decode, Solver


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def naive_unit_refutes(clauses, assumptions):
    values = {}
    for literal in assumptions:
        variable, value = abs(literal), literal > 0
        if variable in values and values[variable] != value:
            return True
        values[variable] = value
    changed = True
    while changed:
        changed = False
        for clause in clauses:
            if any(abs(lit) in values and values[abs(lit)] == (lit > 0) for lit in clause):
                continue
            unknown = [lit for lit in clause if abs(lit) not in values]
            if not unknown:
                return True
            if len(unknown) == 1:
                literal = unknown[0]
                values[abs(literal)] = literal > 0
                changed = True
    return False


def main():
    resource.setrlimit(resource.RLIMIT_CPU, (120, 125))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    wall, cpu = time.monotonic(), time.process_time()
    counts = {}
    rng = random.Random(2026110502)
    unit_cases = 0
    for variables in range(1, 7):
        for _ in range(150):
            clauses = [[rng.choice((-1, 1))*rng.randint(1, variables)
                        for _ in range(rng.randrange(5))]
                       for _ in range(rng.randrange(15))]
            db = ClauseDatabase(clauses)
            assumptions = [rng.choice((-1, 1))*rng.randint(1, variables)
                           for _ in range(rng.randrange(6))]
            if clauses and rng.choice((False, True)):
                db.delete(rng.choice(clauses))
            active = [c for c, enabled in zip(db.clauses, db.active) if enabled]
            require(db.unit_refutes(assumptions) == naive_unit_refutes(active, assumptions),
                    "unit-propagation disagreement")
            unit_cases += 1
    counts["unit_propagation_against_separate_scan"] = unit_cases

    # Exhaust all values of inputs and output for literal-signed basic gates.
    gate_cases = 0
    for gate in ("xor2", "conjunction"):
        for sa, sb in itertools.product((-1, 1), repeat=2):
            c = Circuit()
            x, y = c.var("x"), c.var("y")
            z = getattr(c, gate)(sa*x, sb*y)
            for bx, by, bz in itertools.product((False, True), repeat=3):
                values = {x: bx, y: by, z: bz}
                holds = all(any(values[abs(lit)] == (lit > 0) for lit in clause)
                            for clause in c.cnf.clauses)
                px, py = bx if sa > 0 else not bx, by if sb > 0 else not by
                expected = (px != py) if gate == "xor2" else (px and py)
                require(holds == (bz == expected), "incorrect signed gate truth table")
                gate_cases += 1
    counts["signed_gate_truth_assignments"] = gate_cases

    cardinality_cases = 0
    for bound in range(4):
        c = Circuit()
        x, y, z = [c.var(name) for name in ("x", "y", "z")]
        c.cardinality([x, -y, z], bound)
        with Solver(name="glucose42", bootstrap_with=c.cnf) as sat:
            for bits in itertools.product((0, 1), repeat=3):
                assumptions = [variable if bit else -variable for variable, bit in zip((x,y,z), bits)]
                expected = bits[0]+1-bits[1]+bits[2] == bound
                require(sat.solve(assumptions=assumptions) == expected, "signed cardinality failure")
                cardinality_cases += 1
    counts["signed_totalizer_cardinality_assignments"] = cardinality_cases

    direct_cases = 0
    for n in (1, 2, 3, 4):
        c, meta = build_direct(n, mirror=False, mode="none")
        variables = meta["A"] + meta["B"]
        with Solver(name="glucose42", bootstrap_with=c.cnf) as sat:
            for bits in itertools.product((0, 1), repeat=2*n):
                assumptions = [v if bit else -v for v, bit in zip(variables, bits)]
                a = [1-2*bit for bit in bits[:n]]
                b = [1-2*bit for bit in bits[n:]]
                expected = verify_pair(a, b)["aperiodic_golay"]
                require(sat.solve(assumptions=assumptions) == expected, "direct CNF semantic mismatch")
                direct_cases += 1
    counts["complete_direct_primary_assignments_n_le_4"] = direct_cases

    quad_cases, orientation_cases = 0, 0
    for n in (2, 4, 6):
        m = n//2
        c, meta = build_quad(n)
        variables = meta["q"] + meta["t"] + meta["s"]
        with Solver(name="glucose42", bootstrap_with=c.cnf) as sat:
            for bits in itertools.product((0, 1), repeat=3*m):
                assumptions = [v if bit else -v for v, bit in zip(variables, bits)]
                a, b = decode(assumptions, meta)
                normalized = bits[0] == bits[m] == bits[2*m] == 0
                expected = normalized and verify_pair(a, b)["aperiodic_golay"]
                require(sat.solve(assumptions=assumptions) == expected, "quad CNF semantic mismatch")
                quad_cases += 1
        c, meta = build_quad(n, orientation_only=True)
        variables = meta["q"] + meta["t"]
        with Solver(name="glucose42", bootstrap_with=c.cnf) as sat:
            for bits in itertools.product((0, 1), repeat=2*m):
                assumptions = [v if bit else -v for v, bit in zip(variables, bits)]
                q, t = [1-2*x for x in bits[:m]], [1-2*x for x in bits[m:]]
                a = [1]*m + list(reversed(t))
                b = q + list(reversed([-q[i]*t[i] for i in range(m)]))
                residuals = verify_pair(a, b)["residuals"]
                require(all(r % 4 == 0 for r in residuals), "quad divisibility assumption failed")
                expected = (bits[0] == bits[m] == 0 and all(r % 8 == 0 for r in residuals))
                require(sat.solve(assumptions=assumptions) == expected, "orientation relaxation mismatch")
                orientation_cases += 1
    counts["complete_quad_primary_assignments_n_2_4_6"] = quad_cases
    counts["complete_orientation_assignments_n_2_4_6"] = orientation_cases

    proof_cases = 0
    with tempfile.TemporaryDirectory() as directory:
        directory = Path(directory)
        formula, proof = directory / "input.cnf", directory / "proof.drup"
        formula.write_text("p cnf 2 4\n1 2 0\n1 -2 0\n-1 2 0\n-1 -2 0\n")
        proof.write_text("1 0\nd 1 2 0\n0\n")
        require(check(formula, proof)["result"] == "PASS", "valid DRUP rejected")
        proof_cases += 1
        # RUP consequences of the original CNF remain true when deletion hints
        # are ignored. This alternative has explicit semantics and is sound.
        proof.write_text("1 0\nd 1 0\n0\n")
        require(check(formula, proof, deletions_mode="retain")["result"] == "PASS",
                "sound retained-lemma replay rejected")
        proof_cases += 1
        # Fresh unit3 is RAT with a vacuous opposite-pivot condition, but is
        # not RUP here. The intentionally limited checker must reject it.
        for text in ("3 0\n0\n", "1 0\nd 1 0\n0\n", "d 7 0\n0\n", "a 1 0\n"):
            proof.write_text(text)
            try:
                check(formula, proof)
            except ProofRejected:
                proof_cases += 1
            else:
                raise AssertionError("unsupported or invalid proof accepted")
        formula.write_text("p cnf 2 1\n1 2 0\n")
        for text in ("0\n", "1 0\n0\n", "\n"):
            proof.write_text(text)
            try:
                check(formula, proof)
            except ProofRejected:
                proof_cases += 1
            else:
                raise AssertionError("satisfiable formula certified UNSAT")
        for malformed in (b"p cnf 1 1\n2 0\n", b"p cnf 1 2\n1 0\n", b"p cnf 1 1\n1\n"):
            try:
                parse_dimacs(malformed)
            except ProofRejected:
                proof_cases += 1
            else:
                raise AssertionError("malformed DIMACS accepted")
    counts["valid_and_adversarial_proof_parser_cases"] = proof_cases

    report = {"date":"2026-11-05", "result":"PASS", "counts":counts,
              "cpu_seconds":time.process_time()-cpu, "wall_seconds":time.monotonic()-wall,
              "peak_memory_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
              "cnf_encoder_sha256":hashlib.sha256((ROOT/"src/cnf_golay.py").read_bytes()).hexdigest(),
              "drup_checker_sha256":hashlib.sha256((ROOT/"src/verify_drup.py").read_bytes()).hexdigest(),
              "test_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "limits":"Regression and exact finite truth-table checks; no open-length result."}
    (ROOT/"results/verification_cnf_and_drup_tests.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
