"""Audit exported sign spaces against ORIGINAL aperiodic correlations.

This checks exact affine spaces and DECLARED interval coverage. It does not
replay every sign rejection and must never be called a complete UNSAT checker.
The derivation does not reuse the native solver's quad-edge coefficient code.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

if not __debug__:
    raise RuntimeError('this audit requires Python assertions enabled; do not use -O')

def unique_object(pairs):
    out={}
    for key,value in pairs:
        if key in out:
            raise ValueError(f'duplicate JSON object key: {key}')
        out[key]=value
    return out


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def strict_jsonl(path,allow_empty=False):
    raw=path.read_text()
    if not raw and allow_empty:
        return []
    assert raw.endswith('\n'), f'{path}: missing final newline / possible truncation'
    rows=[]
    for number,line in enumerate(raw.splitlines(),1):
        assert line.strip(), f'{path}:{number}: blank record'
        item=json.loads(line,object_pairs_hook=unique_object)
        assert isinstance(item,dict), f'{path}:{number}: record is not an object'
        rows.append(item)
    return rows


def read_orientation_files(paths,n):
    expected={}
    provenance=[]
    for path in paths:
        rows=strict_jsonl(path)
        assert len(rows)>=2 and rows[0].get('record_type')=='header'
        assert rows[-1].get('record_type')=='footer', f'{path}: missing footer'
        header,footer=rows[0],rows[-1]
        assert header['n']==n
        assert header['format'] in ('exact_orientation_v1','exact_fiber_orientations_v1')
        if header['format']=='exact_fiber_orientations_v1':
            begin,end,done=header['h_start'],header['h_end_exclusive'],footer['H_completed']
            assert all(type(v) is int for v in (begin,end,done))
            assert 0<=begin<end and 0<=done<=end-begin
            assert footer['status'] in ('COMPLETE_H_DOMAIN','COMPLETE_H_PARTITION','TIMEOUT')
            if footer['status'].startswith('COMPLETE_'):
                assert done==end-begin
            if footer['status']=='COMPLETE_H_DOMAIN':
                assert (n//2)%2==1 and begin==0 and end==(1<<((n//2-1)//2))
        else:
            begin,end,done=header['q_start'],header['q_end_exclusive'],footer['q_completed']
            assert all(type(v) is int for v in (begin,end,done))
            assert 0<=begin<end and 0<=done<=end-begin
            assert footer['solver_report'] in ('SAT','UNSAT','PARTITION_UNSAT','TIMEOUT')
            if footer['solver_report'] in ('UNSAT','PARTITION_UNSAT'):
                assert done==end-begin
        for row in rows[1:-1]:
            assert row.get('record_type')=='orientation', f'{path}: unexpected middle record'
            assert row['n']==n
            key=(row['q_bits_mask'],row['t_bits_mask'])
            assert all(type(v) is int for v in key)
            if header['format']=='exact_fiber_orientations_v1':
                assert type(row['h']) is int and begin<=row['h']<begin+done
                p=n//2
                folded=key[0]^reverse_bits(key[0],p)
                assert (folded&((1<<((p-1)//2))-1))==row['h']
            assert key not in expected, f'duplicate orientation in audited inputs: {key}'
            expected[key]=row
        provenance.append({'path':str(path),'sha256':sha256(path),'header':header,'footer':footer,
                           'orientation_records':len(rows)-2,'header_footer_metadata_checked':True})
    return expected,provenance


def reverse_bits(a,m):
    assert 0<=a<(1<<m)
    return int(format(a,f'0{m}b')[::-1],2)


def original_residuals(q,t,u,n):
    m=n//2
    mask=(1<<m)-1
    A=u|(reverse_bits(u^t,m)<<m)
    B=(u^q)|(reverse_bits(u^q^t^mask,m)<<m)
    residual=[]
    for k in range(1,n):
        live=(1<<(n-k))-1
        h=((A^(A>>k))&live).bit_count()+((B^(B>>k))&live).bit_count()
        residual.append(2*(n-k)-2*h)
    return residual


def original_affine_rows(q,t,n):
    """r_k(u)/8 mod2 is affine once the first parity condition holds."""
    m=n//2
    assert n%2==0 and m>=1
    assert 0<=q<(1<<m) and 0<=t<(1<<m) and not((q|t)&1)
    constant=original_residuals(q,t,0,n)
    assert all(r%8==0 for r in constant), 'orientation fails direct original first parity'
    bits=[(r//8)&1 for r in constant]
    rows=[c<<(m-1) for c in bits]
    for i in range(1,m):
        values=original_residuals(q,t,1<<i,n)
        assert all(r%8==0 for r in values)
        for k,(r,c) in enumerate(zip(values,bits)):
            rows[k]^=(((r//8)&1)^c)<<(i-1)
    return rows


def rank_and_consistency(rows,variables):
    mask=(1<<variables)-1
    pivots={}
    inconsistent=False
    for row in rows:
        while row&mask:
            p=(row&mask).bit_length()-1
            if p in pivots:
                row^=pivots[p]
            else:
                pivots[p]=row
                break
        if not(row&mask) and (row>>variables)&1:
            inconsistent=True
    return len(pivots),not inconsistent


def independent_rank(vectors):
    pivots={}
    for vector in vectors:
        while vector:
            p=vector.bit_length()-1
            if p in pivots:
                vector^=pivots[p]
            else:
                pivots[p]=vector
                break
    return len(pivots)


def verify_descriptor(record,rows,variables,rank):
    part=record['sign_particular_bits_mask']
    kernel=record['sign_kernel_masks']
    assert type(part) is int and isinstance(kernel,list)
    assert all(type(v) is int for v in kernel)
    assert 0<=part<(1<<(variables+1)) and not(part&1)
    assert all(0<=v<(1<<(variables+1)) and not(v&1) for v in kernel)
    assert type(record['sign_nullity']) is int and record['sign_nullity']==len(kernel)==variables-rank
    part>>=1
    vectors=[v>>1 for v in kernel]
    assert independent_rank(vectors)==len(vectors), 'dependent exported sign basis'
    mask=(1<<variables)-1
    for row in rows:
        coeff=row&mask
        assert (coeff&part).bit_count()%2==((row>>variables)&1), 'invalid particular sign vector'
        assert all((coeff&v).bit_count()%2==0 for v in vectors), 'basis outside original kernel'
    return (record['sign_particular_bits_mask'],tuple(kernel))


def merge_intervals(intervals,total):
    merged=[]
    for start,end in sorted(intervals):
        assert 0<=start<=end<=total
        if start==end:
            continue
        if merged and start<=merged[-1][1]:
            merged[-1][1]=max(merged[-1][1],end)
        else:
            merged.append([start,end])
    return merged


def audit(n,orientation_paths,detail_paths,summary_paths=()):
    start=time.process_time()
    expected,provenance=read_orientation_files(orientation_paths,n)
    records={key:[] for key in expected}
    detail_provenance=[]
    for path in detail_paths:
        rows=strict_jsonl(path,allow_empty=True)
        for row in rows:
            if 'n' in row:
                assert type(row['n']) is int and row['n']==n
            key=(row['q_bits_mask'],row['t_bits_mask'])
            assert all(type(v) is int for v in key)
            assert key in expected, f'details contain unexpected orientation: {key}'
            records[key].append(row)
        detail_provenance.append({'path':str(path),'sha256':sha256(path),'records':len(rows)})
    summary_provenance=[]
    if summary_paths:
        input_by_hash={r['sha256']:r for r in provenance}
        detail_by_hash={r['sha256']:r for r in detail_provenance}
        matched=set()
        for path in summary_paths:
            summary=json.loads(path.read_text(),object_pairs_hook=unique_object)
            assert type(summary['n']) is int and summary['n']==n
            detail_hash=summary['details_sha256']
            assert detail_hash in detail_by_hash
            assert summary['input_sha256'] in input_by_hash
            assert summary['input_orientations']==input_by_hash[summary['input_sha256']]['orientation_records']
            matched.add(detail_hash)
            summary_provenance.append({'path':str(path),'sha256':sha256(path),'n':n,
                                       'details_sha256':detail_hash,'input_sha256':summary['input_sha256']})
        assert matched==set(detail_by_hash), 'a detail file lacks a matching summary provenance record'
    summaries=[]
    completed=0
    affine_rejected=0
    for (q,t),orientation in expected.items():
        rows=original_affine_rows(q,t,n)
        variables=n//2-1
        rank,consistent=rank_and_consistency(rows,variables)
        group={}
        evidence=records[(q,t)]
        if not consistent:
            assert evidence, 'no rejection record for inconsistent orientation'
            for row in evidence:
                assert row['sign_system_consistent'] is False
                assert row['status']=='SECOND_PARITY_INCONSISTENT'
            affine_rejected+=1
            completed+=1
            summaries.append({'q_bits_mask':q,'t_bits_mask':t,'affine_system':'INCONSISTENT',
                              'coverage':'COMPLETE_ORIENTATION_BY_AFFINE_CONTRADICTION'})
            continue
        d=variables-rank
        total=1<<d
        for row in evidence:
            assert row['sign_system_consistent'] is True
            key=verify_descriptor(row,rows,variables,rank)
            assert type(row['sign_space_size']) is int and row['sign_space_size']==total
            status=row['status']
            assert status in ('NOT_SEARCHED_KERNEL_BOUND','COMPLETE_NO_PAIR',
                              'PARTIAL_SIGN_INTERVAL','TIMEOUT'), 'positive/unknown status requires separate handling'
            if status=='NOT_SEARCHED_KERNEL_BOUND':
                continue
            begin=row['s_start']
            count=row['sign_assignments_examined']
            assert all(type(v) is int for v in (begin,count,row['s_end_exclusive']))
            end=begin+count
            assert 0<=count and end<=row['s_end_exclusive']<=total
            if status=='COMPLETE_NO_PAIR':
                assert begin==0 and end==total
            group.setdefault(key,[]).append((begin,end))
        covers=[]
        full=False
        for descriptor,intervals in group.items():
            merged=merge_intervals(intervals,total)
            this_full=merged==[[0,total]]
            full|=this_full
            covers.append({'particular_bits_mask':descriptor[0],'kernel_masks':list(descriptor[1]),
                           'declared_covered_intervals':merged,'complete_coordinate_space':this_full})
        if full:
            completed+=1
        summaries.append({'q_bits_mask':q,'t_bits_mask':t,'affine_system':'CONSISTENT',
                          'rank':rank,'nullity':d,'space_size':total,'coordinate_groups':covers,
                          'coverage':'COMPLETE_DECLARED_SIGN_SPACE' if full else 'INCOMPLETE_DECLARED_SIGN_SPACE'})
    return {'result':'PASS','audit_scope':'EXACT_AFFINE_SPACES_AND_DECLARED_INTERVAL_COVERAGE_ONLY',
            'n':n,'input_orientation_count':len(expected),'complete_declared_orientation_count':completed,
            'affine_contradictions_independently_verified':affine_rejected,
            'complete_declared_input_coverage':completed==len(expected),
            'original_sign_rejections_replayed':False,
            'global_first_stage_completeness_verified':False,
            'formal_kernel':False,
            'python_assertions_enabled':__debug__,
            'orientation_inputs':provenance,'detail_inputs':detail_provenance,
            'summary_provenance_linked':bool(summary_paths),'summary_inputs':summary_provenance,
            'orientations':summaries,'cpu_seconds':time.process_time()-start}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--n',type=int,required=True)
    parser.add_argument('--orientations',type=Path,action='append',required=True)
    parser.add_argument('--details',type=Path,action='append',required=True)
    parser.add_argument('--summary',type=Path,action='append',default=[])
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=audit(args.n,args.orientations,args.details,args.summary)
    result['auditor_source_sha256']=sha256(Path(__file__))
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('result','audit_scope','input_orientation_count',
                     'complete_declared_orientation_count','complete_declared_input_coverage','cpu_seconds')},indent=2))


if __name__=='__main__':
    main()
