"""Positive and exhaustive-negative calibration for direct sign replay."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from verify_independent import verify_pair


def require(ok,message):
    if not ok:raise ValueError(message)


def masks(A,B):
    A=[x*A[0] for x in A];B=[x*B[0] for x in B]
    if A[-1]==-1:A,B=B,A
    n=len(A);p=n//2
    require(A[0]==B[0]==A[-1]==1 and B[-1]==-1,'MODE P normalization')
    q=sum((int(A[i]!=B[i]))<<i for i in range(p))
    t=sum((int(A[i]!=A[n-1-i]))<<i for i in range(p))
    s=sum((int(A[i]<0))<<i for i in range(p))
    return q,t,s


def main():
    binary=ROOT/'src/verify_signs_direct'
    cases=[]
    fixtures=json.loads((ROOT/'tests/verify_fixtures.json').read_text())
    with tempfile.TemporaryDirectory(prefix='golay_direct_calibration_') as tmp:
        tmp=Path(tmp)
        for n in (2,10,26):
            fixture=next(x for x in fixtures if x['n']==n)
            q,t,s=masks(fixture['A'],fixture['B'])
            inp,out=tmp/f'positive{n}.txt',tmp/f'positive{n}.jsonl'
            inp.write_text(f'{n} 1\n{q} {t} {s} 0\n')
            run=subprocess.run([str(binary),str(inp),str(out),'10'],capture_output=True,text=True,timeout=15)
            require(run.returncode==0,'direct positive calibration crashed')
            rows=[json.loads(x) for x in out.read_text().splitlines()]
            require(rows[-1]['status']=='ORIGINAL_PAIR_FOUND','known positive was rejected')
            witness=next(x for x in rows if x['record_type']=='witness')
            verify=verify_pair(witness['A'],witness['B'],expected_n=n)
            require(verify['aperiodic_golay'],'direct known witness failed integer convolution')
            cases.append({'n':n,'case':'known_positive','result':'PASS','footer':rows[-1]})
        # n=6 has p=3. Enumerate every MODE P mirror-compatible pair:
        # all q/t tails and the complete two-bit s space for each orientation.
        n=6
        spaces=[(q<<1,t<<1,0,[2,4]) for q in range(4) for t in range(4)]
        inp,out=tmp/'negative6.txt',tmp/'negative6.jsonl'
        inp.write_text(f'{n} {len(spaces)}\n'+''.join(f'{q} {t} {s} 2 2 4\n' for q,t,s,_ in spaces))
        run=subprocess.run([str(binary),str(inp),str(out),'10'],capture_output=True,text=True,timeout=15)
        require(run.returncode==0,'direct negative calibration crashed')
        rows=[json.loads(x) for x in out.read_text().splitlines()]
        require(rows[-1]['status']=='COMPLETE_SUPPLIED_SPACES_NO_PAIR' and rows[-1]['total_assignments']==64,'negative exhaustive calibration failed')
        for q,t,_,basis in spaces:
            for mask in range(4):
                s=sum(((mask>>j)&1)*basis[j] for j in range(2))
                A=[0]*6;B=[0]*6
                for i in range(3):
                    A[i]=1-2*((s>>i)&1);B[i]=1-2*(((s^q)>>i)&1)
                    A[5-i]=1-2*(((s^t)>>i)&1);B[5-i]=2*(((s^q^t)>>i)&1)-1
                require(not verify_pair(A,B,expected_n=6)['aperiodic_golay'],'independent n6 calibration disagreement')
        cases.append({'n':6,'case':'all64_MODE_P_mirror_pairs','result':'PASS','footer':rows[-1]})
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    report={'status':'PASS','source_sha256':sha(ROOT/'src/verify_signs_direct.cpp'),
            'binary_sha256':sha(binary),'calibrator_sha256':sha(Path(__file__)),
            'independent_checker_sha256':sha(ROOT/'src/verify_independent.py'),'cases':cases}
    (ROOT/'results/verification_direct_sign_calibration.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':'PASS','positive_lengths':[2,10,26],'exhaustive_negative_pairs':64}))


if __name__=='__main__':main()
