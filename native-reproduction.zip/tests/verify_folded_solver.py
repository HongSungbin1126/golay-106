"""Independent coverage, original-equation, and fallback tests for folding."""

from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import random
import resource
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from algebra_orientation_fibers import (
    FiberSolver, affine_preimage, parity_output, reduce_span, span_basis,
)
from verify_independent import verify_pair


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def all_affine(particular, basis):
    out = []
    for bits in itertools.product((0, 1), repeat=len(basis)):
        value = particular
        for enabled, vector in zip(bits, basis):
            if enabled:
                value ^= vector
        out.append(value)
    require(len(out) == len(set(out)), "dependent alleged affine basis")
    return set(out)


def list_polynomial_product(a, b):
    out = [0] * (len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] ^= x*y
    return out


def list_remainder_j(coefficients, p):
    coefficients = coefficients[:]
    while len(coefficients) >= p:
        if coefficients[-1]:
            start = len(coefficients)-p
            for j in range(p):
                coefficients[start+j] ^= 1
        coefficients.pop()
    coefficients += [0]*(p-1-len(coefficients))
    return coefficients


def audit_orientation(q, t, p):
    require(q & 1 == 0 and t & 1 == 0, "MODE P violated")
    qb = [(q >> i) & 1 for i in range(p)]
    tb = [(t >> i) & 1 for i in range(p)]
    qs, ts = [1-2*x for x in qb], [1-2*x for x in tb]
    a = [1]*p + ts[::-1]
    b = qs + [-x*y for x, y in zip(qs, ts)][::-1]
    residuals = verify_pair(a, b)["residuals"]
    require(all(value % 8 == 0 for value in residuals), "first parity fails in original integer coordinates")
    H = [x^y for x, y in zip(qb, qb[::-1])]
    K = [x^y for x, y in zip(tb, tb[::-1])]
    product = [0] + list_polynomial_product(H, [x^y for x, y in zip(H,K)])
    require(list_remainder_j(product, p) == [1]+[0]*(p-2), "folded inverse identity fails")


class ToyQuadratic(FiberSolver):
    """Exercise the general elimination loop on independent small MQ maps."""
    def __init__(self, d, constant, linear, quadratic):
        super().__init__(3, time.process_time()+30)
        self.d, self.constant, self.linear, self.quadratic = d, constant, linear, quadratic

    def evaluate(self, q, t):
        self.stats["parity_evaluations"] += 1
        value = self.constant
        for i, coefficient in enumerate(self.linear):
            if (q >> i) & 1:
                value ^= coefficient
        for i, j, coefficient in self.quadratic:
            if ((q >> i) & 1) and ((q >> j) & 1):
                value ^= coefficient
        return value


def main():
    resource.setrlimit(resource.RLIMIT_CPU, (120, 125))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    begin, wall = time.process_time(), time.monotonic()
    child_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    rng = random.Random(2026110503)
    counts = Counter()

    for d in range(7):
        for _ in range(30):
            columns = [rng.randrange(128) for _ in range(d)]
            target = rng.randrange(128)
            expected = set()
            for mask in range(1 << d):
                image = 0
                for i, column in enumerate(columns):
                    if mask & (1 << i):
                        image ^= column
                if image == target:
                    expected.add(mask)
            result = affine_preimage(columns, target)
            actual = set() if result is None else all_affine(*result)
            require(actual == expected, "affine-preimage coverage mismatch")
            counts["affine_preimage_exhaustive_comparisons"] += 1
            basis = span_basis(columns)
            actual_kernel = {v for v in range(128) if reduce_span(v, basis) == 0}
            expected_kernel = {0}
            for column in columns:
                expected_kernel |= {v ^ column for v in tuple(expected_kernel)}
            require(actual_kernel == expected_kernel, "projection kernel mismatch")
            for _ in range(5):
                x, y = rng.randrange(128), rng.randrange(128)
                require(reduce_span(x^y,basis) == reduce_span(x,basis)^reduce_span(y,basis),
                        "quotient reduction is not linear")
            counts["projection_kernel_and_linearity_cases"] += 1

    branch_nodes = 0
    cases = [(2, 0, [0,0], [(0,1,1)]), (2, 1, [0,0], [(0,1,1)])]
    for d in range(1, 6):
        for _ in range(12):
            cases.append((d, rng.randrange(8), [rng.randrange(8) for _ in range(d)],
                          [(i,j,rng.randrange(8)) for i in range(d) for j in range(i)]))
    for d, c, linear, quadratic in cases:
        solver = ToyQuadratic(d,c,linear,quadratic)
        expected = {x for x in range(1 << d) if solver.evaluate(x,0) == 0}
        found = list(solver.solve_affine_space((0,0), [(1 << i,0) for i in range(d)]))
        require(all(t == 0 for _, t in found), "toy parameter escape")
        require(len(found) == len(set(found)) and {q for q,_ in found} == expected,
                "ElimLin/branching coverage mismatch")
        branch_nodes += solver.stats["branch_nodes"]
        counts["quadratic_maps_exhaustively_compared"] += 1
    require(branch_nodes > 0, "branch fallback was never exercised")

    for p in (3,5,7):
        expected = {(q << 1,t << 1) for q in range(1 << (p-1)) for t in range(1 << (p-1))
                    if parity_output(q << 1,t << 1,p) == 0}
        solver = FiberSolver(p,time.process_time()+30)
        found = [pair for h in range(1 << ((p-1)//2)) for pair in solver.solve_h(h)]
        require(len(found) == len(set(found)) and set(found) == expected,
                "folded MODE P coverage mismatch")
        for q,t in found:
            audit_orientation(q,t,p)
        counts[f"complete_p{p}_orientations"] = len(found)

    reference_path = ROOT/"results/algebra_native_fiber_crosscheck_n106.json"
    reference = json.loads(reference_path.read_text())
    require(reference["status"] == "PASS", "upstream sampled comparison incomplete")
    for item in reference["checks"]:
        for q,t in item["orientations"]:
            audit_orientation(q,t,53)
            counts["n106_orientations_checked_against_original_convolution"] += 1

    # A few complete fibers from the dispersed reference, including positive
    # fibers, also check the current v2 binary rather than merely its old report.
    native = ROOT/"src/exact_orientation_fibers_v2"
    selected = []
    positive = [item for item in reference["checks"] if item["orientations"]]
    selected.extend(positive[:3])
    selected.extend(reference["checks"][-3:])
    selected = list({item["h"]:item for item in selected}.values())
    native_records = []
    with tempfile.TemporaryDirectory(prefix="verify_fibers_",dir=ROOT/"results") as directory:
        directory = Path(directory)
        for item in selected:
            output, trace = directory/"run.json", directory/"orientations.jsonl"
            command = [str(native),"--p","53","--h-start",str(item["h"]),"--h-limit","1",
                       "--seconds","3","--output",str(output),"--orientations",str(trace)]
            proc = subprocess.run(command, capture_output=True, text=True, timeout=5)
            require(proc.returncode == 0, "native sample process failed: "+proc.stderr)
            report = json.loads(output.read_text())
            require(report["status"] == "COMPLETE_H_PARTITION" and report["H_completed"] == 1,
                    "native sample coverage incomplete")
            rows = [json.loads(line) for line in trace.read_text().splitlines()]
            observed = sorted((r["q_bits_mask"],r["t_bits_mask"]) for r in rows
                              if r["record_type"] == "orientation")
            require(observed == sorted(map(tuple,item["orientations"])), "native v2 fiber mismatch")
            native_records.append({"h":item["h"],"orientations":observed,"status":"PASS"})

    require(pow(2,26,53) == 52 and pow(2,4,53) != 1, "order-52 arithmetic fails")
    report = {"date":"2026-11-05","result":"PASS","counts":dict(counts),
              "branch_fallback_nodes_exercised":branch_nodes,
              "native_v2_selected_fibers":native_records,
              "prior_crosscheck_fibers":reference["distinct_fibers"],
              "prior_crosscheck_sha256":hashlib.sha256(reference_path.read_bytes()).hexdigest(),
              "native_v2_sha256":hashlib.sha256(native.read_bytes()).hexdigest(),
              "native_v2_source_sha256":hashlib.sha256((ROOT/"src/exact_orientation_fibers_v2.cpp").read_bytes()).hexdigest(),
              "python_solver_source_sha256":hashlib.sha256((ROOT/"src/algebra_orientation_fibers.py").read_bytes()).hexdigest(),
              "test_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "cpu_seconds":time.process_time()-begin,"wall_seconds":time.monotonic()-wall,
              "child_cpu_seconds":(resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime-child_before.ru_utime
                                   +resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime-child_before.ru_stime),
              "peak_memory_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
              "scope":"Exact small-domain and selected-fiber validation; no complete n106 enumeration or Golay claim."}
    (ROOT/"results/verification_folded_solver.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
