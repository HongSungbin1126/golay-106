"""Bounded adversarial tests for the independent Laurent checker.

Bootstrap seed literals and construction functions are selected from its AST.
No bootstrap autocorrelation/scoring/verifier function is imported or run.
"""

from __future__ import annotations

import ast
import hashlib
import itertools
import json
from pathlib import Path
import random
import resource
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from verify_independent import (  # noqa: E402
    _signs, known_length_witness, load_candidate, polynomial_product, verify_pair,
)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def fixture_sources():
    path = ROOT / "src/golay_bootstrap.py"
    tree = ast.parse(path.read_text())
    seeds = None
    constructors = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "SEEDS"
            for target in node.targets
        ):
            seeds = ast.literal_eval(node.value)
        if isinstance(node, ast.FunctionDef) and node.name in {"double_pair", "multiply_pairs"}:
            constructors.append(node)
    require(seeds is not None, "bootstrap seed literals not found")

    def input_check(a, b):
        aa, bb = _signs(a, "A"), _signs(b, "B")
        if len(aa) != len(bb):
            raise ValueError("unequal fixture lengths")

    namespace = {"validate_pair": input_check}
    # Compile only the two constructors. The bootstrap correlation routines
    # are absent from the code object and the namespace.
    exec(compile(ast.Module(body=constructors, type_ignores=[]), str(path), "exec"), namespace)
    require("ac" not in namespace and "verify" not in namespace, "independence breach")
    return seeds, namespace["multiply_pairs"], namespace["double_pair"]


def main():
    resource.setrlimit(resource.RLIMIT_CPU, (300, 301))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    start_wall, start_cpu = time.monotonic(), time.process_time()
    checks = 0
    seeds, multiply, double = fixture_sources()
    fixtures = []
    lengths = set()
    for n, (a, b) in sorted(seeds.items()):
        require(len(a) == len(b) == n, "incorrect seed length")
        fixtures.append({"name": f"bootstrap-seed-{n}", "n": n, "A": a, "B": b})
    for m, n in itertools.product(sorted(seeds), repeat=2):
        a, b = multiply(*seeds[m], *seeds[n])
        fixtures.append({"name": f"bootstrap-product-{m}-{n}", "n": m*n, "A": a, "B": b})
    for n in (2, 4, 8, 16, 32, 64):
        a, b = seeds[1]
        while len(a) < n:
            a, b = double(a, b)
        fixtures.append({"name": f"bootstrap-doubling-{n}", "n": n, "A": a, "B": b})
    fixture_results = []
    for fixture in fixtures:
        a, b, n = fixture["A"], fixture["B"], fixture["n"]
        result = verify_pair(a, b, n)
        require(result["aperiodic_golay"], f"invalid fixture: {fixture['name']}")
        require(result["energy"] == 0 and not result["failed_coefficients"], "acceptance inconsistency")
        require(result["diagnostics"]["row_sum_squares_equal_2n"], "row identity failure")
        require(result["diagnostics"]["alternating_sum_squares_equal_2n"], "alternating identity failure")
        if n % 2 == 0:
            require(result["diagnostics"]["mirror_constraint_holds_even_n"], "mirror failure")
        checks += 1
        lengths.add(n)
        fixture_results.append({
            "name": fixture["name"], "n": n, "candidate_sha256": result["candidate_sha256"],
            "status": "EXACT_VALID_PAIR_AT_KNOWN_LENGTH",
        })
        # Transformations are deliberately not imported from search code.
        if n <= 104:
            variants = [
                (b, a), ([-v for v in a], b), (a, [-v for v in b]),
                (list(reversed(a)), b), (a, list(reversed(b))),
                ([v if i % 2 == 0 else -v for i, v in enumerate(a)],
                 [v if i % 2 == 0 else -v for i, v in enumerate(b)]),
            ]
            for aa, bb in variants:
                require(verify_pair(aa, bb)["aperiodic_golay"], "target-preserving symmetry rejected")
                checks += 1

    # Exhaustive normalized domain through n=8: positive first symbols are
    # obtained by independent global negation, so existence coverage is full.
    normalized_counts = {}
    for n in range(1, 9):
        seqs = [(1,) + tail for tail in itertools.product((-1, 1), repeat=n-1)]
        polys = [polynomial_product(list(a), list(reversed(a))) for a in seqs]
        count = 0
        for i, j in itertools.product(range(len(seqs)), repeat=2):
            total = [x+y for x, y in zip(polys[i], polys[j])]
            ok = all(value == (2*n if k == n-1 else 0) for k, value in enumerate(total))
            if not ok:
                continue
            count += 1
            result = verify_pair(seqs[i], seqs[j], n)
            require(result["aperiodic_golay"], "exhaustive checker disagreement")
            if n % 2 == 0:
                require(result["diagnostics"]["mirror_constraint_holds_even_n"], "exhaustive mirror counterexample")
            checks += 1
        normalized_counts[n] = count
        require((count > 0) == (n in {1, 2, 4, 8}), "incorrect tiny existence classification")
        checks += 1

    # Exact tiny polynomial hand calculations, including a trap where the
    # ordinary n-point periodic test would accept an invalid aperiodic pair.
    require(polynomial_product([1, 2], [3, 4]) == [3, 10, 8], "convolution convention")
    require(verify_pair([1], [-1])["combined_polynomial_coefficients"] == [2], "length-one convention")
    a = [1, 1, 1, -1]
    shifted = verify_pair(a, a)
    require(shifted["residuals"] == [2, 0, -2], "periodic trap residuals")
    require(not shifted["aperiodic_golay"] and shifted["energy"] == 8, "periodic trap accepted")
    require(all(shifted["residuals"][k-1] + shifted["residuals"][3-k] == 0 for k in range(1, 4)), "periodic trap malformed")
    checks += 5

    # Rows and alternating sums can satisfy the n106 necessary conditions
    # while the original equations fail. Such a candidate must be rejected.
    a_even = [-1]*22 + [1]*31
    a_odd = [-1]*24 + [1]*29
    b_even = [-1]*22 + [1]*31
    b_odd = [-1]*29 + [1]*24
    a = [v for pair in zip(a_even, a_odd) for v in pair]
    b = [v for pair in zip(b_even, b_odd) for v in pair]
    row_trap = verify_pair(a, b, 106)
    require(row_trap["diagnostics"]["row_sum_squares_equal_2n"], "row trap malformed")
    require(row_trap["diagnostics"]["alternating_sum_squares_equal_2n"], "alternating trap malformed")
    require(row_trap["diagnostics"]["mode_r106_block_sums"], "normalization trap malformed")
    require(not row_trap["aperiodic_golay"], "necessary conditions used as acceptance")
    checks += 1

    # Known-length membership is tested by an independently generated finite
    # set, not by the bootstrap's factor-exponent predicate.
    generated_lengths = {2**a * 10**b * 26**c for a in range(13) for b in range(4) for c in range(3)
                         if 2**a * 10**b * 26**c <= 4096}
    for n in range(1, 4097):
        witness = known_length_witness(n)
        require((witness is not None) == (n in generated_lengths), "known-set mismatch")
        if witness is not None:
            require(2**witness["a"] * 10**witness["b"] * 26**witness["c"] == n, "invalid semigroup witness")
        checks += 1

    # Enumerate only scalar necessary equations, not sequences at n106.
    row_pairs = [(u, v) for u in range(0, 107, 2) for v in range(0, u+1, 2)
                 if u*u + v*v == 212]
    require(row_pairs == [(14, 4)], "n106 rows")
    alt_branches = []
    for t, u in itertools.product(range(-106, 107, 2), repeat=2):
        if t*t + u*u != 212:
            continue
        partial = ((14+t)//2, (14-t)//2, (4+u)//2, (4-u)//2)
        if all(-53 <= s <= 53 and s % 2 == 1 for s in partial):
            alt_branches.append((t, u))
    require(alt_branches == [(-4, -14), (-4, 14), (4, -14), (4, 14)], "n106 alternating branches")
    checks += 2

    invalid_inputs = [([], []), ([1], [1, -1]), ([True], [1]), ([1.0], [1]),
                      ([0], [1]), ([1j], [1]), ("+", [1]), ([1], None)]
    for aa, bb in invalid_inputs:
        try:
            verify_pair(aa, bb)
        except ValueError:
            checks += 1
        else:
            raise AssertionError("invalid alphabet/shape accepted")
    for bad_n in (True, 1.0, 0, -1, 2):
        try:
            verify_pair([1], [1], bad_n)
        except ValueError:
            checks += 1
        else:
            raise AssertionError("invalid expected_n accepted")
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "duplicate-key.json"
        path.write_text('{"n":1,"n":2,"A":[1],"B":[1]}')
        try:
            load_candidate(path)
        except ValueError:
            checks += 1
        else:
            raise AssertionError("ambiguous duplicate JSON key accepted")

    # Random arbitrary pairs test invariant diagnostics without presupposing
    # complementarity; negative coefficients and both Laurent sides matter.
    rng = random.Random(11052026)
    for n in (3, 7, 16, 26, 53, 106):
        for _ in range(10):
            aa, bb = [[rng.choice((-1, 1)) for _ in range(n)] for _ in range(2)]
            result = verify_pair(aa, bb)
            coeff = result["combined_polynomial_coefficients"]
            require(coeff == coeff[::-1] and coeff[n-1] == 2*n, "Laurent symmetry/constant term")
            require(sum(coeff) == sum(aa)**2 + sum(bb)**2, "evaluation at z=1")
            require(sum((-1)**i * value for i, value in enumerate(coeff)) ==
                    (-1)**(n-1) * ((sum(aa[::2])-sum(aa[1::2]))**2 +
                                    (sum(bb[::2])-sum(bb[1::2]))**2), "evaluation at z=-1")
            checks += 1

    report = {
        "status": "PASS", "date": "2026-11-05", "checks": checks,
        "method": "independent exact integer polynomial convolution",
        "imports_bootstrap_correlations": False,
        "bootstrap_code_reuse": "seed literals and constructors only, selected AST; no scoring code",
        "verified_fixture_count": len(fixtures), "verified_fixture_lengths": sorted(lengths),
        "fixtures": fixture_results,
        "exhaustive_normalized_pair_counts_n_le_8": normalized_counts,
        "periodic_trap_energy": shifted["energy"],
        "n106_row_condition_trap_energy": row_trap["energy"],
        "n106_row_pairs": row_pairs, "n106_alternating_branches": alt_branches,
        "cpu_seconds": time.process_time()-start_cpu,
        "wall_seconds": time.monotonic()-start_wall,
        "peak_memory_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        "worker_count": 1, "cpu_limit_seconds": 300, "ram_limit_bytes": 1024**3,
        "checker_sha256": hashlib.sha256((ROOT / "src/verify_independent.py").read_bytes()).hexdigest(),
        "test_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "allowed_conclusion": "CHECKER_REGRESSIONS_PASSED; NO_NEW_OPEN_LENGTH_RESULT",
    }
    (ROOT / "tests/verify_fixtures.json").write_text(json.dumps(fixtures, indent=2)+"\n")
    (ROOT / "results/verification_initial.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
