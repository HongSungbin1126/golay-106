"""Negative tests for the compact checker; run only in an allocated compute slot."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('character_checker',ROOT/'src/exact_sign_character_certificate_check.py')
checker=importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


def main():
    source=ROOT/'results/algebra_sign_character_reductions.json'
    spaces=ROOT/'results/exact_signs_n106_campaign_kernel_inventory.jsonl'
    audit=ROOT/'results/campaign_n106_sign_space_audit.json'
    witnesses=ROOT/'results/algebra_mod32_witnesses.json'
    original=json.loads(source.read_text())
    report=checker.check(106,spaces,source,audit,witnesses)
    assert report['result']=='PASS' and report['spaces_checked']==8
    assert report['mod32_witness_validation']['verified_mod32_pairs']==8
    variants=[]
    def variant(name,change):
        value=copy.deepcopy(original)
        change(value)
        variants.append((name,value))
    variant('changed_gcd',lambda c:c['spaces'][0]['stages'][0]['equations'][0].update(coefficient_gcd=16))
    variant('changed_linear_rhs',lambda c:c['spaces'][1]['stages'][0]['equations'][9].update(rhs=0))
    variant('false_xor_provenance',lambda c:c['spaces'][1]['stages'][0]['affine_solution'].update(contradiction_equation_indices=[9,10]))
    variant('omitted_free_direction',lambda c:c['spaces'][0]['stages'][0]['affine_solution'].update(kernel=[299593],rank=19))
    variant('changed_substitution',lambda c:c['spaces'][0]['stages'][1].update(sign_particular_bits_mask=0))
    variant('changed_terminal_sign',lambda c:c['spaces'][2]['stages'][0]['contradiction'].update(primitive_terms=[[10,-1]]))
    variant('omitted_initial_space',lambda c:c['spaces'].pop())
    rejected=[]
    with tempfile.TemporaryDirectory(prefix='golay_character_mutations_') as scratch:
        for name,value in variants:
            path=Path(scratch)/(name+'.json')
            path.write_text(json.dumps(value)+'\n')
            try:
                checker.check(106,spaces,path,audit)
            except (AssertionError,ValueError,KeyError):
                rejected.append(name)
            else:
                raise AssertionError(f'unsound mutation accepted: {name}')
        wrong_witness=json.loads(witnesses.read_text())
        wrong_witness['rows'][0]['A'][1]*=-1
        path=Path(scratch)/'changed_original_witness.json'
        path.write_text(json.dumps(wrong_witness)+'\n')
        try:
            checker.check(106,spaces,source,audit,path)
        except (AssertionError,ValueError,KeyError):
            rejected.append('changed_original_witness')
        else:
            raise AssertionError('incorrect original witness accepted')
    result={'result':'PASS','positive_certificate_spaces':8,'mutations_rejected':rejected,
            'checker_source_sha256':checker.digest(ROOT/'src/exact_sign_character_certificate_check.py')}
    (ROOT/'results/exact_sign_character_certificate_mutations.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
