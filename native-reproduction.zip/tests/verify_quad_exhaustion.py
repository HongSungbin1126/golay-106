"""Independent exact quad replay with finite GF(2) rejection certificates.

This Python implementation is written from the audited equations, not imported
from the C++ solver. It uses full reduced row echelon elimination, provenance
combinations of input equations, lexicographic affine enumeration, and the
independent polynomial checker on every remaining sign assignment. No row-sum
prefilter is used. The --check mode verifies certificate coverage without
running Gaussian elimination or trusting the original solver's UNSAT report.

The trusted base remains Python integer arithmetic, the reduction proof, and
this source; this is not a proof in a formal theorem-prover kernel.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path
import resource
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from verify_independent import verify_pair  # noqa: E402

FORMAT = "audited_quad_rejection_certificate_v1"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sign_vector(tail, m):
    return [1] + [-1 if tail & (1 << j) else 1 for j in range(m - 1)]


def reconstruct(q, t, s):
    m = len(q)
    a, b = [0] * (2*m), [0] * (2*m)
    for i in range(m):
        a[i] = s[i]
        b[i] = s[i] * q[i]
        a[2*m-1-i] = t[i] * s[i]
        b[2*m-1-i] = -t[i] * s[i] * q[i]
    return a, b


def edge_groups(q):
    """Partition unordered quad pairs by their only possibly nonzero lag."""
    m = len(q)
    groups = [[] for _ in range(2*m-1)]
    for i, j in itertools.combinations(range(m), 2):
        equal_q = q[i] == q[j]
        lag = j-i if equal_q else 2*m-1-i-j
        variables = (0 if i == 0 else 1 << (i-1)) | (1 << (j-1))
        groups[lag-1].append((i, j, equal_q, variables))
    return groups


def first_equations(groups):
    equations = []
    for group in groups:
        mask = 0
        for _, _, _, variables in group:
            mask ^= variables
        equations.append((mask, len(group) % 2))
    return equations


def second_equations(groups, t):
    equations = []
    for group in groups:
        mask, total = 0, 0
        for i, j, equal_q, variables in group:
            if t[i] != t[j]:
                continue
            mask ^= variables
            total += 1 if equal_q else t[i]
        require(total % 2 == 0, "first reduction failed to guarantee even signed sums")
        equations.append((mask, (total // 2) % 2))
    return equations


def rref_proof(equations, variables):
    """Full row reduction, retaining a combination of original rows per row."""
    rows = [[mask, rhs, 1 << i] for i, (mask, rhs) in enumerate(equations)]
    for mask, rhs, provenance in rows:
        if mask == 0 and rhs:
            return {"contradiction": provenance}
    pivots, used = [], 0
    for column in reversed(range(variables)):
        bit = 1 << column
        selected = next((j for j in range(used, len(rows)) if rows[j][0] & bit), None)
        if selected is None:
            continue
        rows[used], rows[selected] = rows[selected], rows[used]
        pm, pr, pp = rows[used]
        for j in range(len(rows)):
            if j == used or not (rows[j][0] & bit):
                continue
            rows[j][0] ^= pm
            rows[j][1] ^= pr
            rows[j][2] ^= pp
            if rows[j][0] == 0 and rows[j][1]:
                return {"contradiction": rows[j][2]}
        pivots.append(column)
        used += 1
    return {"pivots": pivots, "rows": rows[:used]}


def affine_description(proof, variables):
    particular = 0
    pivots = proof["pivots"]
    for pivot, (_, rhs, _) in zip(pivots, proof["rows"]):
        if rhs:
            particular |= 1 << pivot
    basis = []
    for free in range(variables):
        if free in pivots:
            continue
        vector = 1 << free
        for pivot, (mask, _, _) in zip(pivots, proof["rows"]):
            if mask & (1 << free):
                vector |= 1 << pivot
        basis.append(vector)
    return particular, basis


def assignments(proof, variables):
    particular, basis = affine_description(proof, variables)
    for choice in itertools.product((0, 1), repeat=len(basis)):
        value = particular
        for selected, vector in zip(choice, basis):
            if selected:
                value ^= vector
        yield value


def check_reduction(equations, proof, variables):
    """Check row-space certificates, without invoking an elimination solver."""
    def combination(selector):
        require(type(selector) is int and 0 <= selector < (1 << len(equations)), "bad provenance")
        mask, rhs = 0, 0
        for i, (mi, ri) in enumerate(equations):
            if selector & (1 << i):
                mask ^= mi
                rhs ^= ri
        return mask, rhs

    if "contradiction" in proof:
        require(combination(proof["contradiction"]) == (0, 1), "invalid zero-equals-one certificate")
        return False
    pivots, rows = proof["pivots"], proof["rows"]
    require(len(pivots) == len(rows) and len(set(pivots)) == len(pivots), "bad pivots")
    for j, (pivot, row) in enumerate(zip(pivots, rows)):
        require(type(pivot) is int and 0 <= pivot < variables, "pivot out of range")
        mask, rhs, provenance = row
        require(type(mask) is int and 0 <= mask < (1 << variables), "bad coefficient mask")
        require(type(rhs) is int and rhs in (0, 1), "bad RHS")
        require(combination(provenance) == (mask, rhs), "derived row not justified")
        require(mask & (1 << pivot), "missing pivot")
        for k, other_pivot in enumerate(pivots):
            require(k == j or not (mask & (1 << other_pivot)), "matrix not reduced on pivots")
    # Reverse inclusion of row spaces proves no original equation was dropped.
    for original_mask, original_rhs in equations:
        mask, rhs = original_mask, original_rhs
        for pivot, (derived_mask, derived_rhs, _) in zip(pivots, rows):
            if mask & (1 << pivot):
                mask ^= derived_mask
                rhs ^= derived_rhs
        require((mask, rhs) == (0, 0), "uncovered original equation")
    return True


def check_certificate(certificate):
    begin = time.process_time()
    require(certificate.get("format") == FORMAT, "wrong certificate format")
    n = certificate.get("n")
    require(type(n) is int and 2 <= n <= 36 and n % 2 == 0, "unsupported certificate size")
    require(certificate.get("normalization") == "MODE_P", "wrong normalization")
    m, variables = n//2, n//2-1
    records = certificate.get("q_records")
    require(isinstance(records, list) and len(records) == 1 << variables, "incomplete q coverage")
    checked_t, checked_s = 0, 0
    for q_index, record in enumerate(records):
        q = sign_vector(q_index, m)
        groups = edge_groups(q)
        first = first_equations(groups)
        if not check_reduction(first, record["t_reduction"], variables):
            continue
        t_values = list(assignments(record["t_reduction"], variables))
        require(len(record["t_cases"]) == len(t_values), "missing t assignments")
        for t_value, t_case in zip(t_values, record["t_cases"]):
            require(t_case["assignment"] == t_value, "wrong t order/coverage")
            checked_t += 1
            t = sign_vector(t_value, m)
            second = second_equations(groups, t)
            if not check_reduction(second, t_case["s_reduction"], variables):
                continue
            s_values = list(assignments(t_case["s_reduction"], variables))
            require(len(t_case["rejections"]) == len(s_values), "missing s assignments")
            for s_value, rejection in zip(s_values, t_case["rejections"]):
                # Replay just a nonzero original equation. This uses signed
                # direct products rather than the generator's convolution.
                require(rejection[0] == s_value, "wrong s order/coverage")
                lag, submitted = rejection[1:]
                require(type(lag) is int and 1 <= lag < n, "invalid rejecting lag")
                a, b = reconstruct(q, t, sign_vector(s_value, m))
                actual = sum(a[i]*a[i+lag] + b[i]*b[i+lag] for i in range(n-lag))
                require(type(submitted) is int and actual == submitted and actual != 0,
                        "candidate not refuted by claimed original equation")
                checked_s += 1
    return {
        "result": "PASS", "n": n, "q_orientations_covered": len(records),
        "t_assignments_checked": checked_t, "s_rejections_checked": checked_s,
        "cpu_seconds": time.process_time()-begin,
        "claim": "AUDITED_FINITE_NONEXISTENCE_CERTIFICATE_CHECKED",
        "formal_kernel": False,
        "trusted_base": ["Python integer arithmetic", "audited quad/parity reduction", "checker source"],
        "novelty": "known fixed-length result reproduced; no new open-length theorem",
    }


def generate(n, cpu_budget):
    require(type(n) is int and 2 <= n <= 36 and n % 2 == 0, "even 2<=n<=36 required")
    begin = time.process_time()
    m, variables = n//2, n//2-1
    records = []
    counts = {"q_with_consistent_t_system": 0, "t_assignments_examined": 0,
              "t_with_consistent_s_system": 0, "sign_assignments_examined": 0,
              "row_norm_failures_observed_without_pruning": 0}
    t_nullity, s_nullity = {}, {}
    for q_index in range(1 << variables):
        if q_index % 256 == 0 and time.process_time()-begin > cpu_budget:
            return {"result": "NO_CONCLUSION", "reason": "CPU_BUDGET", "q_completed": len(records)}, None
        q = sign_vector(q_index, m)
        groups = edge_groups(q)
        t_proof = rref_proof(first_equations(groups), variables)
        record = {"t_reduction": t_proof}
        if "contradiction" in t_proof:
            records.append(record)
            continue
        counts["q_with_consistent_t_system"] += 1
        nullity = variables-len(t_proof["pivots"])
        t_nullity[nullity] = t_nullity.get(nullity, 0)+1
        record["t_cases"] = []
        for t_value in assignments(t_proof, variables):
            counts["t_assignments_examined"] += 1
            t = sign_vector(t_value, m)
            s_proof = rref_proof(second_equations(groups, t), variables)
            t_case = {"assignment": t_value, "s_reduction": s_proof}
            record["t_cases"].append(t_case)
            if "contradiction" in s_proof:
                continue
            counts["t_with_consistent_s_system"] += 1
            nullity = variables-len(s_proof["pivots"])
            s_nullity[nullity] = s_nullity.get(nullity, 0)+1
            t_case["rejections"] = []
            for s_value in assignments(s_proof, variables):
                counts["sign_assignments_examined"] += 1
                a, b = reconstruct(q, t, sign_vector(s_value, m))
                verdict = verify_pair(a, b, n)
                if verdict["aperiodic_golay"]:
                    return {"result": "SAT", "n": n, "A": a, "B": b,
                            "candidate_sha256": verdict["candidate_sha256"], **counts}, None
                if not verdict["diagnostics"]["row_sum_squares_equal_2n"]:
                    counts["row_norm_failures_observed_without_pruning"] += 1
                lag = next(k for k, value in enumerate(verdict["residuals"], 1) if value)
                t_case["rejections"].append([s_value, lag, verdict["residuals"][lag-1]])
        records.append(record)
    certificate = {"format": FORMAT, "n": n, "normalization": "MODE_P", "q_records": records}
    return {
        "result": "EXHAUSTION_COMPLETE_NO_PAIR", "n": n, "q_completed": len(records),
        "q_total": 1 << variables, **counts, "t_nullity_histogram": t_nullity,
        "s_nullity_histogram": s_nullity, "generation_cpu_seconds": time.process_time()-begin,
    }, certificate


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--n", type=int)
    ap.add_argument("--check", type=Path)
    ap.add_argument("--cpu-seconds", type=int, default=240)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--certificate", type=Path)
    args = ap.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU, (args.cpu_seconds, args.cpu_seconds+1))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    begin_wall, begin_cpu = time.monotonic(), time.process_time()
    if args.check:
        raw = args.check.read_bytes()
        report = check_certificate(json.loads(raw))
        report["certificate_sha256"] = hashlib.sha256(raw).hexdigest()
    else:
        report, certificate = generate(args.n, args.cpu_seconds * 0.65)
        if certificate is not None:
            require(args.certificate is not None, "--certificate required for exhaustive run")
            encoded = json.dumps(certificate, sort_keys=True, separators=(",", ":")).encode()
            args.certificate.write_bytes(encoded)
            # Deserialize to verify the artifact actually written, not an
            # in-memory object accidentally differing from the certificate.
            report["certificate_check"] = check_certificate(json.loads(args.certificate.read_bytes()))
            report["certificate_path"] = str(args.certificate)
            report["certificate_sha256"] = hashlib.sha256(encoded).hexdigest()
            report["certificate_bytes"] = len(encoded)
    report.update({
        "date": "2026-11-05", "wall_seconds": time.monotonic()-begin_wall,
        "total_cpu_seconds": time.process_time()-begin_cpu,
        "peak_memory_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        "implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "independent_pair_checker_sha256": hashlib.sha256((ROOT / "src/verify_independent.py").read_bytes()).hexdigest(),
        "formal_kernel": False, "target_conjecture_status": "STILL_OPEN",
    })
    args.output.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
