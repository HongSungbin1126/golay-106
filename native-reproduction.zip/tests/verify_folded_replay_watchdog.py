"""Independent resource watchdog for the pinned replay executable only.

This does not alter the frozen search controller or solver. It inspects only
readable process metadata and never attempts to bypass inaccessible /proc data.
It supplements completed native reports with live CPU for processes whose
command's first argument exactly matches the campaign's private executable.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import time

from verify_folded_independent_calibration import publish_bytes

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/campaign_n106_first_parity_independent'
config=json.loads((OUT/'configuration.json').read_text())
private=Path(config['private_raw_directory'])
binary=str(private/'solver').encode()
ticks=os.sysconf('SC_CLK_TCK')
stop_at=7000.0  # Reserve 200 aggregate CPU seconds below the allocated hard cap.
started=time.time()
monitor_cpu_started=time.process_time()
maximum_seen=0.0
last_report=0.0
source_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

while True:
    consumed={}
    for report in private.glob('h*.json'):
        try:
            value=json.loads(report.read_text())
            consumed[value['h_start']]=max(consumed.get(value['h_start'],0),value['cpu_seconds'])
        except (OSError,ValueError,KeyError):
            continue
    live=[]
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():
            continue
        try:
            args=(process/'cmdline').read_bytes().split(b'\0')
            if not args or args[0]!=binary:
                continue
            index=args.index(b'--h-start')
            h=int(args[index+1])
            fields=(process/'stat').read_text().rsplit(')',1)[1].split()
            cpu=(int(fields[11])+int(fields[12]))/ticks
            consumed[h]=max(consumed.get(h,0),cpu)
            live.append({'pid':int(process.name),'h_start':h,'cpu_seconds':cpu})
        except (OSError,ValueError,IndexError):
            continue
    measured=sum(consumed.values())
    maximum_seen=max(maximum_seen,measured)
    try:
        state=json.loads((OUT/'campaign_state.json').read_text())
        finished=state['status'] in ('COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY','INCOMPLETE')
    except (OSError,ValueError,KeyError):
        finished=False
    stopped=[]
    if measured>=stop_at:
        for process in live:
            pid=process['pid']
            # Recheck identity immediately before signaling to guard PID reuse.
            try:
                if (Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0')[0]==binary:
                    os.kill(pid,signal.SIGTERM)
                    stopped.append(pid)
            except (OSError,ProcessLookupError):
                pass
    if time.time()-last_report>=10 or finished or stopped:
        report={'scope':'RESOURCE_MONITOR_ONLY','source_sha256':source_hash,
                'private_binary':binary.decode(),'native_plus_live_cpu_seconds':measured,
                'maximum_observed_cpu_seconds':maximum_seen,'stop_threshold_cpu_seconds':stop_at,
                'live_matching_processes':live,'completed_native_reports':len(list(private.glob('h*.json'))),
                'monitor_cpu_seconds':time.process_time()-monitor_cpu_started,
                'wall_seconds':time.time()-started,'campaign_finished':finished,'terminated_pids':stopped,
                'unreadable_proc_policy':'skip; no access-control bypass attempted'}
        publish_bytes(OUT/'resource_watchdog.json',(json.dumps(report,indent=2)+'\n').encode())
        print(json.dumps({'cpu_seconds':measured,'live_processes':len(live),'finished':finished,'terminated':stopped}),flush=True)
        last_report=time.time()
    if finished or stopped:
        break
    time.sleep(1)
