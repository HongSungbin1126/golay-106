#define main exact_fiber_program_main
#include "../src/exact_orientation_fibers.cpp"
#undef main
#include <random>
int main(){
    std::mt19937_64 rng(20261105);
    U checks=0;
    for(unsigned p=3;p<=63;p+=2)for(unsigned trial=0;trial<1000;++trial){
        U mask=(U(1)<<p)-1,q=rng()&mask,t=rng()&mask;
        if(parity_fast(q,t,p)!=parity_direct(q,t,p)){
            std::cerr<<"parity mismatch p="<<p<<"\n";return 1;
        }
        ++checks;
    }
    std::cout<<"{\"result\":\"PASS\",\"fast_vs_direct_parity_checks\":"<<checks<<"}\n";
    return 0;
}
