#define main exact_quad_program_main
#include "../src/exact_quad_v4.cpp"
#undef main
#include <random>

// Exercise cache rollback and retained contradictions against fresh elimination.
// It is not enough to compare consistency: also compare ranks and check that the
// complete affine basis returned by the cache satisfies every original row.
int main() {
    std::mt19937_64 rng(20261105);
    unsigned checks=0;
    for(unsigned vars=0;vars<=30;++vars) {
        for(unsigned trial=0;trial<25;++trial) {
            unsigned count=1+unsigned(rng()%60);
            U augmented_mask=(U(1)<<(vars+1))-1;
            U variable_mask=(U(1)<<vars)-1;
            std::vector<U> rows(count);
            for(U& row:rows)row=rng()&augmented_mask;
            CachedF2 cache(vars,count);
            for(unsigned step=0;step<100;++step) {
                unsigned highest=step ? unsigned(rng()%count) : count-1;
                if(step)for(unsigned r=0;r<=highest;++r) {
                    if(rng()%3==0)rows[r]^=rng()&augmented_mask;
                }
                Affine actual=cache.solve(rows,int(highest));
                Affine expected=solve_f2(rows,vars);
                if(actual.consistent!=expected.consistent) {
                    std::cerr<<"consistency mismatch at "<<vars<<","<<trial<<","<<step<<"\n";
                    return 1;
                }
                if(actual.consistent) {
                    if(actual.rank!=expected.rank || actual.basis.size()!=expected.basis.size()) {
                        std::cerr<<"rank mismatch\n";return 1;
                    }
                    for(U row:rows) {
                        if(unsigned(__builtin_parityll(row&actual.particular&variable_mask))
                           !=unsigned((row>>vars)&1)) {
                            std::cerr<<"invalid particular solution\n";return 1;
                        }
                        for(U vector:actual.basis)if(__builtin_parityll(row&vector&variable_mask)) {
                            std::cerr<<"invalid homogeneous basis\n";return 1;
                        }
                    }
                    // A row-span rank check verifies independence of returned basis.
                    Affine independence=solve_f2(actual.basis,vars);
                    if(!independence.consistent || independence.rank!=actual.basis.size()) {
                        std::cerr<<"dependent homogeneous basis\n";return 1;
                    }
                }
                ++checks;
            }
        }
    }
    std::cout<<"{\"result\":\"PASS\",\"cached_systems_checked\":"<<checks<<"}\n";
    return 0;
}
