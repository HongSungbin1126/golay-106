"""Small original-domain and independently derived edge-identity regressions."""
import importlib.util
import json
import random
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from golay_bootstrap import brute_profile_exists
from verify_independent import verify_pair


def direct(a, b):
    n = len(a)
    return [sum(a[i]*a[i+k] + b[i]*b[i+k] for i in range(n-k))
            for k in range(1, n)]


def main():
    rng = random.Random(20261105)
    checks = 0
    for n in range(2, 28, 2):
        m = n//2
        for _ in range(50):
            q = [rng.choice([-1,1]) for _ in range(m)]
            t = [rng.choice([-1,1]) for _ in range(m)]
            s = [rng.choice([-1,1]) for _ in range(m)]
            a = s + [t[i]*s[i] for i in reversed(range(m))]
            b = [s[i]*q[i] for i in range(m)] + [-t[i]*s[i]*q[i] for i in reversed(range(m))]
            r = [0]*(n-1)
            for i in range(m):
                for j in range(i+1,m):
                    if t[i] != t[j]:
                        continue
                    k = j-i if q[i] == q[j] else n-1-i-j
                    sig = 1 if q[i] == q[j] else t[i]
                    r[k-1] += 4*sig*s[i]*s[j]
            assert r == direct(a,b)
            checks += 1
    runs = []
    for n in range(2, 21, 2):
        proc = subprocess.run([str(ROOT/'src/exact_quad'), '--n', str(n), '--seconds', '5'],
                              capture_output=True, text=True, check=True)
        result = json.loads(proc.stdout)
        if n <= 12:
            expected = brute_profile_exists(n) is not None
            assert result['solver_report'] == ('SAT' if expected else 'UNSAT')
        if result['solver_report'] == 'SAT':
            report = verify_pair(result['A'], result['B'], expected_n=n)
            result['independent_verification'] = report
        runs.append(result)
        checks += 1
    output = {'status':'PASS', 'checks':checks,
              'scope':'small calibration and random edge-identity regression only', 'runs':runs}
    out = ROOT/'results/exact_selfcheck.json'
    out.write_text(json.dumps(output, indent=2))
    print(json.dumps({'status':'PASS','checks':checks,
                      'runs': [{k:r[k] for k in ('n','solver_report','cpu_seconds',
                               'q_completed','sign_assignments_examined')} for r in runs]}, indent=2))


if __name__ == '__main__':
    main()
