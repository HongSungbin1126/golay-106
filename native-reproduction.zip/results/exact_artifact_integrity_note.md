# In-progress artifact integrity anomaly

Date: 2026-11-05. This note records an observed issue; it does not assign a proven cause.

During the root-controlled first-parity campaign, some completed chunk receipts reported normal exit and full coverage while their orientation JSONL files were empty. In particular, the chunks beginning at 6,291,456 and 7,340,032 both had the SHA-256 of the empty file. Their report files said `COMPLETE_H_PARTITION`, and the first reported one orientation. A later chunk beginning at 32,505,856 was also reported by the controller as affected.

For the first two inspected empty files, the modification time was `2026-11-05T06:11:19.220277Z`, and the metadata-change time was `2026-11-05T06:11:21.404251Z`. Their solver report files were written around `06:12:13.83Z` and `06:12:13.95Z`. The frozen source writes a header, periodically flushes, writes a footer, closes the stream, and checks stream failure. The source and executable hashes matched the campaign's frozen hashes.

These observations do not fit the ordinary no-solution output path, which still writes a header and footer. In addition, one affected report explicitly counted a solution. Replacement of a directory entry while a process retained an older open file descriptor is one possible explanation for the timestamps and successful stream operations, but it has not been established. No file-descriptor permission workaround was attempted.

An empty artifact must not be interpreted as an empty orientation set. The affected original artifacts and receipts are retained. The controller will rerun affected entire intervals under new result tags, using private temporary output files and installing final artifacts only after the subprocess has completed. Recovery requires normal exit, complete interval metadata, strict JSONL parsing, matching header/footer, exact orientation-record counts, and hashes of the final bytes.

The sign-refinement wrapper now follows the same principle: it pins a copy of the complete validated input, writes native outputs under a private temporary directory, and atomically installs only final bytes into the project. Every installation is immediately checked against the byte hash. It preserves existing result tags rather than overwriting them.

This issue affects the provenance and availability of output artifacts. It must be resolved before aggregation or any global mathematical conclusion. It does not by itself establish either correctness or incorrectness of the underlying search computation.
