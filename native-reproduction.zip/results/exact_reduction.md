# Exact quad enumeration: reduction and claim limits

Date: 2026-11-05. This re-expresses established quad/parity techniques; no novelty
is claimed. The implementation is `src/exact_quad.cpp`.

## Domain and normalization

For even n=2m, assume the necessary mirror identity
`a_i a_(n-1-i) + b_i b_(n-1-i) = 0` from protocol Section 5.3.
Write the left and right columns as

    L_i = (s_i, s_i q_i), R_i = (t_i s_i, -t_i s_i q_i),

where all s_i,q_i,t_i are signs. This parameterizes every mirror-compatible pair.
Independent whole-sequence negations permit a_0=b_0=1. Since the largest-lag
equation then makes the last signs opposite, row exchange permits a_(n-1)=1.
Thus s_0=q_0=t_0=1 (MODE P), without imposing row-sum normalization.

## Two necessary linear systems, followed by original equations

For i<j, the left-left plus right-right inner products contribute

    4 [q_i=q_j] [t_i=t_j] s_i s_j

to lag j-i. The two left-right products contribute

    4 [q_i!=q_j] [t_i=t_j] t_i s_i s_j

to lag n-1-i-j. Self-mirror products are zero. These account for every product in
the original correlations, so r_k/4 is a sum of signed edges.

1. Fix q. Select each pair's lag using q. At each lag the number of active edges
   (edges with t_i=t_j) must be even. With tau_i=(1-t_i)/2, this gives a GF(2)
   linear system: XOR of tau_i+tau_j over selected edges equals their count mod 2.
   Enumerate its full affine solution space, with tau_0=0.
2. Fix t. An active edge has coefficient sigma_e=1 for equal q, and t_i otherwise.
   At each lag its signed sum S_k is even by step 1. With u_i=(1-s_i)/2,
   reduction modulo 4 of sum_e sigma_e s_i s_j=0 gives

       sum_e (u_i+u_j) = S_k/2 mod 2.

   Enumerate the full affine solution space, with u_0=0.
3. Reconstruct all n signs and check the ORIGINAL aperiodic equations by exact
   XOR/popcount. The row-norm equality is an additional necessary prefilter.

An independent agent (`/root/theory_ai_quantum`) checked this algebraic reduction
from the original vector inner products on 2026-11-05. This review does not
independently certify all implementation details or a completed large enumeration.

## Enumeration and certificates

The q range is explicit; every t and s affine kernel is enumerated in Gray order.
Budget interruption is TIMEOUT, never UNSAT. Completing a strict q subrange is
PARTITION_UNSAT, never full UNSAT. A full completion is still marked a solver report
until independently replayed or otherwise certified.

For small n, a separate proof route avoids the mirror lemma and all quad code:
`exact_profile_certificate.py` lists every complete aperiodic correlation profile
of a sequence with first entry +1, in tail-mask order. `exact_profile_checker.py`
reconstructs every sequence using a different algorithm, recomputes direct signed
inner products, and checks that no two profiles are opposites. Whole-sequence
negation justifies the normalization, so this is complete original-domain
nonexistence evidence for that fixed length.
