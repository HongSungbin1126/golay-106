# A compact arithmetic exclusion of the eight remaining sign spaces

Date: 2026-11-05. Scope: the eight affine sign spaces supplied by the separately audited first and second parity reductions at length 106. The independent checker in `src/exact_sign_character_certificate_check.py` passed on all eight spaces, linked them to the upstream affine audit, and rejected all eight deliberately corrupted test cases. This note does not itself establish the upstream completeness of the first-parity search; that separate audit is `final_independent_coverage_audit.json`.

## Integer characters and the valid congruence step

In one audited sign space, write the remaining Boolean coordinates as `x in F_2^d`. Every sequence entry is a fixed sign times an integer character

\[
\chi_M(x)=(-1)^{\sum_{j\in M}x_j}\in\{-1,+1\}.
\]

Multiplying two sequence entries XORs their character masks. Collecting the original signed products at lag `k` therefore gives an **integer identity**

\[
r_k(x)=\sum_M c_{k,M}\chi_M(x).
\]

Let `g` be the positive gcd of the nonzero coefficients and let `P=r_k/g`. For exact-zero exclusion, dividing by `g` is an operation over the integers: `r_k=0` implies `P=0` regardless of whether `g` is invertible modulo a chosen modulus.

Write the primitive coefficients as `c_M` and `S=sum c_M`. Since `chi_M=1−2b_M`, where `b_M` is the Boolean parity selected by mask `M`,

\[
P=S-2\sum_M c_M b_M.
\]

If `S` is odd, `P` is odd for every assignment and cannot vanish. If `S` is even, the integer equality `P=0` implies

\[
\sum_M c_Mb_M=S/2.
\]

Reducing this last equality modulo two gives the necessary linear parity equation. **No division by two in `F_2` is used.**

For the stronger statement with the assumption `r_k=0 mod64`, the proof below uses only gcd-eight rows. There `r_k=8P`, so `64 | r_k` implies `8 | P`, which implies `P=0 mod4`. The same linear parity consequence follows. Unused rows with other gcds are not needed for this strengthening.

## Four cases, each occurring twice

The eight spaces form four pairs under the already defined row-reversal symmetry. All variable indices below refer to the exact basis ordering in the audited sign-space descriptors and the machine-readable certificate.

| Initial dimension | Two orientation indices in the consolidated list | Decisive contradiction |
|---:|---|---|
| 4 | 2 and 63 | `r_33=+16 chi_{10}(x)` exactly. |
| 4 | 7 and 54 | `r_9=−16 chi_{10}(x)` exactly. |
| 26 | 1 and 87 | Lags 24 and 28 force the same parity to both 1 and 0. |
| 20 | 0 and 86 | Eighteen necessary equations reduce the space to dimension two; then `r_4=−160` exactly. |

Here mask 10 is binary `1010`, so `chi_10=(-1)^(x_1+x_3)`. In the four dimension-four cases, the decisive correlation is always either 16 or −16. It is never zero, and never zero modulo 64.

### Dimension 26: two conflicting equations

At lags 24 and 28, the coefficient gcd is eight. The primitive coefficient sums are 14 and 12. In both cases the XOR of masks with odd primitive coefficient is

\[
M=33548287,
\]

which selects coordinates `0,...,24` except 11 and 12. Thus the two necessary equations are

\[
\bigoplus_{\substack{0\le j\le24\\j\notin\{11,12\}}}x_j
=14/2\pmod2=1,
\]

\[
\bigoplus_{\substack{0\le j\le24\\j\notin\{11,12\}}}x_j
=12/2\pmod2=0.
\]

Their XOR is `0=1`. These consequences are valid both under exact vanishing and under divisibility of both original correlations by 64.

### Dimension 20: a complete affine restriction, then a constant residual

Use only the gcd-eight equations from lags

\[
2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,40.
\]

The independent checker verifies that these eighteen rows have rank 18 and that their **entire** solution set is

\[
z=174763\;\mathbin{\oplus}\;\alpha\,299593
\;\mathbin{\oplus}\;\beta\,524288,
\qquad \alpha,\beta\in\{0,1\}.
\]

This is a statement about packed bit vectors, so multiplication by `alpha` or `beta` means choosing or omitting the indicated XOR direction. The checker verifies a particular solution, both independent kernel directions, and a rank witness with exact original-row XOR provenance. It does not assume that a proposed two-dimensional subset contains every solution.

After substitution into the full sign mask, the particular vector is `3708846773663864` and the two directions are `600479950316066` and `6905519428634760`. Rebuilding the original signed correlations, not merely their parity reductions, gives

\[
r_4(\alpha,\beta)=-160
\]

for all four remaining assignments. Hence exact vanishing is impossible. Also `−160=32 mod64`, so divisibility by 64 is impossible.

## What the checker verifies

The checker imports no producer or search code. It reconstructs the full signed A/B vectors at the affine base, attaches a character label to each sign-flip direction, and forms the upper triangle of the two-row signed Gram matrix. This independently rebuilds every original aperiodic correlation polynomial.

It verifies coefficient gcds and integer divisions, every claimed necessary linear equation, explicit XOR contradiction indices, complete affine preimages, the affine substitution between stages, and the final nonzero original residuals. A separate pass uses only the safe rows listed above for the modulo-64 strengthening. It pins the certificate and input hashes and, when given the upstream affine audit, checks that precisely the eight audited consistent sign spaces are covered.

This compresses the sign-tail argument from 136,314,944 individual sign checks to small integer-polynomial and binary-linear-algebra certificates. The upstream enumeration of all first-parity orientations remains a separate proof obligation. No claim of novelty or formal-kernel verification is made here.

## The modulo-32 survivors and the sharp power-of-two threshold

The same small proof also restricts every modulo-32 solution. The dimension-four correlations `±16 chi` are not divisible by 32. For dimension 26, `32 | 8P` already implies `P=0 mod4`, so the conflicting parity equations still apply. For dimension 20, the eighteen gcd-eight equations are still necessary, leaving exactly four sign assignments in each of two orientations.

The eight resulting original pairs are stored explicitly in `algebra_mod32_witnesses.json`. Their only nonzero combined aperiodic residuals are

\[
(r_4,r_8,r_{12},r_{16},r_{20})=(-160,128,-96,64,-32).
\]

All are divisible by 32, while several are not divisible by 64. Their residual energy is `56320`; this is not a global minimum-energy claim. The independent checker reconstructs every pair from its audited affine coordinates, recomputes all 105 original signed correlations, checks all eight are distinct, and generates the symmetry orbit using independent row negations, row swap, independent reversals, and common alternating signs.

Consequently the sign tail has exactly eight MODE P solutions modulo 32 and none modulo 64. The eight pairs are the MODE P members of one 64-member standard symmetry orbit. Promoting these to global counts for all length-106 pairs requires the separately proved modular mirror identity, free normalization action, and complete upstream orientation coverage.

With those upstream conditions, a useful exact hierarchy is:

| Required divisibility of every original `r_k` | Number in MODE P |
|---:|---:|
| 4 | `2^156` |
| 8 | `102·2^52` |
| 16 | `136314944` |
| 32 | `8` |
| 64 | `0` |

For these five rows, raw ordered-pair counts are eight times the normalized counts. The factor-eight rule is not extended to divisibility by two, which does not force the mirror/end-sign condition needed by this normalization.

On the unit circle the shared residual pattern can also be written exactly as

\[
|A(z)|^2+|B(z)|^2
=20+32\left|1-z^4+z^8-z^{12}+z^{16}-z^{20}\right|^2.
\]

The constant term is `20+32·6=212=2·106`, and the five nonzero sidelobes are the autocorrelations of the six-term alternating polynomial multiplied by 32. This identity describes the eight modulo-32 survivors; it does not assert a minimum for any optimization problem.

## Executed independent check and corruption tests

The exact checker command, run from the project root, was:

```bash
python3 src/exact_sign_character_certificate_check.py \
  --n 106 \
  --spaces results/exact_signs_n106_campaign_kernel_inventory.jsonl \
  --certificate results/algebra_sign_character_reductions.json \
  --affine-audit results/campaign_n106_sign_space_audit.json \
  --mod32-witnesses results/algebra_mod32_witnesses.json \
  --output results/exact_sign_character_certificate_checked.json
```

Result: **PASS**, eight spaces, all excluded modulo 64, all eight original modulo-32 witnesses recomputed, 0.02358854 CPU seconds. The reconstructed standard symmetry orbit has 64 distinct ordered pairs and exactly the eight supplied MODE P members. The checker does not import the certificate producer or either search engine, refuses optimized Python mode, and rejects duplicate JSON keys.

`python3 tests/exact_sign_character_certificate_mutations.py` also passed: the valid input was accepted, while changes to a coefficient gcd, a linear right-hand side, XOR provenance, a free direction, affine substitution, a terminal sign, the initial space list, and an original witness entry were each rejected. These tests exercise concrete certificate-integrity risks; they are not a proof that the checker cannot contain an error.

| Artifact | SHA-256 |
|---|---|
| Checker source | `5aa64ada1a3e7a5dce26e09b5ec19da49028ab0a4f3786499fd051427e5ba45a` |
| Certificate producer output | `ab5f16dc5a4d7933dead0a99b2f90c429e0fcb1f06a39b04f77a96bad9e45cc7` |
| Checked result | `e6adff328bf5def0bc0f77aa4e13edf4c0d7c625da969a2b763d7ffb7145ce44` |
| Mutation result | `5eee9b68ba59490c52abd07a1c2f782598b4fc450ad94cab75978ac5cd0a083e` |

Two other agents independently audited the checker source and found no material mathematical error. The certificate remains a program-checked integer-arithmetic argument with an explicitly stated trusted base, not a proof checked by a formal theorem-prover kernel.
