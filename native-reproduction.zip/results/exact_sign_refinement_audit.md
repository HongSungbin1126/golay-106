# Exact sign refinement: reduction and interval semantics

Date: 2026-11-05. This note describes `src/exact_sign_refine.cpp`, whose current source hash is recorded in `exact_build_manifest.json`. It is an implementation audit note, not a formal-kernel proof. The independent reviewer owns the separate acceptance decision.

## Scope

The input is an explicit list of normalized orientation masks `(q,t)` for a binary **aperiodic** pair of even length `n=2m`. Bit zero in each mask is zero. This program never claims that its input list contains every possible orientation. A negative result covers only the supplied masks and the explicitly completed sign intervals. Global nonexistence additionally requires a separately checked complete first-stage orientation enumeration.

The sign convention is bit `0` for sign `+1` and bit `1` for sign `-1`. With signs denoted by the corresponding lower-case letters,

\[
(a_i,b_i)=(s_i,s_iq_i),\qquad
(a_{n-1-i},b_{n-1-i})=(t_is_i,-t_is_iq_i),\quad 0\leq i<m.
\]

The normalization is MODE P: `s_0=q_0=t_0=+1`. It does not impose any fixed row sum or alternate MODE R normalization.

## The second parity system

For every `i<j`, an edge is active exactly when `t_i=t_j`. If `q_i=q_j`, it contributes `s_i s_j` to `r_(j-i)/4`. Otherwise it contributes `t_i s_i s_j` to `r_(n-1-i-j)/4`. Write each active coefficient as `sigma_e` in `{−1,+1}`. The integer equation at lag `k` is therefore

\[
\sum_{e\text{ at }k}\sigma_e s_i s_j=0.
\]

The first parity system guarantees that the signed coefficient sum `S_k=sum sigma_e` is even. The refiner explicitly checks that fact; an odd value is an input error, not a rejection of a valid sign assignment.

Writing `s_i=(-1)^{u_i}` gives

\[
S_k-2\sum_e\sigma_e(u_i\mathbin{\oplus}u_j)=0.
\]

Consequently, reduction modulo four yields the necessary affine equation over `F_2`

\[
\sum_e(u_i+u_j)=S_k/2\pmod 2.
\]

The program constructs precisely these rows, with `u_0=0`. It uses the already audited `solve_f2` routine from `exact_quad_v3.cpp`. An inconsistent system rejects the entire orientation. A consistent system returns a particular vector and an independent basis of its homogeneous kernel. The exported full-length sign masks are obtained by shifting these `(m−1)`-bit vectors left once.

This is a necessary reduction, so every vector in the resulting affine space is still tested against the original equations. No assertion that second parity is sufficient is used.

## Exact reconstruction and final test

For a full `m`-bit sign mask `u`, the bit sequences are reconstructed as

\[
A=u\;\Vert\;\operatorname{rev}_m(u\oplus t),\qquad
B=(u\oplus q)\;\Vert\;\operatorname{rev}_m(u\oplus q\oplus t\oplus\mathbf1).
\]

Here concatenation places the first half in the low bits. The integer row-norm identity

\[
\left(\sum a_i\right)^2+\left(\sum b_i\right)^2=2n
\]

is a necessary consequence of all aperiodic correlations vanishing, and is used only as an exact prefilter. It preserves all possible signs and row orders; at length 106 it does not assume a particular assignment of the row sums `±14` and `±4`.

For every surviving row norm, the program checks every original positive lag. If `h_k` is the total number of unequal endpoint pairs in both rows at lag `k`, then

\[
r_k=2(n-k)-2h_k.
\]

Thus the test `h_k==n-k` is exactly the integer Golay equation. All masks and population counts are integer operations. No floating-point feasibility or numerical UNSAT inference is involved. The wrapper independently verifies any returned positive witness with `verify_independent.py`.

## Gray enumeration and resuming a sign interval

For kernel basis `v_0,...,v_(d−1)` and particular solution `u_*`, index `j` represents

\[
u(j)=u_*+\sum_i \operatorname{bit}_i\bigl(j\oplus(j\!\gg\!1)\bigr)v_i.
\]

Binary reflected Gray code is a bijection on `[0,2^d)`. Consecutive indices differ by basis vector `v_ctz(j)`, which is the update used by the implementation. Initializing from the full Gray word of `s_start` makes nonzero starts correct.

The actual examined interval for one output record is

\[
[\mathtt{s\_start},\;\mathtt{s\_start}+\mathtt{sign\_assignments\_examined}).
\]

**`s_end_exclusive` records the requested end, not the completed end on timeout.** Coverage auditing must use the actual interval above. A timeout checks the budget before evaluating the next assignment, so the count does not include the unexamined assignment.

To resume an interrupted orientation, extract that single `(q,t)` into its own input file and set `--s-start` to the completed interval end. Later orientations from the original input must also be processed. A global `--s-start` applies separately to every input orientation; it is not an offset into the concatenation of all their spaces.

## Status meanings

| Status | What has been established by this solver run |
|---|---|
| `SECOND_PARITY_INCONSISTENT` | This entire listed orientation fails the necessary affine system. |
| `COMPLETE_NO_PAIR` | The entire sign kernel for this listed orientation was checked and rejected. |
| `NOT_SEARCHED_KERNEL_BOUND` | The kernel exceeded a configured bound, or the requested start was outside it. No exhaustive rejection is asserted. |
| `PARTIAL_SIGN_INTERVAL` | Only the explicitly recorded interval was rejected. |
| `TIMEOUT` | Only the completed prefix of the current interval, plus earlier complete records, is covered. |
| `ORIGINAL_PAIR_FOUND` | An exact candidate passed every original lag; the wrapper invokes an independent witness verifier. |
| `COMPLETE_INPUT_NO_PAIR` | Every supplied orientation was rejected, but completeness of the input orientation set is an external obligation. |

The program labels negative output `SOLVER_REPORT_NOT_INDEPENDENTLY_CERTIFIED`. Independent replay or a checked exhaustive certificate is still required before changing that label.

## Observed calibration

* Length 58: the refiner reproduced exactly the old complete search's 64 orientations, 54 second-parity inconsistencies, 36,960 sign assignments, 36,436 row-norm rejections, and 524 original-equation rejections. No sign kernel was skipped.
* Length 106, only the first folded interval `H in [0,4096)`: the first stage exported 13 orientations. Nine failed second parity. The remaining kernel dimensions were 4, 4, 20, and 26. All 68,157,472 sign assignments were checked; 68,059,166 failed the exact row norm, and 98,306 failed original equations. This excludes that first-stage interval under the audited folding reduction. It does not exclude the other 67,104,768 folded values.

The latest output-failure hardening changes only stream checks; the underlying sign-search algorithm is unchanged from these calibration runs. Source, dependency, binary, input, and wrapper hashes are recorded in each result. External CPU and address-space limits are set by `exact_sign_run.py`.
