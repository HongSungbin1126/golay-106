# Exact-search engineering report

Date: 2026-11-05. Final SEARCH_ENGINEER handoff. The complete length-106 first-parity campaign and a structurally independent replay have finished. Both give the same 102 normalized orientations. Every remaining sign space has been excluded by direct enumeration and by a separately checked compact arithmetic certificate. This report records the implementation, calibration, coverage evidence, and limits of that fixed-length computational conclusion.

## What is complete

1. Tiny fixed-length negative instances at lengths 6, 12, and 18 have raw complete normalized autocorrelation-profile certificates and a separate direct-product checker.
2. The classical quad/two-parity solver exhaustively reproduced known negative lengths 34, 50, and 58. Length 34 also has an independently generated and checked finite certificate from the verification agent.
3. A folded-polynomial/ElimLin-style first-parity solver agrees exactly with all previously exhausted orientation sets at lengths 34, 50, and 58. Its accelerated evaluator was checked against a direct edge expansion on 31,000 random cases.
4. The complete length-106 folded domain of 67,108,864 values was exhausted. A second, structurally independent first-parity implementation replayed the full domain and recovered exactly the same 102 orientations.
5. An independent affine audit found 94 inconsistent second-parity systems and eight complete sign spaces of dimensions 4, 4, 4, 4, 20, 20, 26, and 26. All 136,314,944 assignments were rejected both by the native refiner and by a separate direct signed-correlation replay.
6. A compact arithmetic certificate excludes the same eight spaces even under the weaker requirement that every original residual be divisible by 64. A separate checker passed, accepted the eight reconstructed modulo-32 witnesses, and rejected all eight deliberately corrupted certificate variants.

All computations retain the ordinary binary **aperiodic** definition. No periodic, complex, ternary, or complementary-set witness is accepted as a solution of the target problem.

## Reproduced complete quad searches

| Length | Full `q` domain | First-parity `(q,t)` survivors | Consistent sign spaces | Sign assignments | Original-lag tests | Native CPU time |
|---:|---:|---:|---:|---:|---:|---:|
| 34 | 65,536 | 22 | 10 | 664 | 332 | 0.0481 s, original v1 |
| 50 | 16,777,216 | 28 | 4 | 9,216 | 0 | 19.9224 s, original v1 |
| 58 | 268,435,456 | 64 | 10 | 36,960 | 524 | 211.934 s, incremental v3 |

Every first-stage survivor in these three runs had a unique `t` solution. Every final sign assignment was rejected, either by the exact row norm or by an original aperiodic equation. These are known fixed-length results reproduced for calibration; they do not establish the infinite length conjecture.

The published Borwein–Ferguson first-parity counts are half these counts because their search also applies a first-Q canonical normalization. Our baseline deliberately uses only MODE P. The factor of two is therefore expected. The quad reduction and original counts are documented in `exact_reduction.md` and the historical paper at `https://www.norbertwiener.umd.edu/crowds/documents/borwein_ferguson.pdf`.

## Native optimizations and their checks

* `exact_quad_v2` adds explicit orientation/kernel export to the immutable original v1.
* `exact_quad_v3` updates the first affine matrix under Gray-code changes instead of rebuilding every edge contribution. Length 50 decreased from 18.8803 s on the export-enabled v2 to 10.1091 s. All 28 `(q,t)` masks and all second-stage affine kernels matched exactly.
* `exact_quad_v4` reverses Gray-bit order and retains Gaussian pivots derived from unchanged high-lag rows. Length 50 decreased to 4.68132 s; the complete orientation/kernel set again matched. A separate test compared cached elimination to fresh elimination for 77,500 changing affine systems. The measured length-34/50 runs had zero unchanged-conflict skips, so the observed gain came from pivot reuse rather than broad conflict skipping.

These are implementations and combinations of established exact-search ideas. No novelty claim is made for Gray codes, incremental Gaussian elimination, quad reduction, or ElimLin.

## Folded polynomial search

For odd half-length `p`, the theory agent derived an exact first-parity reduction using

\[
H=Q+\operatorname{rev}_p Q,\qquad K=T+\operatorname{rev}_p T,
\qquad zH(H+K)=1\pmod{J_p},\quad J_p=1+z+\cdots+z^{p-1}.
\]

There are `2^((p−1)/2)` folded values `H`. Nonunits are rejected; for a unit, the palindromic zero-center representative `K` is determined. Every remaining normalized orientation lies in a complete affine fiber. The solver repeatedly projects out the span of quadratic output coefficients, solves the resulting affine consequences, substitutes the entire kernel, and branches exhaustively if the reduction stalls. It never assumes that projection always succeeds.

The theory proof is `proof/algebra_orientation_fibers.md`. The independently written Python reference is `src/algebra_orientation_fibers.py`. The native port is `src/exact_orientation_fibers.cpp`; the accelerated, hardened version used for the campaign is `src/exact_orientation_fibers_v2.cpp`.

| Length | Folded domain | All first-parity orientations | Portable native v1 | Accelerated native v2 |
|---:|---:|---:|---:|---:|
| 34 | 256 | 22 | 0.002402 s | not needed |
| 50 | 4,096 | 28 | 0.096757 s | not needed |
| 58 | 16,384 | 64 | 0.581084 s | 0.270024 s |

Complete set comparison, rather than count-only comparison, was used. An additional independent Python replay checked 76 length-106 fibers, including 64 sampled across the domain and 12 fibers containing the pilot's 13 orientations; that replay is recorded in `algebra_native_fiber_crosscheck_n106.json`.

### Accelerated output polynomial

The v2 evaluator computes the entire parity-output polynomial with five exact carryless products. Let `J` be the all-one `p`-bit polynomial, `u=q OR t`, and `g_ab` the bitmask of indices with `(q_i,t_i)=(a,b)`. Then the cross-lag polynomial is the reversal of

\[
g_{00}g_{10}+g_{01}g_{11},
\]

and the positive difference-lag terms are the appropriate high half of

\[
J(u+\operatorname{rev}_p u)+q\operatorname{rev}_p t+t\operatorname{rev}_p q,
\]

plus the known constant parity `p−k`. All products are in `F_2[z]`. On supported x86 processors the implementation uses PCLMUL; otherwise it uses exact portable carryless multiplication. The fast output and direct edge-loop output agreed on 31,000 random masks for odd half-lengths 3 through 63. The 128-bit word bounds cover the stated maximum length 126.

## Length-106 pilot and original resource estimate

The folded domain has 67,108,864 values. Five disjoint 4,096-value intervals were completed: the initial interval, and intervals starting at `2^24`, `2^25`, `3·2^24`, and `2^26−4096`.

| Interval start | Portable v1 CPU | Accelerated v2 CPU | First-parity orientations |
|---:|---:|---:|---:|
| 0 | 0.685709 s | 0.195487 s | 13 |
| 16,777,216 | 0.653839 s | 0.202787 s | 0 |
| 33,554,432 | 0.672456 s | 0.198515 s | 0 |
| 50,331,648 | 0.662501 s | 0.212757 s | 0 |
| 67,104,768 | 0.636530 s | 0.203662 s | 0 |

No branching fallback was needed in these samples, but it remains enabled. Extrapolating the observed v2 rates gives about 54–58 CPU minutes for the full first-parity domain. This is a workload estimate, not a guarantee and not a proof that later sign refinement will be cheap.

The first interval's 13 orientations were all rejected by the exact sign refiner: nine second-parity inconsistencies and four complete kernels of dimensions 4, 4, 20, and 26. All 68,157,472 sign assignments were covered in 1.03343 CPU seconds. The report and explicit kernel/interval details are `exact_signs_n106_pilot_full_signs.json` and `.jsonl`.

## Interruption, provenance, and certification boundaries

The fiber wrapper writes a manifest before launching a process. It records source, binary, and wrapper hashes, the exact command, CPU limits, and address-space limits. Native code records completed folded values, not merely started values. A timeout inside a fiber leaves that fiber uncommitted and it must be restarted. Output failures exit nonzero.

A timeout/resume test stopped after 55 completed folded values; restarting at 55 and finishing the remaining suffix produced exactly the same 13 orientations as uninterrupted `[0,4096)` enumeration. See `exact_fibers_resume_selfcheck.json`.

The frozen accelerated source hash is `3154f3816e12d8476df26a8e736fe26cbbd520e74238f842e853b9bfc379163f`. Build commands, binary hashes, and compiler version are in `exact_build_manifest.json`. The compiler was GNU C++ 13.3.0 with `-O3 -std=c++17 -Wall -Wextra`; assertions were enabled. The explicit free-space budget check remains active even if a future build disables assertions.

The native searches label their own negative conclusions as solver reports. The length-34 independent finite certificate verifies every rejection and affine row-space certificate without rerunning Gaussian elimination. For length 106, the subsequent independent full-domain replay, affine-space audit, direct sign replay, and compact arithmetic checker now supply the separate evidence recorded below. Their trusted base includes the mathematical reductions, checker programs, compilers/interpreters, and hardware; this is not a formal-kernel proof. The fixed-length exclusion does not prove the infinite Golay length conjecture, and this report makes no claim of publication priority or novelty.

## Subsequent output-integrity hardening

Some primary campaign chunks later had empty or truncated orientation artifacts despite normal reports. These were not accepted as empty solution sets. The observations, limits of the diagnosis, and recovery requirements are recorded in `exact_artifact_integrity_note.md`. The root controller retained the original receipts, reran all ten affected whole partitions using private temporary outputs, and accepted the aggregate only after strict coverage and output-integrity checks. The cause of the original artifact anomaly remains undetermined.

Both engineering wrappers now pin native output under private temporary directories and atomically install only finalized bytes. They check installed hashes, preserve existing tags, and validate the native output schema. No frozen native solver source or binary was changed by this wrapper hardening.

An additional independent audit program, `tests/exact_sign_space_audit.py`, reconstructs the complete second-parity affine system directly from original aperiodic correlations at zero and one-bit sign masks. It verifies contradictions, affine descriptors, and declared Gray-interval coverage. It explicitly does not claim to replay every original sign rejection; that separate obligation was completed by the root verifier, which rebuilt signed sequences and evaluated direct original correlations for every assignment.

## Additional positive and larger published baselines

After the main campaign released a compute lane, the following sequential tests completed under a separate 120-CPU-second allowance; actual native time was less than 35 CPU seconds.

| Length | Complete folded domain | First-parity orientations | Native CPU seconds | Check |
|---:|---:|---:|---:|---|
| 26 | 64 | 18 | 0.002691 | Twice the published first-Q canonical count 9; original positive pair recovered and independently verified. |
| 74 | 262,144 | 86 | 6.29658 | Twice the published first-Q canonical count 43. |
| 82 | 1,048,576 | 76 | 28.4591 | Twice the published first-Q canonical count 38; 2,047 folded values were nonunits. |

The length-26 sign search found a pair after eight sign assignments. The independent integer-convolution checker confirmed all 25 aperiodic residuals were zero and the full combined polynomial was constant 52. This is an expected positive control at a known Golay length, not a counterexample to the length conjecture. Its full sequences and verifier output are preserved in `exact_signs_n26_positive26_anchor.json`.

The factor of two has a direct normalization explanation. Reversing row A acts on bit masks as `(q,t,s) -> (q XOR t, t, s XOR t)` and preserves MODE P. A first-parity solution with half-length greater than one cannot have `t=0`: descending high cross-lag equations would inductively force every `q_i=0`, after which difference lag `m−1` has exactly one active edge. Thus the reversal has no fixed orientation. Selecting `q_j=0` at the first nonzero `t_j` keeps exactly one member of each two-element orbit, which is the paper's additional first-Q normalization.

## Final length-106 evidence chain

| Obligation | Completed result | Main record |
|---|---|---|
| Complete primary first-parity domain | All 67,108,864 folded values; 102 normalized orientations after integrity repairs | `campaign_n106_first_parity_orientations.jsonl` |
| Independent full first-parity replay | All 64 partitions; 67,108,864 values; exact equality of the 102-element orientation sets | `final_independent_coverage_audit.json` |
| Complete second-parity systems | 94 inconsistent systems and eight full affine sign spaces | `campaign_n106_sign_space_audit.json` |
| Native sign coverage | All 136,314,944 signs; no original Golay pair | `exact_signs_n106_campaign_full_signs.json` |
| Independent original-equation replay | All eight spaces and 136,314,944 signs; no pair; 92.3943 native CPU seconds | `campaign_n106_direct_sign_replay.json` |
| Compact sign-tail proof | All eight spaces excluded modulo 64; 0.02358854 checker CPU seconds | `exact_sign_character_certificate_checked.json` |
| Certificate rejection tests | Valid input accepted; eight distinct corruptions rejected | `exact_sign_character_certificate_mutations.json` |

The final independent first-stage audit reports `COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY_ACCEPTED`, exact primary-set equality, and 5,704.4228 seconds summed from the native partition CPU fields. The compact checker deliberately reports `global_first_stage_completeness_verified: false`: it checks the sign tail and its link to the upstream affine audit, while full first-stage coverage is checked by the separate coverage auditor. These scopes must not be conflated.

The native sign run rejected 136,118,332 assignments by the exact row norm and 196,612 by original aperiodic equations. The independent replay bypassed that row-norm filter, used ordinary binary basis enumeration instead of Gray enumeration, reconstructed signed A/B arrays, and checked original integer sums. The compact certificate is a third, much smaller way to discharge the same sign-tail obligation; its argument and exact command are in `exact_sign_character_proof.md`.

The arithmetic checker also reconstructed exactly eight MODE P pairs whose original residuals are divisible by 32 but not by 64. Each has residuals `(-160,128,-96,64,-32)` at lags `(4,8,12,16,20)` and zero at every other positive lag. These are failed Golay pairs with a useful modular structure, not solutions and not claimed global energy minimizers. The separate modular reduction and normalization proof are needed when interpreting their count globally.

### Final artifact pins

| Artifact | SHA-256 |
|---|---|
| Primary consolidated orientations | `1b24ce49462c7c8c46195588c1bf6ce84f42046be0d8accad0cb9a4af91f16f5` |
| Independent full-domain coverage audit | `49fa9f12cada6f86eaa37244f1d8a4e59433871cdfbc6248ed6f82dd0580bac3` |
| Independent direct-sign replay report | `ade1f2d42a65055df30012432536cca243ce5fbe8dbd76531ae12274f7c21cde` |
| Compact arithmetic checker source | `5aa64ada1a3e7a5dce26e09b5ec19da49028ab0a4f3786499fd051427e5ba45a` |
| Compact arithmetic checked report | `e6adff328bf5def0bc0f77aa4e13edf4c0d7c625da969a2b763d7ffb7145ce44` |
| Compact certificate mutation report | `5eee9b68ba59490c52abd07a1c2f782598b4fc450ad94cab75978ac5cd0a083e` |

All engineering compute is stopped. No extension to a new length, publication, or outreach was performed.
