"""Two checkpointed half-domain batches for the independent n=106 replay.

Four single-threaded children maximum; each long-lived output is under /tmp.
Every closed partition is strictly parsed and compared before atomic publication.
The primary orientation set is used only AFTER enumeration, never for pruning.
The root coordinator separately rehashes and accepts final global coverage.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import tempfile
import time

from verify_folded_independent_calibration import records, sha, publish_bytes, unique

ROOT = Path(__file__).resolve().parents[1]
TOTAL = 1 << 26
HALF = 1 << 25
CHUNK = 1 << 20


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    publish_bytes(path, (json.dumps(value, indent=2, sort_keys=True)+'\n').encode())


def live_cpu(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        return (int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')
    except FileNotFoundError:
        return 0.0


def literal_orientation(row):
    q,t,h = (row[k] for k in ('q_bits_mask','t_bits_mask','h'))
    if not all(type(v) is int for v in (q,t,h)) or not 0<=q<(1<<53) or not 0<=t<(1<<53) or (q|t)&1:
        raise ValueError('invalid orientation masks')
    reverse_q = int(f'{q:053b}'[::-1],2)
    if ((q^reverse_q)&((1<<26)-1)) != h:
        raise ValueError('orientation belongs to a different H fiber')
    parity = 0
    for i in range(53):
        for j in range(i+1,53):
            if ((t>>i)^(t>>j))&1:
                continue
            lag = 105-i-j if ((q>>i)^(q>>j))&1 else j-i
            parity ^= 1 << (lag-1)
    if parity:
        raise ValueError('orientation fails literal first parity')


def aggregate(path, begins, end, received, source_hash):
    all_rows=[]
    seen=set()
    cursor=begins
    for receipt in sorted(received,key=lambda x:x['h_start']):
        if receipt['h_start']!=cursor:
            raise ValueError('partition coverage gap or overlap')
        cursor=receipt['h_end_exclusive']
        raw, points=records(Path(receipt['orientation_path']))
        if sha(Path(receipt['orientation_path']))!=receipt['orientation_sha256']:
            raise ValueError('published partition changed after validation')
        if seen.intersection(points):
            raise ValueError('duplicate orientation across partitions')
        seen.update(points)
        all_rows.extend(raw[1:-1])
    if cursor!=end:
        raise ValueError('partition range does not reach requested endpoint')
    all_rows.sort(key=lambda r:(r['h'],r['q_bits_mask'],r['t_bits_mask']))
    header={'record_type':'header','format':'independent_folded_orientations_v2','n':106,
            'h_start':begins,'h_end_exclusive':end,'source_sha256':source_hash}
    footer={'record_type':'footer','status':'COMPLETE_H_DOMAIN' if begins==0 and end==TOTAL else 'COMPLETE_H_PARTITION',
            'h_start':begins,'covered_end_exclusive':end,'H_completed':end-begins,
            'orientation_records':len(all_rows)}
    data=''.join(json.dumps(row,separators=(',',':'))+'\n' for row in [header,*all_rows,footer])
    publish_bytes(path,data.encode())
    records(path)
    return seen


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--cpu-budget',type=float,default=7200)
    parser.add_argument('--batch-wall-limit',type=float,default=1100)
    parser.add_argument('--binary',type=Path,default=Path('/tmp/verify_folded_independent_v2'))
    parser.add_argument('--output-dir',type=Path,default=ROOT/'results/campaign_n106_first_parity_independent')
    args=parser.parse_args()
    if not 1<=args.workers<=4 or not 0<args.cpu_budget<=7200 or not 0<args.batch_wall_limit<=1150:
        raise ValueError('resource limits exceed allocated replay envelope')
    out=args.output_dir.resolve()
    out.mkdir(parents=True,exist_ok=False)
    source=ROOT/'src/verify_folded_independent_v2.cpp'
    calibration=ROOT/'results/verification_folded_independent_calibration_v2_strata4096.json'
    unit=ROOT/'results/verification_folded_independent_v2_unit.json'
    expected_path=ROOT/'results/campaign_n106_first_parity_orientations.jsonl'
    source_hash,binary_hash=sha(source),sha(args.binary)
    evidence=json.loads(calibration.read_text(),object_pairs_hook=unique)
    unit_evidence=json.loads(unit.read_text(),object_pairs_hook=unique)
    if evidence['result']!='PASS' or evidence['source_sha256']!=source_hash or evidence['binary_sha256']!=binary_hash:
        raise ValueError('current executable/source lacks matching complete calibration')
    if unit_evidence['status']!='PASS' or unit_evidence['source_sha256']!=source_hash:
        raise ValueError('current source lacks matching unit validation')
    reference,expected=records(expected_path)
    if reference[0]['h_start']!=0 or reference[0]['h_end_exclusive']!=TOTAL:
        raise ValueError('reference is not a complete declared H domain')
    private=Path(tempfile.mkdtemp(prefix='golay_independent_full_',dir='/tmp'))
    pinned_binary=private/'solver'
    shutil.copyfile(args.binary,pinned_binary)
    pinned_binary.chmod(0o700)
    shutil.copyfile(source,private/'source.cpp')
    publish_bytes(out/'source_snapshot.cpp',source.read_bytes())
    publish_bytes(out/'binary_snapshot',args.binary.read_bytes())
    (out/'binary_snapshot').chmod(0o700)
    publish_bytes(out/'controller_snapshot.py',Path(__file__).read_bytes())
    dependency=ROOT/'tests/verify_folded_independent_calibration.py'
    publish_bytes(out/'controller_dependency_snapshot.py',dependency.read_bytes())
    configuration={'started_utc':now(),'private_raw_directory':str(private),'source_sha256':source_hash,
                   'binary_sha256':binary_hash,'controller_sha256':sha(Path(__file__)),
                   'controller_dependency_sha256':sha(dependency),'compiler':['g++','-std=c++17','-O3','-Wall','-Wextra'],
                   'reference_path':str(expected_path),'reference_sha256':sha(expected_path),
                   'calibration_sha256':sha(calibration),'unit_validation_sha256':sha(unit),
                   'workers':args.workers,'aggregate_child_cpu_budget':args.cpu_budget,
                   'half_batch_wall_limit':args.batch_wall_limit,'child_cpu_limit':1000,
                   'child_wall_limit':1000,'chunk_size':CHUNK,'total_H_domain':TOTAL,
                   'batches':[[0,HALF],[HALF,TOTAL]],'scope':'FIRST_PARITY_ONLY'}
    save(out/'configuration.json',configuration)
    received=[]
    running={}
    cpu_base=resource.getrusage(resource.RUSAGE_CHILDREN)
    cpu_base=cpu_base.ru_utime+cpu_base.ru_stime
    start_all=time.monotonic()

    def used_cpu():
        usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        return usage.ru_utime+usage.ru_stime-cpu_base+sum(live_cpu(item['child'].pid) for item in running.values())

    def state(status,extra=None):
        value={'status':status,'updated_utc':now(),'completed_partitions':len(received),
               'H_completed':sum(x['H_completed'] for x in received),
               'accepted_orientation_records':sum(x['orientation_count'] for x in received),
               'aggregate_child_cpu_seconds':used_cpu(),'wall_seconds':time.monotonic()-start_all,
               'active_partitions':[item['start'] for item in running.values()],
               'receipts':received,'scope':'FIRST_PARITY_ONLY'}
        if extra:value.update(extra)
        save(out/'campaign_state.json',value)
        return value

    try:
        for batch_number,(begin,end) in enumerate(((0,HALF),(HALF,TOTAL)),1):
            pending=list(range(begin,end,CHUNK))
            batch_start=time.monotonic()
            last_progress=0
            while pending or running:
                if used_cpu()>=args.cpu_budget:
                    raise TimeoutError('aggregate replay CPU budget reached')
                if time.monotonic()-batch_start>=args.batch_wall_limit:
                    raise TimeoutError('half-campaign wall limit reached')
                while pending and len(running)<args.workers:
                    start=pending.pop(0)
                    name=f'h{start:09d}'
                    raw_report=private/(name+'.json')
                    raw_orient=private/(name+'.jsonl')
                    stdout=private/(name+'.stdout.log')
                    stderr=private/(name+'.stderr.log')
                    command=[str(pinned_binary),'--p','53','--h-start',str(start),'--h-limit',str(CHUNK),
                             '--seconds','1000','--wall-seconds','1000','--output',str(raw_report),
                             '--orientations',str(raw_orient),'--source-sha256',source_hash]
                    out_handle=stdout.open('w')
                    err_handle=stderr.open('w')
                    child=subprocess.Popen(command,stdout=out_handle,stderr=err_handle,start_new_session=True)
                    running[start]={'child':child,'start':start,'launched_utc':now(),'started':time.monotonic(),
                                    'report':raw_report,'orient':raw_orient,'stdout':stdout,'stderr':stderr,
                                    'handles':[out_handle,err_handle],'command':command}
                for start,item in list(running.items()):
                    rc=item['child'].poll()
                    if rc is None:
                        if time.monotonic()-item['started']>1020:
                            raise TimeoutError(f'child hard wall deadline: {start}')
                        continue
                    for handle in item['handles']:handle.close()
                    del running[start]
                    if rc!=0:
                        raise RuntimeError(f'child {start} returned {rc}; raw evidence retained at {private}')
                    report=json.loads(item['report'].read_text(),object_pairs_hook=unique)
                    rows,points=records(item['orient'])
                    if report['status']!='COMPLETE_H_PARTITION' or report['h_start']!=start or report['h_end_exclusive']!=start+CHUNK:
                        raise ValueError('child report range/status mismatch')
                    if report['H_completed']!=CHUNK or report['covered_end_exclusive']!=start+CHUNK:
                        raise ValueError('child report incomplete range')
                    if report['source_sha256']!=source_hash or rows[0]['source_sha256']!=source_hash:
                        raise ValueError('child source provenance mismatch')
                    if rows[0]['n']!=106 or rows[0]['h_start']!=start or rows[0]['h_end_exclusive']!=start+CHUNK:
                        raise ValueError('orientation header mismatch')
                    if rows[-1]['covered_end_exclusive']!=start+CHUNK or rows[-1]['orientation_records']!=len(points):
                        raise ValueError('orientation footer mismatch')
                    if report['orientation_records']!=len(points):
                        raise ValueError('report/records count mismatch')
                    statistics=report['statistics']
                    if statistics['H_examined']!=CHUNK or statistics['nonunit_H']!=int(start==0) or statistics['unit_H']!=CHUNK-int(start==0):
                        raise ValueError('unexpected H/unit accounting')
                    for row in rows[1:-1]:literal_orientation(row)
                    target={x for x in expected if start<=x[0]<start+CHUNK}
                    if points!=target:
                        raise ValueError(f'independent set mismatch at {start}: missing={target-points}, extra={points-target}')
                    name=f'h{start:09d}'
                    final_report,final_orient=out/(name+'.json'),out/(name+'.jsonl')
                    publish_bytes(final_report,item['report'].read_bytes())
                    publish_bytes(final_orient,item['orient'].read_bytes())
                    publish_bytes(out/(name+'.stderr.log'),item['stderr'].read_bytes())
                    receipt={'h_start':start,'h_end_exclusive':start+CHUNK,'H_completed':CHUNK,
                             'orientation_count':len(points),'orientation_path':str(final_orient),
                             'orientation_sha256':sha(final_orient),'report_path':str(final_report),
                             'report_sha256':sha(final_report),'source_sha256':source_hash,'binary_sha256':binary_hash,
                             'cpu_seconds':report['cpu_seconds'],'wall_seconds':report['wall_seconds'],
                             'launched_utc':item['launched_utc'],'validated_utc':now(),'command':item['command'],
                             'result':'EXACT_PRIMARY_SET_MATCH_AND_LITERAL_PARITY_PASS'}
                    save(out/(name+'.receipt.json'),receipt)
                    received.append(receipt)
                    print(json.dumps({'event':'partition_complete','batch':batch_number,**{k:receipt[k] for k in
                                      ('h_start','H_completed','orientation_count','cpu_seconds')}}),flush=True)
                if time.monotonic()-last_progress>=15:
                    progress=state('RUNNING',{'batch':batch_number})
                    print(json.dumps({k:progress[k] for k in ('status','H_completed','aggregate_child_cpu_seconds','wall_seconds')}),flush=True)
                    last_progress=time.monotonic()
                time.sleep(0.25)
            batch_receipts=[r for r in received if begin<=r['h_start']<end]
            seen=aggregate(out/f'half{batch_number}_orientations.jsonl',begin,end,batch_receipts,source_hash)
            checkpoint=state('HALF_BATCH_CHECKPOINT',{'batch':batch_number,'batch_covered_interval':[begin,end],
                             'batch_wall_seconds':time.monotonic()-batch_start,'batch_orientation_count':len(seen)})
            save(out/f'half{batch_number}_checkpoint.json',checkpoint)
            print(json.dumps({'event':'half_batch_checkpoint','batch':batch_number,'H_completed':end,
                              'aggregate_child_cpu_seconds':used_cpu()}),flush=True)
            # The next half is a fresh bounded batch; aggregate CPU accounting persists.
        aggregate_path=out/'all_orientations.jsonl'
        combined=aggregate(aggregate_path,0,TOTAL,received,source_hash)
        if combined!=expected:
            raise ValueError('global independent orientation set mismatch')
        final=state('COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY',
                    {'orientation_count':len(combined),'orientation_path':str(aggregate_path),
                     'orientation_sha256':sha(aggregate_path),'source_sha256':source_hash,'binary_sha256':binary_hash,
                     'original_golay_existence_decided_by_this_run':False})
        save(out/'final_summary.json',final)
        print(json.dumps({'event':'complete','H_completed':TOTAL,'orientation_count':len(combined),
                          'aggregate_child_cpu_seconds':used_cpu(),'wall_seconds':time.monotonic()-start_all}),flush=True)
    except BaseException as error:
        for item in running.values():
            if item['child'].poll() is None:item['child'].terminate()
        for item in running.values():
            try:item['child'].wait(timeout=3)
            except subprocess.TimeoutExpired:item['child'].kill();item['child'].wait()
            for handle in item['handles']:handle.close()
        running.clear()
        state('INCOMPLETE',{'error':repr(error),'private_raw_directory':str(private)})
        raise


if __name__=='__main__':
    main()
