"""One-worker complete calibrations and stratified n=106 timing comparisons.

Raw child files are kept outside the synchronized tree until closed, parsed,
and compared with an intact reference. No global n=106 conclusion is implied.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key {key}')
        result[key] = value
    return result


def records(path):
    raw = path.read_text()
    if not raw.endswith('\n'):
        raise ValueError(f'incomplete JSONL {path}')
    result = [json.loads(line, object_pairs_hook=unique) for line in raw.splitlines()]
    if len(result) < 2 or result[0].get('record_type') != 'header' or result[-1].get('record_type') != 'footer':
        raise ValueError(f'missing header/footer {path}')
    if not result[-1].get('status', '').startswith('COMPLETE_H_'):
        raise ValueError(f'incomplete H partition {path}')
    if result[-1]['H_completed'] != result[0]['h_end_exclusive'] - result[0]['h_start']:
        raise ValueError(f'coverage count mismatch {path}')
    seen = set()
    for row in result[1:-1]:
        if row.get('record_type') != 'orientation':
            raise ValueError(f'unexpected middle record {path}')
        key = tuple(row[k] for k in ('h', 'q_bits_mask', 't_bits_mask'))
        if not all(type(v) is int for v in key) or key in seen:
            raise ValueError(f'duplicate or malformed orientation {path}')
        if row['n'] != result[0]['n'] or not result[0]['h_start'] <= key[0] < result[0]['h_end_exclusive']:
            raise ValueError(f'orientation outside header domain {path}')
        seen.add(key)
    return result, seen


def publish_bytes(path, content):
    staging = path.with_name(path.name + f'.publish.{os.getpid()}')
    staging.write_bytes(content)
    os.replace(staging, path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--binary', type=Path, default=Path('/tmp/verify_folded_independent'))
    parser.add_argument('--source', type=Path, default=ROOT/'src/verify_folded_independent.cpp')
    parser.add_argument('--limit106', type=int, default=4096)
    parser.add_argument('--seconds', type=float, default=60)
    parser.add_argument('--tag', default='v1')
    parser.add_argument('--skip-small', action='store_true')
    args = parser.parse_args()
    if not 1 <= args.limit106 <= 4096:
        raise ValueError('106 sample size must be 1..4096')
    source = args.source
    source_hash, binary_hash = sha(source), sha(args.binary)
    cases = [] if args.skip_small else [(f'n{n}', n//2, 0, 1 << ((n//2-1)//2),
              ROOT/f'results/exact_fibers_n{n}_calibration.jsonl') for n in (34,50,58)]
    for label, begin in [('pilot',0),('quarter',1<<24),('half',1<<25),
                         ('threequarter',3*(1<<24)),('tail',(1<<26)-4096)]:
        cases.append((f'n106_{label}',53,begin,args.limit106,
                      ROOT/f'results/exact_fibers_n106_pclmul_{label}4096.jsonl'))
    summaries = []
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix='golay_independent_calibration_', dir='/tmp') as private:
        private = Path(private)
        for label,p,start,count,reference in cases:
            reference_rows, expected_all = records(reference)
            expected = {x for x in expected_all if start <= x[0] < start+count}
            if not reference_rows[0]['h_start'] <= start < start+count <= reference_rows[0]['h_end_exclusive']:
                raise ValueError('requested comparison not covered by reference')
            report_path, orientation_path = private/(label+'.json'), private/(label+'.jsonl')
            command = [str(args.binary),'--p',str(p),'--h-start',str(start),'--h-limit',str(count),
                       '--seconds',str(args.seconds),'--wall-seconds','180','--output',str(report_path),
                       '--orientations',str(orientation_path),'--source-sha256',source_hash]
            child = subprocess.run(command,capture_output=True,text=True,timeout=190)
            if child.returncode != 0:
                raise RuntimeError(f'{label}: {child.returncode}: {child.stderr}')
            report = json.loads(report_path.read_text(),object_pairs_hook=unique)
            actual_rows, actual = records(orientation_path)
            if actual != expected:
                raise ValueError(f'{label}: exact set mismatch; missing={expected-actual}, extra={actual-expected}')
            if report['H_completed'] != count or report['source_sha256'] != source_hash:
                raise ValueError('report coverage or provenance mismatch')
            if actual_rows[-1]['orientation_records'] != len(actual) or report['orientation_records'] != len(actual):
                raise ValueError('orientation count mismatch')
            prefix = ROOT/f'results/verification_folded_independent_{label}_{args.tag}'
            publish_bytes(prefix.with_suffix('.jsonl'), orientation_path.read_bytes())
            report.update({'comparison':'EXACT_ORIENTATION_SET_MATCH',
                           'reference_path':str(reference),'reference_sha256':sha(reference),
                           'orientation_sha256':sha(orientation_path),'binary_sha256':binary_hash,
                           'command':command,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
            publish_bytes(prefix.with_suffix('.json'), (json.dumps(report,indent=2)+'\n').encode())
            summary = {'case':label,'p':p,'h_start':start,'H_completed':count,
                       'orientation_count':len(actual),'cpu_seconds':report['cpu_seconds'],
                       'wall_seconds':report['wall_seconds'],'peak_rss_kib':report['peak_rss_kib'],
                       'result':'EXACT_ORIENTATION_SET_MATCH'}
            summaries.append(summary)
            print(json.dumps(summary),flush=True)
    samples = [x for x in summaries if x['p']==53]
    average = sum(x['cpu_seconds'] for x in samples)/sum(x['H_completed'] for x in samples)
    maximum = max(x['cpu_seconds']/x['H_completed'] for x in samples)
    output = {'result':'PASS','scope':('sampled n106 H partitions only' if args.skip_small
                                    else 'complete n34/50/58 and sampled n106 H partitions only'),
              'source_sha256':source_hash,'binary_sha256':binary_hash,
              'wrapper_sha256':sha(Path(__file__)),'runs':summaries,
              'n106_extrapolation_not_guarantee':{'mean_cpu_hours':average*(1<<26)/3600,
                                                'maximum_stratum_rate_cpu_hours':maximum*(1<<26)/3600},
              'total_child_cpu_seconds':sum(x['cpu_seconds'] for x in summaries),
              'wall_seconds':time.monotonic()-started}
    path = ROOT/f'results/verification_folded_independent_calibration_{args.tag}.json'
    publish_bytes(path,(json.dumps(output,indent=2)+'\n').encode())
    print(json.dumps(output['n106_extrapolation_not_guarantee']),flush=True)


if __name__ == '__main__':
    main()
