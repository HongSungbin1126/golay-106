#define GOLAY_VERIFY_NO_MAIN
#ifndef GOLAY_VERIFY_ENGINE
#define GOLAY_VERIFY_ENGINE "../src/verify_folded_independent.cpp"
#endif
#include GOLAY_VERIFY_ENGINE
#include <random>
#include <set>

namespace independent_folded {
struct SolverTestAccess {
    static void solve(Solver& solver, Point base, std::vector<Point> directions) {
        solver.solve_space(base, std::move(directions));
    }
};
}
using namespace independent_folded;

static void require(bool condition, const std::string& label) {
    if (!condition) throw std::runtime_error("test failed: " + label);
}
using PointSet = std::set<std::pair<Word, Word>>;
static PointSet solution_set(const std::vector<Point>& values) {
    PointSet result;
    for (Point value : values) require(result.emplace(value.q, value.u).second, "no repeated solution");
    return result;
}
static std::set<Word> all_span(const std::vector<Word>& generators) {
    std::set<Word> values{0};
    for (Word v : generators) {
        std::vector<Word> next;
        for (Word w : values) next.push_back(v^w);
        values.insert(next.begin(), next.end());
    }
    return values;
}
static Wide ordinary_product(Word a, Word b) {
    Wide product = 0;
    for (unsigned i = 0; i < 64; ++i) if ((b >> i) & 1) product ^= Wide(a) << i;
    return product;
}
static int degree(Wide a) {
    int answer = -1;
    while (a) { ++answer; a >>= 1; }
    return answer;
}
static Wide polynomial_remainder(Wide a, Wide divisor) {
    int dd = degree(divisor);
    if (dd < 0) throw std::logic_error("zero divisor in test");
    while (degree(a) >= dd) a ^= divisor << (degree(a)-dd);
    return a;
}
static Wide gcd_polynomial(Wide a, Wide b) {
    while (b) { Wide c = polynomial_remainder(a,b); a=b; b=c; }
    return a;
}

int main() {
    try {
        const std::clock_t start = std::clock();
        std::mt19937_64 random(0x20261105a11d17ULL);
        unsigned parity_checks = 0, row_checks = 0, inverse_checks = 0;
        unsigned derivative_checks = 0, nonlinear_checks = 0, complete_domains = 0;
        unsigned generic_spaces = 0;
        unsigned fast_reflection_checks = 0, product_checks = 0;
        Word branch_nodes = 0;

        for (unsigned p = 3; p <= 63; p += 2) {
            ParityEvaluator parity(p);
            const Word mask = low_bits(p);
            for (unsigned trial = 0; trial < 64; ++trial) {
                Point point{random() & mask, random() & mask};
                require(parity(point) == parity.literal(point), "reflection parity versus literal pairs");
                ++parity_checks;
            }
        }

#ifdef GOLAY_VERIFY_HAS_FAST
        for (unsigned p = 3; p <= 63; p += 2) {
            ParityEvaluator parity(p);
            const Word mask = low_bits(p);
            for (unsigned trial = 0; trial < 4096; ++trial) {
                Point point{random() & mask, random() & mask};
                require(parity(point) == parity.reflection(point), "D/C versus reflection parity");
                ++fast_reflection_checks;
                Word a=random()&mask,b=random()&mask;
                require(product(a,b)==ordinary_product(a,b), "carryless instruction versus literal product");
                require(product_shift(a,b)==ordinary_product(a,b), "portable versus literal product");
                ++product_checks;
            }
            for (unsigned trial=0;trial<64;++trial) {
                Point base{random()&mask,random()&mask};
                unsigned m=(p-1)/2;
                for(unsigned i=1;i<=m;++i) {
                    Word v=Word(1)<<i;
                    if(i!=m)v^=Word(1)<<(p-1-i);
                    Point point{base.q^v,base.u};
                    require(parity(point)==parity.reflection(point),"D/C fixed-fiber Q direction");
                    point={base.q,base.u^v};
                    require(parity(point)==parity.reflection(point),"D/C fixed-fiber U direction");
                    fast_reflection_checks+=2;
                }
            }
        }
#endif

        for (unsigned d = 0; d <= 8; ++d) for (unsigned trial = 0; trial < 50; ++trial) {
            std::vector<Word> rows(random() % (d+5));
            for (Word& row : rows) row = random() & low_bits(d+1);
            AffineSolution result = row_solve(rows, d);
            std::set<Word> expected;
            for (Word x = 0; x < (Word(1)<<d); ++x) {
                bool good = true;
                for (Word row : rows)
                    if (__builtin_parityll(row & x) != ((row >> d)&1)) { good=false; break; }
                if (good) expected.insert(x);
            }
            std::set<Word> actual;
            if (result.consistent) for (Word x : all_span(result.kernel)) actual.insert(result.particular^x);
            require(actual == expected, "complete RREF solution set");
            if (result.consistent)
                require(result.rank + result.kernel.size() == d, "rank plus nullity");
            ++row_checks;
        }

        for (unsigned p = 3; p <= 63; p += 2) {
            for (unsigned trial = 0; trial < 12; ++trial) {
                const Word h = trial == 0 ? 0 : random() & low_bits((p-1)/2);
                const Word H = h | reverse_bits(h,p);
                Word inverse = 0;
                const bool found = inverse_by_rows(H,p,inverse);
                require(found == (gcd_polynomial(H,low_bits(p))==1), "matrix inverse versus polynomial gcd");
                if (found)
                    require(polynomial_remainder(ordinary_product(H,inverse),low_bits(p))==1,
                            "matrix inverse versus ordinary polynomial product");
                ++inverse_checks;
            }
        }

        for (unsigned p : {3U,5U,7U,9U,17U,53U,63U}) {
            const unsigned m = (p-1)/2;
            ParityEvaluator parity(p);
            Solver solver(p,60,60);
            for (unsigned trial = 0; trial < 8; ++trial) {
                Point base{random() & (low_bits(p)^1), random() & (low_bits(p)^1)};
                Word H = base.q ^ reverse_bits(base.q,p), G = base.u ^ reverse_bits(base.u,p);
                const std::vector<Word> columns = solver.initial_columns(H,G);
                const Wide f0 = parity.literal(base);
                unsigned column = 0;
                for (unsigned block = 0; block < 2; ++block) for (unsigned i = 1; i <= m; ++i) {
                    Word v = Word(1)<<i;
                    if (i!=m) v ^= Word(1)<<(p-1-i);
                    Point direction = block==0 ? Point{v,0} : Point{0,v};
                    const Wide difference = f0 ^ parity.literal(add(base,direction));
                    Word expected = 0;
                    for (unsigned k = 1; k < p; ++k)
                        if (((difference>>(k-1))^(difference>>(2*p-k-1)))&1)
                            expected |= Word(1)<<(k-1);
                    require(expected == columns[column++], "analytic affine derivative");
                    require(!((difference>>(p-1))&1), "middle derivative zero");
                    ++derivative_checks;
                }
            }
        }

        for (unsigned trial = 0; trial < 100; ++trial) {
            const unsigned d = 2 + random()%4, monomials=d*(d-1)/2;
            const unsigned count = 1 + random()%8;
            std::vector<AnfRow> rows(count);
            for (AnfRow& row : rows) {
                row.quadratic[0] = random() & low_bits(monomials);
                row.affine = random() & low_bits(d+1);
            }
            std::set<Word> expected;
            for (Word combination = 0; combination < (Word(1)<<count); ++combination) {
                Word nonlinear=0, affine=0;
                for (unsigned j=0;j<count;++j) if ((combination>>j)&1) {
                    nonlinear ^= rows[j].quadratic[0]; affine ^= rows[j].affine;
                }
                if (!nonlinear) expected.insert(affine);
            }
            LinearConsequences result=remove_nonlinear(rows,monomials);
            require(all_span(result.rows)==expected, "all and only row-span affine consequences");
            ++nonlinear_checks;
        }

        for (unsigned p : {3U,5U,7U}) {
            ParityEvaluator parity(p);
            PointSet expected;
            for (Word q=0;q<(Word(1)<<p);q+=2) for (Word u=0;u<(Word(1)<<p);u+=2)
                if (!parity.literal({q,u})) expected.emplace(q,u);
            Solver solver(p,60,60);
            PointSet actual;
            for (Word h=0;h<(Word(1)<<((p-1)/2));++h) {
                solver.solve_h(h);
                for (auto point : solution_set(solver.solutions))
                    require(actual.insert(point).second, "disjoint complete H fibers");
            }
            require(actual==expected,"complete folded domain versus brute original parity");
            ++complete_domains;

            // Exercise the generic residual solver on the unfurled normalized
            // domain, so rank patterns of folded fibers cannot conceal fallback.
            std::vector<Point> directions;
            for (unsigned i=1;i<p;++i) directions.push_back({Word(1)<<i,0});
            for (unsigned i=1;i<p;++i) directions.push_back({0,Word(1)<<i});
            Solver generic(p,60,60);
            SolverTestAccess::solve(generic,{},directions);
            require(solution_set(generic.solutions)==expected,"generic residual exhaustive domain");
            branch_nodes += generic.stats.branch_nodes;
            ++generic_spaces;
        }
        require(branch_nodes>0,"exhaustive branching fallback was actually exercised");

        // More varied affine subspaces, checked by literal enumeration.
        for (unsigned trial=0;trial<30;++trial) {
            unsigned p=7,d=1+random()%6;
            Point base{random()&126,random()&126};
            std::vector<Point> directions;
            for(unsigned i=0;i<d;++i) directions.push_back(i<3 ? Point{Word(1)<<(i+1),0}
                                                                            : Point{0,Word(1)<<(i-2)});
            PointSet expected;
            ParityEvaluator parity(p);
            for(Word mask=0;mask<(Word(1)<<d);++mask) {
                Point point=add(base,combination(mask,directions));
                if(!parity.literal(point)) expected.emplace(point.q,point.u);
            }
            Solver solver(p,60,60);
            SolverTestAccess::solve(solver,base,directions);
            require(solution_set(solver.solutions)==expected,"generic affine subspace brute force");
            branch_nodes+=solver.stats.branch_nodes;
            ++generic_spaces;
        }
        std::cout << "{\"status\":\"PASS\",\"parity_literal_comparisons\":"<<parity_checks
                  <<",\"rref_exhaustive_systems\":"<<row_checks
                  <<",\"inverse_gcd_product_comparisons\":"<<inverse_checks
                  <<",\"analytic_derivative_comparisons\":"<<derivative_checks
                  <<",\"quadratic_row_span_comparisons\":"<<nonlinear_checks
                  <<",\"complete_small_domains\":"<<complete_domains
                  <<",\"generic_residual_spaces\":"<<generic_spaces
                  <<",\"branch_nodes_exercised\":"<<branch_nodes
                  <<",\"fast_reflection_comparisons\":"<<fast_reflection_checks
                  <<",\"carryless_product_comparisons\":"<<product_checks
                  <<",\"cpu_seconds\":"<<double(std::clock()-start)/CLOCKS_PER_SEC<<"}\n";
        return 0;
    } catch(const std::exception& error) {
        std::cerr << error.what()<<"\n";
        return 1;
    }
}
