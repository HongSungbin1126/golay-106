# Curated public-archive differences

This archive preserves accepted-result evidence without publishing the private original research mission or conversation history.

## Deliberate omissions from the original980-file bundle

- RESEARCH_PROTOCOL.md: original private research instruction/prompt.
- AGENTS.md, AGENT_HANDOFF.md, NEXT_ACTION.md, STATE.md and private handoff/control files.
- Original top-level README: replaced with a scope-specific public reproduction README.
- experiments/: unrelated exploratory work.
- certificates/: exploratory SAT/CNF/DRUP files not used by the accepted native/modular proof chain.
- sources/status_search_log.json: raw prior discovery log, unnecessary for the proof.
- .git directory: was not included in the supplied bundle either.
- Third-party PDFs, private prompts and conversations: not redistributed.

The old manifest is retained under a name explicitly marking it ORIGINAL_BUNDLE_MANIFEST.sha256. Do not interpret omitted entries as files purportedly present in this archive. All public bytes are instead identified by PUBLIC_MANIFEST.sha256.

## Preserved files

Accepted mathematical proof notes, native source and binary snapshots, historical primary and independent campaign directories, original output records (including the ten rejected damaged primary receipts), replacement evidence,102-orientation output, sign-space descriptors, modular certificate and witness files, compiler manifest, and reproduction notes remain byte-identical. Historical absolute /workspace or temporary paths in raw run metadata refer to the recorded environment, not missing user-specific files.

Existing CLAIMS and final acceptance metadata are historical cross-file linkers, not formal theorem proofs. Some historical linkage entries identify the omitted private protocol. Do not run the mutating finalizer to conceal or rewrite this historical fact. The four accepted-result quick checks documented in the new README are the supported integrity/certificate route in this curated archive; they have been run in this curated tree.

The preparation-validation folder contains clearly separated additional checks. Those are later records, not replacements silently substituted into old manifests. Its public auditor and source hashes pin the new execution. A new public manifest covers these additions.
