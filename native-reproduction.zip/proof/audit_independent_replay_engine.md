# Independent first-parity replay: implementation and validation

Date: 2026-11-05. Role: ADVERSARIAL_VERIFIER.

This document describes the second implementation and its verified building
blocks. The complete length-106 replay has finished successfully. Section 7
records its actual completion evidence. The root's separate final artifact
audit remains a distinct acceptance step.

## 1. Independence and shared assumptions

The slow reference is `src/verify_folded_independent.cpp`, SHA256
`5e62a096e1464d8e3f706f508db359b3efdd48c039cfc183206fba7ef1978dd9`.
It remains frozen. Its full n=34/50/58 outputs and five dispersed n=106
4,096-H partitions agree exactly with the primary implementation.

The accelerated copy is `src/verify_folded_independent_v2.cpp`, SHA256
`bf6787ae84099a25d19297e4f47fe5ab0a832167c6e5d86ee1ef83b733c6e1f8`.
The campaign executable SHA256 is
`89d289732728bd460ebeba687276f2e3e50a59b9c377edf00db490236ef0e7a8`.
Only the parity-evaluation path, its helpers, and identifying labels changed.
Both copies use the following independently written machinery:

- Q,U=Q+T coordinates and explicit affine consequences, rather than the
  primary solver's initial quadratic-image projection.
- A multiplication-by-H matrix, solved by scalar row RREF, for the inverse.
  The primary solver uses polynomial Euclid.
- Scalar equation rows and full row RREF for affine systems; the primary
  solver uses output-vector column preimages.
- Scalar ANF rows with nonlinear-monomial columns eliminated by row
  operations; the primary solver projects vector coefficients modulo their
  quadratic span.
- Retention of the complete parity map after every restriction, and both
  branches whenever affine extraction stalls.
- Literal active-edge checks of every emitted orientation.

These implementations share the proved folding theorem, MODE P, and the
established general ElimLin principle. This is implementation independence
with separate proof audits, not an unrelated second mathematical theorem or
a formal proof-kernel certificate.

## 2. Inverse and fiber coverage

The low-degree residue of H is multiplied by successive powers of z modulo
J to form the columns of its multiplication matrix. Row RREF solves
`M_H inverse = 1`. In a finite commutative quotient ring, a solution makes H
a unit and the inverse is unique; a nonzero returned kernel is explicitly
treated as an error. A separate shift/XOR ring product verifies the inverse.

Multiplication by z^-1 is performed by dividing the residue by z after
adding J if its constant coefficient is one. The selected p-term G has
middle coefficient zero and is explicitly checked to be palindromic, with
`zHG=1 mod J`. The normalization fixes q_0=u_0=0. Every remaining reflected
pair and both centers have the independent free coordinates proved in the
folding audit. At p=53, any reported nonunit H other than zero is an error.

The initial affine rows use exact derivatives from Appendix A of
`proof/algebra_orientation_fibers.md`. For reflected-pair direction v, the
derivative polynomial is `v(G+G_i J)` for a Q direction and `v(H+H_i J)` for
a U direction. The center uses a single shift. Right sides come from the
complete parity vector evaluated at the chosen base. F_p is checked as a
constant; no subfield-trace simplification is assumed by the code.

No universal rank-26 assumption or closed-form kernel conjecture is used.
The row system's actual full affine solution is passed to the residual solver.

## 3. Residual quadratic completeness

For each affine parameterization, evaluations at 0, e_i, and e_i+e_j give
the exact degree-two ANF. The implementation transposes coefficient vectors
into scalar output rows, including each row's affine part. Elementary row
operations eliminate nonlinear columns. Rows with no nonlinear part span
all linear combinations of original rows that are affine; their equations
are necessary conditions on every parity zero.

A complete affine restriction is substituted into the original parity map.
If it makes no progress while nonlinear terms remain, the last free variable
is fixed separately to zero and one. These children partition the space.
If all nonlinear terms vanish and the affine system is identically zero,
every assignment is emitted after a direct parity check. There is no rank,
nullity, branch-depth, or observed-solution-count cutoff.

## 4. Separate parity evaluators

The frozen v1 evaluator counts same-side edges with shifted equality masks.
For cross edges of sum s, reflected bit masks align coefficient s-i with i,
and a mask restricts i to
`max(0,s-p+1) <= i <= floor((s-1)/2)`. Thus every unordered edge i<j is
counted once. Its lag bit is `2p-2-s`, exactly lag-1. A literal nested-loop
edge implementation supplies a second acceptance check.

The v2 evaluator uses an independently derived identity. With
`H=Q+R(Q)`, `G=U+R(U)`, `K=H+G`, and `E=Q ⊙ U`, define

\[
Z=J^2+J(K+E+R(E))+QG+UH,\qquad C=EJ+QU.
\]

Then `Z=z^(p-1)D`, and the packed parity vector is

\[
(Z\mathbin{\texttt{>>}}p)\;\mathbin{\mathrm{XOR}}\;
\operatorname{reverse}_{2p-1}(C).
\]

Bit k-1 receives D_k and C_(2p-1-k). The zero-lag coefficient is dropped.
This identity holds for arbitrary q,u when H,G are recomputed as above, so
tests need not assume an inverse fiber. The formula differs from the primary
implementation's q/t group products and `q OR t` expression.

The carryless intrinsic and portable shift/XOR implementation were written
separately from the primary source. They implement the same standard hardware
operation; sharing PCLMUL hardware is not independent hardware verification.
The direct reflection and literal edge oracles remain in the v2 executable,
and both check every emitted orientation.

## 5. Completed validation and measured cost

`results/verification_folded_independent_v2_unit.json` records PASS for:

- 1,984 packed parity versus literal-edge comparisons across all supported
  odd p from 3 to 63.
- 450 affine systems whose entire solution sets were brute-force compared.
- 372 multiplication-matrix inverses compared with a separate polynomial gcd
  and ordinary polynomial product/remainder computation.
- 1,200 analytic derivative comparisons against literal edge differences.
- 100 nonlinear row systems whose complete affine-consequence spans were
  compared by enumerating all combinations of their original rows.
- Entire normalized parity domains at n=6,10,14, plus 33 unfurled or varied
  affine residual spaces. Seven actual branch nodes were exercised.
- 190,464 accelerated-versus-reflection evaluations, including fixed-fiber
  direction changes, and 126,976 intrinsic/portable-versus-literal products.

All unit validation used about 0.184 CPU seconds. The complete orientation
sets at n=34,50,58 agree exactly with the older enumeration (22,28,64 outputs).
Five 4,096-H n=106 strata also agree, including all 13 original pilot outputs.
Those strata extrapolated to about 1.37 aggregate CPU hours for the full
domain, versus 6.82 hours for the frozen reflection version. These were timing
estimates, not completion evidence or guaranteed worst-case bounds.

## 6. Campaign, output integrity, and budgets

`tests/verify_folded_independent_campaign.py` runs four single-threaded workers
over 64 disjoint intervals of size 2^20. The two halves `[0,2^25)` and
`[2^25,2^26)` are separate bounded batches with a checked checkpoint between
them. Each child has CPU, wall, and memory limits. The aggregate allocated
replay budget is 7,200 CPU seconds; each half has a 1,100-second wall limit.

Long-lived child files are private `/tmp` files. Only closed files with parsed
headers, footers, exact counts, source provenance, and verified orientation
sets are copied atomically into the project. Private originals are retained.
The primary result is consulted only after a complete child run, never during
enumeration or pruning. Every emitted orientation also passes a literal
Python parity check. The root performs a separate final rehash and coverage
acceptance audit.

Live CPU lookup by Popen PID underread running solver time in this environment;
reaped RUSAGE and completed native CPU reports agreed. The frozen controller
was not silently replaced. A separate, hashed watchdog scans readable process
metadata for the exact pinned executable, combines live CPU and closed native
reports by H interval, and reserves 200 seconds below the allocation. Its
status is `resource_watchdog.json`; it attempts no access-control bypass.

Standalone source, executable, controller, dependency, and unit-test snapshots
plus a compiler manifest are saved in
`results/campaign_n106_first_parity_independent/`. The compiler manifest gives
the exact C++17 build command and compiler version. Neither a successful
replay nor a small solution count by itself checks the remaining sign and
original-correlation conditions; those have separate certificates.

## 7. Completed full-domain replay

The campaign and external watchdog both exited successfully. The saved result
is `results/campaign_n106_first_parity_independent/final_summary.json`:

- Exactly 67,108,864 H values in 64 disjoint accepted partitions.
- Exactly 102 normalized first-parity orientations, with exact set agreement
  against the primary implementation in every partition and globally.
- First half: 68 orientations, 700.696 seconds wall, 2,784.81849 aggregate
  child CPU seconds.
- Second half: 34 orientations, 734.925 seconds wall. Both halves satisfy
  their separate 1,100-second cap.
- Full child CPU: 5,704.584331 seconds; full wall time: 1,435.630 seconds.
  Sum of native solver reports: 5,704.4228 CPU seconds. The small difference
  covers process work outside the solver's own timed section.
- The watchdog used about 3.648 CPU seconds, terminated no process, and
  observed no live matching worker when the campaign completed.
- No timeout, rejected partition, set mismatch, or missing output occurred.

The final independent aggregate SHA256 is
`0dd49eef995fe3ca1c6d91e5337b8aa6d8d69c2824b1a2e0f69744afc24059b7`.
The exact source and executable hashes remain those in Section 1. All private
raw files, closed published partitions, receipts, and both checkpoints remain
available. The standalone fresh-compiler instructions are in
`REPRODUCE_INDEPENDENT.md`.

This completes the independently implemented first-parity enumeration. Its
mathematical consequence for ordinary Golay pairs additionally uses the
separately checked sign-space and original-correlation arguments. The result
is not presented as a formal proof-kernel derivation or a general solution
of the Golay length conjecture.
