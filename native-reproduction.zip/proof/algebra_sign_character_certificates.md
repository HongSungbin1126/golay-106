# Compact congruence certificates for the eight length-106 sign spaces

Date: 2026-11-05. Status: exact certificates generated from the supplied sign
spaces; independent certificate checking is tracked separately. The full
first-parity domain still requires its separate coverage verification.

The calculation below replaces 136,314,944 sign assignments by small integer
polynomial and binary-linear certificates. It does not independently supply
the upstream list of orientations. Successive reductions modulo powers of
two are established Golay-search techniques, discussed explicitly by
Borwein and Ferguson. No novelty claim is made for that general method.

## 1. Inputs and original-domain convention

Let

\[
r_k(A,B)=\sum_{i=0}^{105-k}a_i a_{i+k}
         +\sum_{i=0}^{105-k}b_i b_{i+k},\qquad 1\le k\le105.
\]

Every polynomial and terminal correlation in this document refers to these
**original integer aperiodic correlations**, not to r_k/4 or a periodic
correlation.

The input is the eight consistent sign spaces in
`results/exact_signs_n106_campaign_kernel_inventory.jsonl`. For an
orientation (q,t), the negative-sign bits eta of the 53 left-column signs
have the exact affine parameterization

\[
\eta=\eta_*+\sum_{j=0}^{d-1}z_j v_j\quad\hbox{over }\mathbb F_2.
\tag{1}
\]

The raw certificate stores eta_*, every v_j, and their order. All integer
masks use low bit = coordinate zero. With s_i=(-1)^(eta_i), the original
binary rows are reconstructed as

\[
a_i=s_i,\quad b_i=(-1)^{q_i}s_i,
\]

\[
a_{105-i}=(-1)^{t_i}s_i,\quad
b_{105-i}=-(-1)^{t_i+q_i}s_i,\qquad 0\le i<53.
\tag{2}
\]

The generator is `src/algebra_sign_characters.py`; its complete trace is
`results/algebra_sign_character_reductions.json`. The input digest recorded
there pins down the exact source spaces. It contains full intermediate
particular solutions and kernels, rather than only a claimed rank.

## 2. Character-polynomial representation

For a bit mask mu and parameter vector z, define

\[
\chi_\mu(z)=(-1)^{\langle\mu,z\rangle},
\qquad \langle\mu,z\rangle=\operatorname{popcount}(\mu\mathbin{\&}z)\bmod2.
\]

Each coefficient a_i or b_i in (2) is a fixed sign times one such character.
Multiplication satisfies chi_mu chi_nu=chi_(mu XOR nu). Thus every original
correlation has the exact integer expansion

\[
r_k(z)=\sum_\mu c_{k,\mu}\chi_\mu(z).
\tag{3}
\]

The program constructs (3) directly by summing all products in the definition
of r_k, combining equal masks and removing zero coefficients. There is no
sampling, numerical fit, or approximation.

For a nonzero polynomial, let g be the positive gcd of its integer
coefficients and put P=r_k/g. This is an exact integer character polynomial.
For the equation r_k=0, division by g is an equivalence. For a modular claim,
the two-adic valuation must instead be tracked: if g=2^v h with h odd and
v<s, then

\[
r_k\equiv0\pmod{2^s}
\quad\Longleftrightarrow\quad
P\equiv0\pmod{2^{s-v}}.
\tag{4}
\]

One must not silently derive P=0 modulo four if s-v<2. The certificates
used below respect this condition explicitly.

## 3. Exact extraction of linear congruences

Write P=sum_mu c_mu chi_mu and C=sum_mu c_mu. Since every character is odd,
P=C modulo two. If C is odd, P cannot vanish modulo two.

If C is even, use

\[
\chi_\mu(z)\equiv1-2\langle\mu,z\rangle\pmod4.
\]

The necessary condition P=0 modulo four becomes the binary linear equation

\[
\left\langle\bigoplus_{\mu:c_\mu\text{ odd}}\mu,z\right\rangle
=C/2\pmod2.
\tag{5}
\]

The generator records the lag, g, C, coefficient mask, and right-hand side
for each such equation. Row reduction retains exact XOR provenance, so an
inconsistency can be checked by XORing the indicated input rows.

If the linear system is consistent, substitution is also exact. For
z=z_*+sum_j y_j w_j,

\[
\chi_\mu(z)=(-1)^{\langle\mu,z_*\rangle}\chi_\nu(y),
\qquad \nu_j=\langle\mu,w_j\rangle.
\tag{6}
\]

The program updates the original sign particular solution and basis, then
rebuilds all original correlations from (2). This avoids treating an
earlier necessary congruence as the full residual equation.

## 4. The eight terminal exclusions

There are four pairs under the legitimate symmetry that reverses A. On
orientation bits this is (q,t)->(q XOR t,t); on left sign bits it is
eta->eta XOR t. Reversal preserves A's aperiodic autocorrelation exactly.

| q mask | t mask | Sign dimension | Exact obstruction |
|---:|---:|---:|---|
| 4503599627370496 | 6905519428634760 | 20 | Eighteen mod-32 equations leave r_4=-160 |
| 2401919801264264 | 6905519428634760 | 20 | Same obstruction |
| 7505999378950826 | 6305039478318694 | 26 | r_24-r_28=16 modulo 32 |
| 3602879701896396 | 6305039478318694 | 26 | Same obstruction |
| 2251799813685248 | 7011648211062416 | 4 | r_33=16 chi_10 |
| 4759848397377168 | 7011648211062416 | 4 | r_33=16 chi_10 |
| 5348024557502464 | 2716569409336474 | 4 | r_9=-16 chi_10 |
| 7501644013417626 | 2716569409336474 | 4 | r_9=-16 chi_10 |

The parameter order for chi_10 is the order of the four basis masks in the
input certificate. Since decimal mask 10 is binary 1010,
chi_10=(-1)^(z_1+z_3). In particular it is always +1 or -1. Each of the last
four correlations is therefore nonzero, and is 16 modulo 32 for every
assignment. A single lag excludes each entire four-dimensional sign space.

### 4.1 The two 26-dimensional spaces

For both spaces the original particular sign mask is zero and the input
kernel has 26 ordered masks. At lags 24 and 28, the coefficient gcd is 8.
Their primitive coefficient sums are 14 and 12, respectively. The odd-mask
XOR in (5) is the same in both cases:

\[
M=33548287=\sum_{j=0}^{24}2^j-2^{11}-2^{12}.
\]

Consequently

\[
r_{24}/8\equiv14-2\langle M,z\rangle\pmod4,
\]

\[
r_{28}/8\equiv12-2\langle M,z\rangle\pmod4.
\]

Subtracting gives

\[
\boxed{r_{24}-r_{28}\equiv16\pmod{32}.}
\tag{7}
\]

Thus these two lags cannot both be zero modulo 32. The Gaussian certificate
is simply the XOR of the two rows: the same linear mask is required to equal
both one and zero. No sign assignments need to be enumerated.

### 4.2 The two 20-dimensional spaces

Use the ordered 20-bit parameter z from the input certificate. It is enough
to retain the following 18 equations from (5). Every row in this table comes
from an original-correlation polynomial with coefficient gcd **exactly 8**.

| Lag k | Primitive coefficient sum C | Linear mask M | Required parity |
|---:|---:|---:|---:|
| 2 | 10 | 2 | 1 |
| 4 | 8 | 393217 | 0 |
| 6 | 6 | 196612 | 1 |
| 8 | 16 | 507913 | 0 |
| 10 | 4 | 221200 | 0 |
| 12 | 2 | 522241 | 1 |
| 14 | 0 | 224288 | 0 |
| 16 | 8 | 524097 | 0 |
| 18 | -2 | 224512 | 1 |
| 20 | -4 | 524257 | 0 |
| 22 | -6 | 224432 | 1 |
| 24 | 0 | 523773 | 0 |
| 26 | -4 | 223670 | 0 |
| 28 | -4 | 524284 | 0 |
| 30 | -4 | 222640 | 0 |
| 32 | 2 | 520160 | 1 |
| 34 | -2 | 216448 | 1 |
| 40 | 2 | 489472 | 1 |

These rows have rank 18. Their complete solution is

\[
z=174763\ \mathbin{\mathrm{XOR}}\ \alpha\,299593
\ \mathbin{\mathrm{XOR}}\ \beta\,524288,
\qquad \alpha,\beta\in\{0,1\}.
\tag{8}
\]

Each selected row is satisfied by this particular solution and annihilates
both kernel masks. Rank 18 then proves completeness of (8), without a
search through the original 2^20 assignments.

In the original 53 sign bits, substitution gives

\[
\eta=3708846773663864
\ \mathbin{\mathrm{XOR}}\ \alpha\,600479950316066
\ \mathbin{\mathrm{XOR}}\ \beta\,6905519428634760.
\tag{9}
\]

Rebuilding the original rows (2) and collecting the character coefficients
at lag four gives the constant polynomial

\[
\boxed{r_4=-160.}
\tag{10}
\]

The two remaining free signs have a useful interpretation. The second
direction is t itself. The XOR of the two directions is q XOR o, where
o=3002399751580330 is the mask of odd indices, for the first orientation.
These span standard MODE-P-preserving sign symmetries: reverse both rows
with the necessary sign normalization, and alternate both rows followed
by row interchange. Thus the four remaining assignments form an ordinary
symmetry orbit. The even-lag correlation r_4 is unchanged by those operations.
The character calculation establishes (10) directly as well.

## 5. Stronger modulus-64 obstruction and its precise dependencies

Conditional on acceptance of the complete upstream orientation and sign-space
coverage, these certificates prove the following stronger finite statement:

> No two binary sequences of length 106 have r_k=0 modulo 64 at every
> nonzero aperiodic lag.

Here is the full implication chain, including the divisions.

First, r_k=0 modulo 64 implies r_k=0 modulo four. Write
a_i=1-2x_i, b_i=1-2y_i and c_i=x_i+y_i modulo two. Expanding r_k, dividing
by two, and reducing modulo two gives

\[
\sum_{i<k}c_i+\sum_{i\ge106-k}c_i=k\pmod2.
\]

Subtract consecutive k identities to obtain c_i+c_(105-i)=1. This is the
mirror condition a_i a_(105-i)+b_i b_(105-i)=0. Independent row negations
and a row interchange establish MODE P and preserve r_k exactly.

The exact quad identity then has the form

\[
r_k=4\sum_{e\in E_k}\gamma_e s_i s_j,
\qquad \gamma_e\in\{+1,-1\}.
\tag{11}
\]

Reducing r_k/4 modulo two yields the first orientation parity system. This
requires only r_k=0 modulo eight, so it follows from the stronger hypothesis.
The complete H-fiber search must cover every one of its solutions; the
reported list has 102 orientations, with its independent replay handled
separately.

For each orientation, r_k=0 modulo 16 implies r_k/4=0 modulo four. Expanding
s_i s_j=1-2(eta_i XOR eta_j) modulo four in (11) gives the second binary
linear sign system. The 94 inconsistent orientations cannot satisfy the
modulus-64 hypothesis. The eight remaining affine spaces are exactly the
inputs to this document, assuming their separately audited particular
solutions and kernels are complete.

In a 26-dimensional space, (7) already contradicts simultaneous vanishing
modulo 32, and therefore modulo 64. In a four-dimensional space, the exact
correlation ±16 chi_10 is nonzero modulo 32, again sufficient.

For a 20-dimensional space, use **only the 18 gcd-eight rows listed above**.
The assumption r_k=0 modulo 64 implies r_k/8=0 modulo eight, hence modulo
four. Thus every equation in that table is a valid necessary condition.
Their complete affine solution is (9), on which

\[
r_4=-160\equiv32\pmod{64},
\]

a contradiction. Equivalently, the terminal gcd is 160=2^5*5, so a
modulus-64 hypothesis would require the terminal primitive constant -1 to
be even. No unsafe division modulo a power of two is used.

This strengthened statement still depends on the complete finite upstream
enumeration. It is not a new general theorem excluding arbitrary lengths.

## 6. Modulus 32 witnesses and exact conditional classification

The two remaining signs in (9) really do give modular solutions. All four
assignments for each of the two 20-dimensional orientations were reconstructed
and checked by both direct integer correlation sums and a separate integer
polynomial convolution. Every one of the eight pairs satisfies every
nonzero-lag correlation modulo 32, and every one fails modulo 64.

A compact representative is specified by

\[
q=4503599627370496,\qquad t=6905519428634760,\qquad
\eta=3708846773663864,
\]

together with the reconstruction (2). Its only nonzero positive-lag
correlations are

\[
(r_4,r_8,r_{12},r_{16},r_{20})=32(-5,4,-3,2,-1).
\tag{12}
\]

Every other r_k is zero. Equivalently, with
\(F(z)=\sum_{j=0}^5(-z^4)^j\), the exact norm identity is

\[
AA^-+BB^-=20+32FF^-.
\tag{13}
\]

The constant term is 20+32*6=212, as required for two length-106 binary
rows. Equation (13) explains the modular flatness without suggesting that
the ordinary Golay identity holds. The combined sidelobe energy is
sum_(k>0)r_k^2=32^2*55=56,320 and max_k|r_k|=160. These are statistics of
this witness orbit, not a claim about a global energy optimum.

Full A,B arrays and all residuals are in
`results/algebra_mod32_witnesses.json`; the eight-case direct checker is
`src/algebra_mod32_witnesses.py`. Its recorded run used 0.019 CPU seconds.

### Exactly eight normalized and 64 raw ordered pairs

Once the complete upstream coverage is accepted, these facts prove an exact
finite classification at modulus 32. Any such pair satisfies the mirror,
first-parity, and second-parity conditions already discussed. The 94
inconsistent orientations fail modulo 16. The four dimension-four and two
dimension-26 sign spaces fail modulo 32. In either remaining dimension-20
space, r_k=0 modulo 32 implies r_k/8=0 modulo four for all 18 selected rows.
Those rows force exactly the four assignments in (9). All four in each
orientation were verified to satisfy every modulo-32 condition. Thus there
are **exactly eight MODE P ordered pairs**.

This count converts to raw ordered pairs without assuming an unverified
orbit size. Consider the eight-element group generated by independently
negating A,B and interchanging the two rows. It acts freely on a pair with
the mirror property. A nonidentity pure negation cannot fix a binary row.
A stabilizer involving interchange would require A=+B or A=-B, and either
relation contradicts a_i a_(105-i)+b_i b_(105-i)=0.

Every orbit has exactly one MODE P representative. Negating each row to
make its first coefficient positive is unique. The two final coefficients
are then opposite by the mirror identity, so there is a unique choice of
whether to interchange rows to make the final A coefficient positive.
Therefore each normalized pair represents exactly eight distinct raw ordered
pairs, and the total count is

\[
\boxed{8\cdot8=64.}
\tag{14}
\]

All eight normalized pairs belong to one orbit under the usual Golay
symmetries. This can be checked constructively. The operation
(A,B)->(reverse A,-reverse B) preserves MODE P and shifts eta by t while
leaving q,t unchanged. Alternating both rows and interchanging them shifts
eta by q XOR o, where o is the odd-index mask, again leaving the orientation
unchanged. These two directions span the two-dimensional space in (9).
Reversing A alone maps (q,t,eta) to (q XOR t,t,eta XOR t), connecting the
two orientations. These operations connect all eight normalized pairs.
The direct witness file also records four two-element A-reversal orbits
and one full standard-symmetry orbit.

### Exact dyadic counting profile

The earlier reductions are equivalences at their respective moduli, so the
same accepted coverage gives more than an upper bound. For a fixed first-
parity orientation, let C_k=sum_e gamma_e in (11). Its edge count is even,
so C_k is even. Modulo four,

\[
r_k/4\equiv C_k-2\sum_e\gamma_e(\eta_i+\eta_j)\pmod4.
\]

Consequently the second binary linear system is equivalent to r_k=0 modulo
16 for all k. Its eight disjoint affine solution spaces contain exactly
4*2^4+2*2^20+2*2^26=136,314,944 normalized pairs.

Similarly, the mirror identities are equivalent to divisibility of every
r_k by four: necessity was proved from the prefix parities, and sufficiency
follows from the exact quad formula (11). The 53 quads each have three
independent signs; MODE P fixes the first quad, leaving 156 bits. At
modulus eight, the first-parity equations depend only on q,t. Each of their
102 orientations allows every one of the 2^52 normalized sign vectors.

Thus the exact conditional profile is:

| Required modulus | Number in MODE P | Number of raw ordered binary pairs |
|---:|---:|---:|
| 4 | 2^156 | 2^159 |
| 8 | 102*2^52 | 102*2^55 |
| 16 | 136,314,944 | 1,090,519,552 |
| 32 | 8 | 64 |
| 64 | 0 | 0 |

The factor-eight normalization argument applies here because each listed
modulus implies the mirror identities. It must not be transferred without
argument to modulus two, which imposes no mirror condition.

Consequently, conditional on complete upstream coverage and independent
certificate acceptance, 64 is the **least power-of-two modulus** for which
there is no binary complementary pair of length 106. The explicit modulo-32
witness also works at every smaller power of two. Failure modulo 64 implies
failure at every larger power of two. This is a fixed-length dyadic
classification, not a general classification of Golay lengths.

## 7. Prior patterns, reproducibility, and status

In Borwein–Ferguson's Section 6 coordinates, their H vector is our q, and
their V vector is the complement of our t bits. The two recurring families
at p=53 are exactly

- q=0^52 1 and V=(1110)^13 0;
- q=(0011)^13 0 and V=(1001)^13 0.

They are the 20- and 26-dimensional cases above, up to A reversal. Section 6
already discusses further sign reductions for these patterns; the final
notes report testing the recurring patterns at prime half-lengths through
total length 500. Therefore excluding these two familiar families at 106
must not be advertised as a new discovery. The other two four-dimensional
orbits are identified here by their exact masks; no claim is made that they
or their one-lag exclusions were previously unknown.

Primary reference: P. Borwein and R. Ferguson, *A complete description of
Golay pairs for lengths up to 100*, Mathematics of Computation 73 (2004),
967–985, Section 6, printed pages 982–983, and Section 8, printed pages
984–985. https://doi.org/10.1090/S0025-5718-03-01576-X

The supplied 102-orientation list was separately checked for literal edge
parities, recomputed H indices, and exact closure under A reversal. It
contains 51 two-element orbits and no fixed orientation; see
`results/algebra_orientation_structure.json`. This structural check does
not replace verification that the list covers the entire H domain.

Reproduce certificate generation with:

```sh
python3 src/algebra_sign_characters.py --output results/algebra_sign_character_reductions.json
```

The recorded generation took 0.0173 CPU seconds. The result is a trace of
exact finite algebra suitable for a distinct checker. Until that checker
and upstream full-domain replay have passed, retain the stated conditional
scope rather than presenting an independently certified global conclusion.
