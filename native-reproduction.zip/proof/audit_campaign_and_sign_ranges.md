# Campaign coverage and sign-range audit

Date: 2026-11-05. Role: ADVERSARIAL_VERIFIER.

Files reviewed: `src/campaign_fibers.py`, `src/exact_sign_refine.cpp`,
`src/exact_quad_v3.cpp` (included F2 solver), and `src/exact_sign_run.py`.
No fatal mathematical omission was found for valid, intact input files.
The final global coverage and artifact-integrity audit is owned by the root
coordinator; this document is not that final acceptance report.

## 1. First-parity controller

For its validated fixed parameters, the controller partitions the requested
H domain into disjoint half-open intervals. A successful receipt requires
zero child exit status, matching interval endpoints, and a completed count
equal to interval length. Failure stops new launches and terminates active
work. The process/RAM limits and live plus reaped CPU accounting apply within
the current controller process.

The final consolidator must independently validate the exact interval union,
source and executable hashes, raw JSONL headers and footers, completion
counts, and orientation records. A filename or success label is insufficient.
On timeout only the declared completed prefix can be considered, and any
partial-fiber records/statistics must be excluded.

Two limitations matter on resume: stored receipts are trusted without
rehashing their artifact files, and the process CPU budget starts again
rather than automatically including prior controller invocations. Prior
resource use must therefore be explicitly included in the project budget,
and final artifact hashes must be recomputed. Missing argument checks for
nonpositive chunk sizes do not affect the current positive, fixed input,
but arbitrary future inputs need validation.

Zero-byte or inode-replaced campaign files reported during the active run
cannot be accepted as complete orientation lists even if a receipt says
complete. Replay or recover intact data and validate it. For the independent
engine, long-lived output files will be written under `/tmp` and copied
atomically to the project only after the process has closed and validated
the output.

## 2. Complete sign affine space

The sign refiner uses q_0=t_0=0 and s_0=+1. Every active-edge signed sum
S_k is even after the first parity equations. Reducing the remaining sign
condition modulo two gives

\[
\sum_{(i,j)\in E_k}(u_i+u_j)=S_k/2\pmod2.
\]

This is exactly the second necessary affine system. The included F2 solver
has distinct least-pivot columns, back-substitutes in descending pivot order,
and supplies one kernel vector per free column. Its particular solution and
kernel therefore cover the entire affine space; no observed nullity cap is
used as a theorem.

Reconstruction matches the quad model: left A bits are u, reversed right A
bits are u XOR t; left B bits are u XOR q, reversed right B bits are
u XOR q XOR t XOR the p-bit all-ones mask. The row-sum square test is an exact
necessary condition at z=1. Surviving assignments are checked by exact
XOR/popcount expressions for all original aperiodic lags. The supported
length and shift bounds fit the unsigned 128-bit representation.

An independent sign-space auditor can derive the same affine system directly
from original integer correlations at u=0 and each one-bit u. First parity
implies divisibility by eight. Constant `r_k(0)/8 mod 2` and single-bit
differences are then the affine coefficients. Checking all exported basis
vectors plus rank and nullity verifies the entire space without using the
edge-row derivation. That separate auditor is assigned to the hardware agent.

## 3. Gray intervals

For a kernel of dimension d, `g(i)=i XOR (i>>1)` permutes `[0,2^d)`.
The refiner initializes at the actual global start index and transitions
using `ctz(i)` of the global index. Thus nonzero starts are handled correctly.
The exact tested interval is `[s_start,s_start+count)`. On timeout the planned
`s_end_exclusive` is not evidence that its entire interval was tested.

Intervals may be combined only when n,q,t, the particular solution, the
**ordered** kernel basis, and the source/dependency hashes agree. A different
kernel order defines a different assignment order. The union must cover
`[0,2^d)` with no gaps, or an independently checked complete pruning
certificate must replace it. A kernel limit or timeout is incomplete.

## 4. Input scope and integrity

The native reader recognizes orientation-looking lines and extracts integers;
it is not a strict JSON parser. Malformed or truncated lines can be skipped,
and an empty list is vacuously complete for its input scope. Therefore
`COMPLETE_INPUT_NO_PAIR` is not, by itself, a global nonexistence statement.

A strict external parser must reject malformed records, verify header/footer
and hashes, and compare the exact canonical orientation set with the complete
first-stage output. Every expected orientation needs either a verified
inconsistent sign system or complete sign-assignment coverage. Duplicate
records must not conceal missing records. Report hashes alone do not prove
the input set was complete.

## 5. Present evidence and limits

The initial 13 n=106 orientations have complete native sign searches:
nine affine inconsistencies, and four kernels of dimensions 20,26,4,4.
Their total assignment count is 68,157,472; 98,306 survived row filtering for
original-lag checks. These counts refer only to those 13 pilot inputs.
The n=58 calibration matches the older exact solver's 36,960 sign assignments,
36,436 row rejects, and 524 original checks. Neither calibration replaces a
complete length-106 orientation and sign coverage argument.
