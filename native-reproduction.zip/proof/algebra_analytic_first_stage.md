# An analytic parameterization of the first affine orientation stage

Date: 2026-11-05. Status: derived with a complete proof below, reviewed by
the root researcher and the independent verifier, and finite validation
completed. The ongoing independent full replay retains its earlier row/RREF
implementation; this later analytic optimization is not a hidden dependency
of that replay. Novelty is not established.

This lemma explains the observed 52-to-26 reduction at n=106 without assuming
that an observed rank is universal. It also removes repeated first-stage
Gaussian elimination. It does not make the remaining parity equations
linear and does not solve a Golay length by itself.

## 1. Setup and notation

Let p=2m+1 be any odd integer >=3. Work in
\(\mathcal A=\mathbb F_2[z]/J\), where \(J=1+z+\cdots+z^{p-1}\).
Since z^p=1, every residue can be represented by p coefficient bits. There
are exactly two such representatives, differing by J. Write norm_0 for the
unique one whose constant coefficient is zero.

The involution is X -> X^-=X(z^-1). The p-term coefficient reversal is
R(X)=z^(p-1)X^-. Let H,G be p-term palindromic polynomials with middle
coefficient zero and

\[
zHG=1\pmod J.
\tag{1}
\]

Thus H,G are units. In the previous notation, G=H+K and U=Q+T. The fiber
conditions are Q+R(Q)=H, U+R(U)=G, q_0=u_0=0. The variable Q/U fiber has
dimension 2m. The free-direction space for either coordinate is

\[
\mathcal V=\{v:R(v)=v,\ v_0=0\},\qquad\dim\mathcal V=m.
\]

Its usual basis consists of reflected pairs z^i+z^(p-1-i), 1<=i<m, and
the center z^m. Define the p-bit output space

\[
\mathcal C=\{w:w_{p-1}=0,\ w_r=w_{p-2-r}\ (0\le r<p-1)\}.
\]

It also has dimension m.

For the original parity vector F, form the explicit affine equations

\[
L_r(Q,U)=F_{r+1}+F_{2p-r-1},\quad 0\le r<p-1,
\qquad L_{p-1}=0.
\tag{2}
\]

Here F_(2p-1)=0, so L_0=F_1. Appendix A of
`proof/algebra_orientation_fibers.md` proves that these are affine on a
fixed H,G fiber. The separate middle equation F_p is constant in the fiber
and is not included in L. At p=53 its constant is zero by the trace argument
in that appendix.

## 2. The homogeneous derivative is an isomorphism

For a U-direction v in V, define

\[
V_H(v)=J(v\mathbin{\odot}H)+vH,
\]

where ⊙ is coefficientwise multiplication. The derivative of L is the
cyclic reduction

\[
\mathcal T_H(v)=V_H(v)\pmod{z^p+1}.
\tag{3}
\]

Indeed the r-th derivative is V_H(v)_(p+r)+V_H(v)_r. The coefficient at
p-1 is zero, because the two contributions there both equal sum_i v_i H_i.

The polynomial V_H(v) is palindromic with 2p-1 coefficient positions. Its
middle coefficient is zero. Cyclic reduction therefore satisfies
w_r=w_(p-2-r) and w_(p-1)=0, so T_H maps V into C.

Moreover

\[
\mathcal T_H(v)=vH\pmod J.
\tag{4}
\]

If T_H(v)=0, the unit H implies v=0 modulo J. A p-term polynomial with
zero residue is either zero or J. The condition v_0=0 excludes J. Thus
T_H is injective. Both its domain and codomain have dimension m, so it is
an isomorphism. The same argument applies to the Q-direction map T_G.

Consequently the derivative of L on the 2m-variable fiber is

\[
(\delta Q,\delta U)\longmapsto
\mathcal T_G(\delta Q)+\mathcal T_H(\delta U),
\tag{5}
\]

and has rank exactly m. This rank statement uses unit H; it is not inferred
from a sample and is not asserted for skipped nonunit H values.

## 3. Every affine right-hand side lies in the same output space

It remains to prove consistency: rank alone does not ensure an affine
system has a solution. Put E=Q⊙U, C=EJ+QU, Z=z^(p-1)D, and
S=C+z^(2p-2)C^-, as in Appendix A. Then

\[
S+Z=N:=J^2+JK+HG,\qquad K=H+G.
\tag{6}
\]

Z is palindromic in 2p-1 positions and its middle coefficient is D_0=1.
N is also palindromic, and N_(p-1)=1: the middle contributions from JK and
HG vanish because K,H,G are palindromic with zero middle coefficient.

By (1), HG=z^(p-1) modulo J. Hence

\[
N+z^{p-1}=JB
\]

for a polynomial B of degree at most p-1. Reversing this product shows
R(B)=B. Its middle product coefficient gives sum_i B_i=0. Therefore the
prefix sums of B have the symmetry

\[
\sum_{i=0}^r B_i=\sum_{i=0}^{p-2-r}B_i.
\]

These prefix sums are exactly the coefficients N_r for 0<=r<p-1.
Thus the low p-1 coefficient portion of N belongs to C.

Equation (2) can now be written as

\[
L_r=Z_{p+r}+Z_r+N_r,\quad 0\le r<p-1.
\]

The first two terms have the C symmetry because Z is palindromic, and so
do the last terms. Therefore L(Q,U) belongs to C for every point in the
fiber. Since T_H is onto C, every such affine system L=0 is consistent.

This proves: **the equations L=0 always cut the fiber to an affine space
of dimension m**, for every odd p and unit H with its inverse partner G.
The separate F_p equation can still reject that whole space.

## 4. Explicit particular solution

Take any initial Q_b,U_b satisfying the fiber and endpoint conditions,
for example the upper halves of H,G with zero center. Compute
w=L(Q_b,U_b). Then

\[
v=\operatorname{norm}_0(H^{-1}w)
=\operatorname{norm}_0(zGw)\pmod J
\tag{7}
\]

is exactly T_H^-1(w). The representative belongs to V, by the isomorphism
in Section 2. Thus

\[
Q_*=Q_b,\qquad U_*=U_b+v
\]

satisfies every L equation. A verifier should explicitly check R(v)=v,
v_0=0, and the resulting L=0; these are inexpensive and guard the
normalization and shift conventions.

## 5. Explicit full homogeneous kernel

Let

\[
\mathcal I=\{X\in\mathcal A:X^-=X\}.
\]

This invariant subspace has basis

\[
e_k=z^k+z^{p-k},\qquad 1\le k\le m.
\tag{8}
\]

To see completeness without an irreducibility assumption, take the
constant-zero p-bit representative of any invariant residue. Its reversal
under z -> z^-1 differs from itself by a multiple of J. That difference
has constant coefficient zero, so it cannot equal J and must be zero.
Its nonconstant coefficients therefore come in the disjoint pairs k,p-k,
which proves the asserted basis and dimension m.

For X in I, define

\[
\delta Q=\operatorname{norm}_0(HX),\qquad
\delta U=\operatorname{norm}_0(GX).
\tag{9}
\]

These representatives belong to V. Indeed H^-=zH and X^-=X imply the
p-term reversal identity modulo J. The exact difference R(delta Q)+delta Q
has middle coefficient zero, so it cannot be J and must be zero; similarly
for delta U.

The image of (9) under (5) is an element of C and is zero modulo J, because
delta Q G+delta U H=HXG+GXH=0. An element of C with zero residue is zero:
its coefficient at p-1 is zero, whereas that coefficient of J is one.
Thus (9) lies in the homogeneous kernel. The map is injective because H is
a unit. Its m-dimensional image is therefore the entire kernel, whose
dimension is m by Section 2.

Equations (7)-(9) are a complete analytic parameterization of L=0.

## 6. Implementation and limitations

For basis element e_k, cyclic multiplication in (9) is just

\[
H e_k=\operatorname{rot}_p(H,k)+\operatorname{rot}_p(H,-k),
\]

and the analogous expression for G. Toggle J if the result's constant bit
is one. These are the two p-bit representatives of the same residue, and
the toggle selects norm_0. No initial Gaussian elimination is needed.

The value of L(base) can be obtained from one complete F evaluation using
(2). The subsequent correction uses one modular product with zG. All
remaining original F equations, including F_p, must then be solved over
the m free parameters. They remain quadratic in general; the previously
recorded nonlinearity counterexample still applies.

Completed validation is in `src/algebra_validate_analytic_stage.py` and
`results/algebra_analytic_stage_validation.json`. In 2.25 CPU seconds, the
test covered every unit H for p=3,5,7,9,13,17: respectively 1,3,7,7,63,225
unit fibers. It compared exact affine cosets against independently built
literal-edge affine equations and checked every mixed second difference.
It then checked all 61,814 small residual assignments. The resulting first
parity orientation counts were 0,4,0,4,18,22. The n=34 full orientation set
exactly matched the earlier native q-by-q enumeration. This is bounded
implementation validation; the general rank claim rests on the proof above.
