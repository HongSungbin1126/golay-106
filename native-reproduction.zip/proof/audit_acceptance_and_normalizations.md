# Independent acceptance and normalization audit

Date: 2026-11-05. Reviewer: `/root/information_control`.

Status: the identities below were derived directly from the target equations.
They are established elementary Golay reductions, not new research results.
The historic source is Borwein–Ferguson, Proposition 2.1 and Section 3; exact
locations and limits are recorded in `sources/status_ledger.jsonl` (STATUS-01).

## 1. Why the independent checker accepts exactly the original target

Let N=n-1, A(z)=sum_i a_i z^i, and A_rev(z)=sum_j a_(N-j) z^j.
The coefficient of z^(N+k) in A(z) A_rev(z), for k>=0, is

    sum_(i=k)^N a_i a_(i-k) = C_A(k).

The coefficient at N-k has the same value, by reversing the product indices.
The central coefficient is sum_i a_i^2=n after the alphabet has been checked.
Therefore ordinary binary aperiodic complementarity is equivalent to the full
coefficient identity

    A(z) A_rev(z) + B(z) B_rev(z) = 2n z^N.

`src/verify_independent.py` multiplies the two ordinary polynomials over the
integers and compares all 2n-1 coefficients with this target. It does not use an
n-point DFT, circular wraparound, a floating tolerance, a search score, or a
necessary-condition shortcut. Strict type checks exclude booleans, floats,
complex phases, zeros, missing positions, empty sequences and unequal lengths.
The JSON front end also rejects repeated keys and an inconsistent n field.

The semigroup test independently enumerates the finite possibilities for powers
of 10 and 26 up to n, then tests whether the remaining quotient is a power of2.
It supplies a literal witness (a,b,c) when n=2^a10^b26^c. This is a check of the
conjectured length set, not a proof that the set contains all possible lengths.

## 2. Derivation of the mirror identity and the even-length exception

Write a_i=(-1)^x_i, b_i=(-1)^y_i with x_i,y_i in {0,1}. At nonzero lag k,
the exact equation r_k=0 is equivalent to the integer equality

    sum_(i=0)^(n-k-1) [(x_i XOR x_(i+k)) + (y_i XOR y_(i+k))] = n-k.

Put z_i=x_i+y_i in F2. Reducing the preceding equality modulo2 cancels every
overlapping interior index, yielding

    B_k := sum_(i=0)^(k-1) z_i + sum_(i=n-k)^(n-1) z_i = n-k in F2.  (1)

This boundary formula is valid even when the two boundary intervals overlap:
overlapping entries occur twice and cancel in F2.

If n=2m+1>1, both k=m and k=m+1 are nonzero allowable lags. Their left sides
are equal in F2, because the central entry is counted twice in B_(m+1).
Their right sides differ by1. This contradiction excludes odd lengths n>1;
n=1 is the separate valid trivial case.

For n=2m, define B_0=0. The required equality at k=0 is now also true in F2
because n is even; no zero-lag complementarity equation is being assumed.
Subtract (1) at consecutive k=1,...,m:

    z_(k-1) + z_(n-k) = 1 in F2.

Thus x_i+x_(n-1-i)+y_i+y_(n-1-i) is odd. Converting back to signs gives

    a_i a_(n-1-i) + b_i b_(n-1-i) = 0,  0<=i<m.

The proof uses every necessary hypothesis and does not claim that the mirror
conditions suffice for complementarity.

## 3. Target-preserving symmetries

Negating either complete sequence changes each of its correlation products by
the factor (-1)^2=1. Swapping the sequences preserves their sum. Reversing a
sequence changes the order in which a given overlap's products are summed.
Common alternation, a_i -> (-1)^i a_i and b_i -> (-1)^i b_i, multiplies r_k
by (-1)^k, preserving every zero equation.

Cyclic shifts are not an ordinary aperiodic symmetry. The regression fixture
A=(1,1,1,-1), B=(1,1,-1,1) is complementary. Shifting B right once makes B=A;
the resulting residuals are (2,0,-2), whose energy is8 even though the periodic
residuals vanish. The independent checker rejects it.

MODE P is complete: independent negations make a_0=b_0=1, and r_(n-1)=0 then
forces the final signs to be opposite. A row swap can make a_(n-1)=1. There
is no additional R106 row-sum normalization in this mode.

## 4. Exact length106 row and parity-block normalization

Evaluation of the Laurent identity at z=1 and z=-1 gives

    A(1)^2+B(1)^2 = A(-1)^2+B(-1)^2 = 212.

Each row sum is even and has absolute value at most106. The only nonnegative
unordered even solution of u^2+v^2=212 is {14,4}. Independent negation and row
exchange permit A(1)=14, B(1)=4.

Each row contains53 even and53 odd positions. If t=A(-1), then its two partial
sums are (14+t)/2 and (14-t)/2, both odd. The alternatives t=+/-14 would make
these sums even. Hence t=+/-4; correspondingly u=B(-1)=+/-14. These are exactly
the four surviving scalar branches. Reversing one even-length row leaves its
row sum unchanged and changes the sign of its alternating sum, so independent
reversals permit t=4 and u=14. The resulting partial sums are

    (A_even,A_odd,B_even,B_odd) = (9,5,9,-5),

and the four negative-symbol counts are (22,24,22,29).

This proves MODE R106 completeness by itself. It does not justify simultaneously
imposing the MODE P endpoint restrictions. A regression pair with exactly these
four counts but energy689840 is rejected, demonstrating that the checker does
not substitute these necessary conditions for the original equations.

## 5. Executed validation and its limits

Run: `python3 tests/verify_independent_suite.py`.

`results/verification_initial.json` records4,409 successful checks,26 seed or
construction fixtures, and normalized exhaustive pair counts through n=8:
1,2,0,8,0,0,0,48. The normalizing first symbols are independently +1, which
preserves full existence coverage by whole-row negation. Valid fixtures include
length676. The test explicitly rejects malformed inputs, a periodic-only pair,
and the row-condition-only length106 trap.

The test extracts only seed literals and the two constructor AST nodes from the
bootstrap. It does not load or execute the bootstrap correlation or acceptance
functions. The trusted checker itself imports no bootstrap code.

Passing these regressions is evidence against implementation errors. The
coefficient and reduction arguments above establish the mathematical meaning;
the tests alone are neither a universal proof nor a result at an open length.
