# A fixed second affine projection after analytic folding

Date: 2026-11-05. Status: derived proof, independently hand-audited by the
verifier; implementation validation remains pending. This lemma is **not a dependency of the frozen independent
length-106 replay**. No code from that replay is changed here. Novelty is
not established.

## 1. Statement

Use the notation and first affine parameterization proved in
`proof/algebra_analytic_first_stage.md`. Let p=2m+1 be odd, J=1+...+z^(p-1),
and let zHG=1 modulo J. After imposing the explicit first affine equations
L=0, parameterize Q,U by m bits using kernel directions

\[
\delta Q=\operatorname{norm}_0(HX),\qquad
\delta U=\operatorname{norm}_0(GX),\qquad X^-=X.
\]

Let the **positive parity polynomial** be

\[
\mathcal F(z)=\sum_{k=1}^{2p-1}F_kz^{k-1}.
\]

Every mixed quadratic coefficient of this vector-valued Boolean polynomial
lies in the fixed space

\[
\mathcal W=\{Jb:R_p(b)=b,\ b_0=b_m=0\},\qquad
\dim\mathcal W=m-1.
\tag{1}
\]

In particular, **F modulo J is affine in the m remaining parameters**.
Solving F=0 modulo J is a sound additional linear restriction. The full
equations F=0 must still be retained afterwards.

## 2. Proof by polarization

Recall E=Q⊙U, C=EJ+QU, and that the difference-edge polynomial D is affine
on every fixed H,G fiber. Choose two homogeneous first-stage directions
(Q_a,U_a),(Q_b,U_b). The mixed quadratic coefficient of C is exactly

\[
B_C=J(Q_a\mathbin{\odot}U_b+Q_b\mathbin{\odot}U_a)
      +Q_aU_b+Q_bU_a.
\tag{2}
\]

Modulo J, the ordinary products in (2) cancel:

\[
Q_aU_b+Q_bU_a=HX_aGX_b+HX_bGX_a=0.
\]

Therefore B_C is divisible by J as an ordinary polynomial. Its degree is
at most 2p-2, so B_C=Jb with deg b<=p-1.

Every direction Q_a,U_a,Q_b,U_b is p-term palindromic and has constant
coefficient zero. It follows that B_C is palindromic with width 2p-1.
Its endpoint coefficients are zero. Its middle coefficient is also zero:
the coefficient at p-1 of the J times coefficientwise-product term is
sum_i (Q_(a,i)U_(b,i)+Q_(b,i)U_(a,i)); the middle coefficient of the ordinary
products is the same sum, by palindromicity. These cancel over F_2.

Because J is palindromic, reversing the product Jb now proves R_p(b)=b.
The constant coefficient gives b_0=0. The middle coefficient of Jb equals
sum_i b_i, which equals b_m for a palindromic p-term b; hence b_m=0.
This proves the asserted form.

The quadratic part of D is zero. In the positive parity polynomial, the
cross contribution is C reversed with width 2p-1. Since B_C is already
palindromic in that width, its reversal is itself. Thus B_F=B_C, proving
(1). Multiplication by J is injective in the ordinary polynomial ring;
the b-space has one free bit for each reflected pair except the endpoint
pair, giving dimension m-1.

## 3. What the projection retains

After L=0, F_k=F_(2p-k), and F_(2p-1)=F_1=0. If the separate constant
middle equation F_p=0 has passed, F is palindromic with width 2p-1,
zero endpoints, and zero middle coefficient. Call this (2m-1)-dimensional
output space S.

The kernel of reduction modulo J within S is exactly W: if F=Jb, the same
reversal/endpoint/middle argument forces the conditions in (1), and the
converse is immediate. Thus the projected output has dimension m.
The next necessary affine system has m inputs and at most m independent
outputs, though it need not have full rank.

This is an affine projection of the positive-lag polynomial F. It is not
the earlier Laurent-polynomial reduction used to derive zHG=1; those are
different polynomials and different logical steps.

## 4. Prospective complete algorithm

For each unit H:

1. Compute G and the complete analytic affine space L=0.
2. Test the constant F_p condition.
3. Evaluate F modulo J at the base point and the m basis translates.
   These m+1 values determine the entire affine residue map exactly.
4. Solve the resulting binary linear system, retaining its full particular
   solution and kernel. Reject only if it is inconsistent.
5. On the remaining affine space, solve every original F equation, using
   exact quadratic elimination and exhaustive branching when required.

The projection is sound even if the actual quadratic coefficient span is
smaller than W. It may then extract fewer linear consequences than a full
ElimLin step, but it cannot remove a genuine solution. The retained full
equations and branch fallback preserve completeness.

For m=26 this first projected pass needs 27 F evaluations, compared with
352 evaluations to recover all constant, linear, and mixed coefficients
by point evaluation. This is an operation-count comparison, not a measured
runtime result. The two algorithms may use different arithmetic costs and
have different residual dimensions.

## 5. Why rank 25 must not be asserted universally

Take H=G=J+z^m. Then zHG=z^(2m+1)=1 modulo J. Every first-stage kernel
direction has delta Q=delta U, so T=Q+U is constant on that affine space.
With t fixed, the original edge-parity indicators are affine in q.
Therefore the entire residual F is affine and its quadratic coefficient
span is zero, not m-1.

This explicit exceptional family rules out turning a commonly observed
quadratic rank into a universal theorem. The upper bound (1) is the proved
statement. No implementation has been changed or benchmarked on the basis
of this additional lemma in this document.
