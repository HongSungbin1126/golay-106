# Folding the first quad parity system into reciprocal-polynomial fibers

Date: 2026-11-05. Authoring role: ALGEBRA_RESEARCHER.

Status: a proved necessary algebraic reduction with a complete finite search
prototype and small-domain cross-checks. It does **not** solve length 106 or the
Golay length conjecture. Novelty of the Golay-specific folding identity has not
been established. Quad reduction is established work (Andres; Borwein–Ferguson).
Repeated linear extraction and substitution is an **ElimLin-style** method, not
a claimed new general MQ algorithm.

## 1. Definitions, signs, and the exact parity target

Let n=2p with p>=3 odd. The usual necessary mirror identities permit the quad
parameterization

\[
L_i=(s_i,s_i q_i^{\rm sign}),\qquad
R_i=(t_i^{\rm sign}s_i,-t_i^{\rm sign}s_iq_i^{\rm sign}),
\quad 0\le i<p,
\]

where L_i is column i and R_i is column n-1-i. All three sign variables are
in {+1,-1}. We use bits q_i=(1-q_i^{sign})/2 and t_i=(1-t_i^{sign})/2 below.
MODE P gives s_0=q_0^{sign}=t_0^{sign}=+1, hence q_0=t_0=0.

Here is a self-contained justification of the necessary mirror condition and
this normalization. Write a_i=1-2x_i and b_i=1-2y_i, with x_i,y_i binary, and
put c_i=x_i+y_i modulo two. Divide the zero correlation sum at lag k by two
and reduce modulo two. Since n is even, this gives

\[
\sum_{i=0}^{k-1}c_i+\sum_{i=n-k}^{n-1}c_i=k\pmod2.
\]

For k=0 the empty-sum identity is also valid. Subtracting the identities at
k and k-1 gives c_(k-1)+c_(n-k)=1. Hence
a_i a_(n-1-i)+b_i b_(n-1-i)=0 for every reflected pair. Independently negate
A and B to make a_0=b_0=+1. Their last signs must be opposite by the mirror
condition; interchange A and B if necessary to make a_(n-1)=+1 and
b_(n-1)=-1. Negation and interchange preserve every correlation sum. Thus
MODE P loses no existence case. Taking s_i=a_i, q_i^{sign}=b_i/a_i, and
t_i^{sign}=a_(n-1-i)/a_i now gives the stated quad representation exactly.

For i<j, the original correlation residual divided by four has an edge at:

- lag j-i when q_i=q_j, with the edge active when t_i=t_j;
- lag 2p-1-i-j when q_i!=q_j, again active when t_i=t_j.

To check that no terms are missing, the two same-side dot products sum to
\((1+q_i^{sign}q_j^{sign})(1+t_i^{sign}t_j^{sign})s_i s_j\).
The two cross-side dot products sum to
\((1-q_i^{sign}q_j^{sign})(t_i^{sign}+t_j^{sign})s_i s_j\).
The self-reflected dot product is zero. Thus an active same-side edge has
signed weight 4s_i s_j and an active cross-side edge has signed weight
4t_i^{sign}s_i s_j, exactly at the lags stated above. These exhaust all
unordered pairs of original columns.

Reducing the signed edge sum modulo two removes its sign. Let F(q,t) be the
vector of these edge-count parities, one coordinate for each lag 1,...,2p-1.
The first parity target is exactly F(q,t)=0. This target is only a **necessary**
condition for an original Golay pair. The subsequent sign system and original
integer correlations must still be checked.

As Boolean functions, the two edge indicators are

\[
(1+q_i+q_j)(1+t_i+t_j),\qquad
(q_i+q_j)(1+t_i+t_j),
\]

respectively, over F_2. In particular F has algebraic degree at most two.

## 2. Polynomial identity forced by the first parity target

Work over F_2. Put

\[
J=1+z+\cdots+z^{p-1},\quad
Q=\sum_iq_i z^i,\quad T=\sum_it_i z^i,\quad
M=\sum_iq_it_i z^i.
\]

Here M is a **coefficientwise** product, not the ordinary polynomial product QT.
For a polynomial X, use X^-(z)=X(z^{-1}). Define

\[
D=JJ^-+(Q+T+M)J^-+J(Q^-+T^-+M^-)+QT^-+TQ^-.
\]

For k>0, the coefficient of z^k in D is precisely the parity of the active
same-q edges at difference k. This follows by expanding
(1+q_i+q_j)(1+t_i+t_j). The constant coefficient of D is p mod 2 = 1.

Define the ordinary polynomial

\[
C=(Q+M)J+QT+Q^2.
\]

The coefficient of z^u in C is precisely the parity of active different-q
edges with i+j=u. For off-diagonal i<j, its coefficient is
(q_i+q_j)(1+t_i+t_j). The diagonal contribution cancels because
(q_i+q_it_i)+q_it_i+q_i=0. Consequently

\[
F(q,t)=0\quad\Longleftrightarrow\quad
D+1+z^{2p-1}C(z^{-1})+z^{-(2p-1)}C(z)=0
\tag{1}
\]

as an exact Laurent-polynomial identity over F_2.

Now reduce (1) modulo J. Since (z+1)J=z^p+1, we have z^p=1 in the quotient;
z is a unit. Terms containing J disappear. With Z=Q+T, the resulting identity
is

\[
1=QZ^-+ZQ^-+z^{-1}Q^-Z^-+zQZ
 =(Q+z^{-1}Q^-)(Z^-+zZ).
\]

For p-term coefficient reversal, R(X)=z^{p-1}X(z^{-1}). Let

\[
H=Q+R(Q),\qquad K=T+R(T).
\]

Modulo J, R(X)=z^{-1}X^-. Therefore every first-parity solution satisfies

\[
\boxed{zH(H+K)=1\pmod J.}
\tag{2}
\]

This proof uses p odd in the constant coefficient of D. It does not assume p
prime. For even p that constant becomes zero, so this inversion reduction must
not be imported unchanged.

## 3. What the identity determines, and what it does not

Equation (2) proves that H is a unit modulo J and

\[
K=H+z^{-1}H^{-1}\pmod J.
\tag{3}
\]

Both H and K are palindromic p-term polynomials with middle coefficient zero.
Every such H is uniquely represented by its first m=(p-1)/2 coefficients:
H=h+R(h), where deg h<m. There are 2^m choices, including H=0, which is rejected.

To recover K exactly from its residue modulo J, first reduce to degree <=p-2.
There are exactly two representatives of degree <=p-1, differing by J; select
the one with middle coefficient zero. This selected representative is
palindromic: H^-=zH in the quotient, and (3) gives K^-=zK. Thus R(K)=K modulo J.
The difference R(K)+K has middle coefficient zero, so it cannot equal J and
must be zero as a polynomial.

For fixed H and K, q_0=t_0=0, every q,t is obtained exactly once by freely
choosing q_i,t_i for 1<=i<=m and setting their reflected partners from H,K.
The center i=m is free; the other pairs satisfy q_{p-1-i}=q_i+H_i and
t_{p-1-i}=t_i+K_i. Hence each fiber starts with 2m=p-1 Boolean variables.

The original F=0 equations MUST still be imposed inside this fiber. Equation
(2) alone is not sufficient.

### Specialization to n=106

Here p=53, m=26. Elementary modular arithmetic gives 2^26=-1 mod 53 and
2^4!=1 mod 53; since 52=4*13, ord_53(2)=52. Thus J_53 is irreducible over F_2.
Every nonzero H in this 26-dimensional folded space is a unit.

If z denotes the root in F_{2^52}, define x=z^{-26}H. Reversal invariance gives
x(z^{-1})=x(z). Since z^{-1}=z^{2^26}, x belongs to F_{2^26}. Equation (2) says
that z^{-26}(H+K)=x^{-1}. It is the **normalized** H that lies in this subfield;
H itself should not be described as fixed under z -> z^{-1}.

The outer domain is therefore 2^26 choices, of which exactly 2^26-1 are units.
This reduces the outer enumeration from 2^52 q assignments, but the cost of
solving every residual fiber must be measured. No total runtime claim follows
from the smaller outer exponent alone.

## 4. Complete elimination inside a fiber

For a current affine parameterization of q,t by u in F_2^d, write

\[
F(u)=c+\sum_iL_i u_i+\sum_{i<j}B_{ij}u_i u_j.
\]

All c,L_i,B_ij are vectors in the parity-output space. The prototype obtains
these coefficients exactly using F(0), F(e_i), and F(e_i+e_j). Degree at most
two makes this exact, not interpolation from a heuristic sample.

Let W=span{B_ij}, and let pi be any linear quotient map with kernel W. Then
every solution satisfies the affine linear system

\[
\pi(c)+\sum_i\pi(L_i)u_i=0.
\tag{4}
\]

If (4) is inconsistent, the fiber has no solution. Otherwise compute a full
particular solution plus a basis of its kernel, substitute into the **entire**
F, and repeat. This is an ElimLin-style extraction of linear consequences.

If no dimension reduction occurs and a quadratic term remains, split a free
variable into 0 and 1 and recurse on both children. These children are disjoint
and cover the parent. If all quadratic terms vanish and the linear system has
rank zero with zero constant, all remaining assignments are solutions.

Therefore the algorithm is complete without assuming any observed rank or
nullity pattern. A time limit makes the result incomplete and is labeled TIMEOUT.

## 5. A tempting but false stronger claim

Fixing H,K does **not** make all first-parity equations linear. Under MODE P,
the lag 2p-2 has just the cross edge (0,1), giving

\[
F_{2p-2}=q_1(1+t_1).
\]

Simultaneously toggling q_1,q_{p-2} preserves H; similarly toggling
t_1,t_{p-2} preserves K. The mixed second difference of this coordinate is 1.
This holds for p>=5, even in a fiber satisfying (2). Linear consequences are
useful, but residual quadratic constraints must be retained.

## 6. Implementations, completed comparisons, and claim limits

Reference implementation: `src/algebra_orientation_fibers.py`.
Integer bit masks represent F_2 polynomials, low bit = constant coefficient.
The script enforces one process, <=1 GiB address space, and a CPU deadline.

Completed results:

| n | Entire H domain | Unit H | First-parity orientations | Independent comparison |
|---|---:|---:|---:|---|
| 10 | 4 | 3 | 4 | Exact match to separate q-by-q enumeration |
| 34 | 256 | 225 | 22 | Exact match to complete native q-enumeration JSONL |
| 50 | 4096 | 3069 | 28 | Exact match to complete native q-enumeration JSONL |

Measured Python CPU times were approximately 0.82 s at n=34 and 58.99 s at n=50.
The datasets are `results/algebra_orientation_fibers_n10.json`,
`results/algebra_orientation_fibers_n34.json`, and
`results/algebra_orientation_fibers_n50.json`.
No branching fallback was required in those completed domains; this is an
observation, not a theorem that branching will never be required.

These are first-parity enumerations, not original-domain nonexistence proofs.
The counts 22 and 28 use weaker normalization than the canonical counts 11 and
14 reported in Borwein–Ferguson Section 6. Matching them is reproduction.

## 7. Prior work and novelty ledger

- Borwein and Ferguson, *A complete description of Golay pairs for lengths up
  to 100*, Math. Comp. 73 (2004), 967–985, Sections 2 and 6. The quad/parity
  framework and successive linear systems are established, as are Gray-code
  updates and prefix-based skips.
  https://doi.org/10.1090/S0025-5718-03-01576-X
- *ElimLin Algorithm Revisited*, FSE 2012. The general principle of extracting
  linear equations by eliminating nonlinear monomials, substituting, and
  repeating is established. Do not claim the projection loop as a new general
  solver.
  https://www.iacr.org/archive/fse2012/75490310/75490310.pdf
  Authors: Nicolas T. Courtois, Pouyan Sepehrdad, Petr Sušil, and Serge Vaudenay.
  LNCS 7549, pp. 306–325; https://doi.org/10.1007/978-3-642-34047-5_18.
- The explicit Golay folding identity (2) and this precise integration were
  derived in this project. A narrow search did not locate an identical use,
  but that is not evidence of novelty. Status: **NOVELTY_NOT_CHECKED** pending
  deeper study of prior Golay polynomial/orientation work.

The project seeks useful reproducible progress, not a novelty claim based on
failure to find a search result.

### Additional n=106 cross-check

The independent Python reference, using the direct edge definition of F,
was compared against the optimized native implementation on 76 distinct
complete H fibers: 64 seeded random values across the full domain and 12
fibers containing the 13 orientations found in the native initial pilot.
Their full (q,t) solution sets agree, including all 13 positive orientations.
The report is `results/algebra_native_fiber_crosscheck_n106.json`, recording
source and executable hashes. This checks selected complete fibers; it is
not a complete n=106 search and does not settle length 106.

## Appendix A. Explicit affine equations for a different implementation

This appendix supplies direct linear consequences of the fiber equations.
It does not require finding a basis of the initial quadratic image. An
independent implementation can use these consequences, retain the complete
F system, and subsequently perform its own row-oriented ANF elimination.

Use U=Q+T, G=H+K, and E=Q⊙U, where ⊙ means coefficientwise multiplication.
Then U+R(U)=G and Q+M=E, so the earlier cross-edge polynomial becomes

\[
C=EJ+QU.
\tag{A1}
\]

The reversal R in this paragraph has p coefficients. Define S using the
different reversal width 2p-1:

\[
S=C+z^{2p-2}C(z^{-1}).
\]

Since R(Q)=Q+H and R(U)=U+G,

\[
E+R(E)=Q\mathbin{\odot}G+H\mathbin{\odot}U+H\mathbin{\odot}G,
\tag{A2}
\]

\[
S=J(E+R(E))+QG+UH+HG,
\tag{A3}
\]

\[
z^{p-1}D=J^2+J(K+E+R(E))+QG+UH.
\tag{A4}
\]

Every right-hand side is affine in the coefficients of Q,U when H,G,K
are fixed. Equation (A2) follows by expanding
Q⊙U+(Q+H)⊙(U+G). For (A3), reverse EJ+QU and cancel the two QU terms.
For (A4), multiply the definition of D by z^(p-1), use R(J)=J,
Q+T+M=T+E, and
Q R(T)+T R(Q)=QG+UH. These establish affine dependence exactly; they do
not assume an observed Gaussian-elimination rank.

Let F_k be the parity at lag k. From the coefficient description in
Section 2,

\[
F_k=D_k+C_{2p-1-k}\quad(1\le k<p),\qquad
F_k=C_{2p-1-k}\quad(p\le k<2p).
\]

The endpoint coefficients C_0 and C_(2p-2) vanish because diagonal terms
cancel. Therefore the following combinations are affine:

\[
F_1=D_1,\qquad
F_k+F_{2p-k}=D_k+S_{k-1}\quad(2\le k<p).
\tag{A5}
\]

There is also the constant condition

\[
F_p=C_{p-1}=\sum_{i=0}^{p-1}q_iG_i
=\sum_{i=0}^{m-1}H_iG_i,\qquad m=(p-1)/2.
\tag{A6}
\]

Indeed C_(p-1)=sum_i q_i u_i+sum_i q_i u_(p-1-i); the two sums combine
to sum_i q_i G_i. Since G is palindromic with middle coefficient zero,
each reflected pair contributes G_i(q_i+q_(p-1-i))=G_iH_i.

For p=53, (A6) is automatically zero for the inverse partner. Here is an
algebraic explanation. Let z be a root of J_53 and m=26. The elements
e_k=z^k+z^(-k), 1<=k<=26, form a basis of F_(2^26). Their absolute traces
satisfy Tr(e_k)=1, since the exponents ±2^j k, 0<=j<26, run through all
nonzero residues modulo 53. Thus Tr(e_k e_l) is 1 for k=l and 0 otherwise:
use e_k e_l=e_(k+l)+e_(k-l), with e_0=0. This also establishes the basis
independence. Writing x=z^(-26)H and y=z^(-26)G in this basis gives

\[
\sum_{i<26}H_iG_i=\operatorname{Tr}(xy)
=\operatorname{Tr}(1)=26\bmod2=0.
\]

The normalized field relation xy=1 follows from zHG=1. This argument does
not assert the same irreducible-field construction at arbitrary composite p.

Implementation coordinates: q_0=u_0=0, since t_0=q_0+u_0=0. Select the free
q_i,u_i for 1<=i<=m, including the center. The reflected partners are fixed
by H,G. Convert back to the original output convention by t=q XOR u.

It is safe to impose (A5)-(A6) before another complete solver. It is not
necessary to assert that they span every affine consequence; residual
F=0 equations must always be retained. A later stalled quadratic solver
still needs exhaustive branching.

For efficient independent construction of these affine rows, take any
symmetric free direction v (a reflected pair of basis bits, or the center
basis bit). A Q-direction has the shared polynomial derivative

\[
\Delta(z^{p-1}D)=\Delta S=J(v\mathbin{\odot}G)+vG;
\tag{A7}
\]

an U-direction instead gives J(v⊙H)+vH. If this polynomial is V, the
derivative of F_1 is V_p, and the derivative of F_k+F_(2p-k) is
V_(p-1+k)+V_(k-1). The derivative of F_p is zero. These expressions follow
directly from (A3)-(A4); H,G,K are fixed, so their terms do not contribute.
They construct the first affine rows without repeated whole-F evaluations.
For v=z^i+z^(p-1-i), i<m, palindrome symmetry gives
V=v(G+G_i J), so only two shifts and an XOR are needed. For the center
direction v=z^m, V=z^m G since G_m=0. Replace G by H for U-directions.
