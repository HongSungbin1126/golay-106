# Independent audit of folded first-parity enumeration

Date: 2026-11-05. Role: ADVERSARIAL_VERIFIER.

**Verdict:** the mathematical reduction and complete residual-fiber algorithm
are sound under the stated ordinary binary, aperiodic, even-length hypotheses.
This is a source and proof audit, not a completed independent length-106 replay
or a formal-kernel certificate. A first-parity result alone does not decide
Golay existence. Novelty is not assessed here.

## 1. Domain coverage

The independently audited mirror argument and MODE P normalization are in
`proof/audit_acceptance_and_normalizations.md`. They give, for every possible
pair of length `2p`, a quad representation with `q_0=t_0=0` in bit notation and
the first sign bit zero. No row-sum normalization is added. The two same-side
dot products have sum

\[
(1+q_i^{\rm sign}q_j^{\rm sign})(1+t_i^{\rm sign}t_j^{\rm sign})s_i s_j,
\]

and the two cross-side dot products have sum

\[
(1-q_i^{\rm sign}q_j^{\rm sign})(t_i^{\rm sign}+t_j^{\rm sign})s_i s_j.
\]

Consequently the active-edge parity vector has a same-side edge at `j-i`
when the two q bits and the two t bits are equal, and a cross-side edge at
`2p-1-i-j` when the q bits differ and the t bits are equal. All original
column pairs are accounted for. The self-reflected dot product is zero.

## 2. Independent polynomial derivation

Work over F2, with `J=1+...+z^(p-1)`, and let `Q,T` have the q,t coefficients.
Write `M=Q ⊙ T` for the coefficientwise product, and `X^-=X(z^-1)`. Then

\[
D=JJ^-+(Q+T+M)J^-+J(Q^-+T^-+M^-)+QT^-+TQ^-,
\]

\[
C=(Q+M)J+QT+Q^2.
\]

The positive coefficient `D_k` is the same-side parity at lag k. Its constant
coefficient is `p mod 2`. Off-diagonal coefficients of C have edge coefficient
`(q_i+q_j)(1+t_i+t_j)`; diagonal terms cancel. Thus, for odd p,

\[
F=0\quad\Longleftrightarrow\quad
D+1+z^{2p-1}C^-+z^{-(2p-1)}C=0.
\]

In particular the cross exponent is `2p-1-(i+j)`, not `2p-2-(i+j)`;
the latter occurs only when storing lag k at bit k-1.

Modulo J we have `z^p=1`. Put `Z=Q+T`. The last identity gives

\[
1=QZ^-+ZQ^-+z^{-1}Q^-Z^-+zQZ
 =(Q+z^{-1}Q^-)(Z^-+zZ).
\]

For p-coefficient reversal `R(X)=z^(p-1)X^-`, set `H=Q+R(Q)` and
`K=T+R(T)`. This proves `zH(H+K)=1 mod J`. It uses odd p, but not primality.
Importing the inverse argument unchanged to even p would be invalid.

H is therefore a unit. Its inverse determines
`K=H+z^-1 H^-1 mod J`. A residue has two representatives of degree at most
p-1, differing by J; exactly one has middle coefficient zero. This chosen K
is palindromic: modulo J, `K^-=zK`, so `R(K)+K` is a multiple of J, of degree
at most p-1, and has middle coefficient zero. It is therefore zero.

With `m=(p-1)/2`, every possible H is uniquely `h+R(h)` for `0<=h<2^m`.
For fixed H,K, the freely chosen q_i,t_i at `1<=i<=m` determine all reflected
partners. The center is free; q_0=t_0=0 fixes the end pair. This is a bijection
with `p-1` fiber bits. The inverse identity is necessary, not sufficient;
the full original parity vector must still vanish.

At p=53, `ord_53(2)=52`, so J is irreducible and exactly `2^26-1` of the
`2^26` outer values are units. The normalized quantity `z^-26 H` belongs to
F_(2^26); H itself should not be described as fixed by the inversion
automorphism. The outer count alone is not a runtime estimate.

## 3. ElimLin and exhaustive fallback

On an affine fiber, the Boolean function F has degree at most two. Its
constant, linear, and mixed quadratic coefficient vectors are exactly
recovered from evaluations at 0, e_i, and e_i+e_j. Let W be the span of the
mixed quadratic vectors. Projection modulo W gives necessary affine
equations. A complete particular solution plus independent kernel basis
parametrizes every solution of those equations.

Substitution is into the entire F. Quadratic coefficients are recomputed
after a changed parameterization. If the projected system is inconsistent,
discarding the fiber is sound. If dimension decreases, every F-zero remains
in the restricted affine space. If it does not decrease and a quadratic
coefficient remains, both values of a free parameter are searched. They are
disjoint and cover the parent. If no quadratic term remains and the affine
system has rank zero and zero constant, every remaining point is a solution.

The native highest-pivot span reduction is a linear quotient map with
kernel W. Its column-preimage null relations have distinct newest input
indices and thus form an independent complete kernel. There is no hidden
assumption about the observed ranks or absence of branching. The initial
quadratic-span cache is legitimate because second derivatives of a degree-two
Boolean map depend on directions, not the base point. It is not reused after
the directions change.

The stronger statement that all fiber equations are affine is false:
`F_(2p-2)=q_1(1+t_1)` under MODE P has nonzero mixed second derivative for
p>=5. The implementation retains this residual constraint.

## 4. Q/U affine consequences for independent implementation

Appendix A of `proof/algebra_orientation_fibers.md` was checked separately.
Set `U=Q+T`, `G=H+K`, `E=Q ⊙ U`, and reverse C with **2p-1 coefficients**:
`S=C+z^(2p-2)C^-`. Then

\[
C=EJ+QU,\qquad E+R(E)=Q\odot G+H\odot U+H\odot G,
\]

\[
S=J(E+R(E))+QG+UH+HG,
\]

\[
z^{p-1}D=J^2+J(K+E+R(E))+QG+UH.
\]

These expressions are affine in Q,U with H,G fixed. The correct paired
coordinates are `F_k+F_(2p-k)=D_k+S_(k-1)` for `2<=k<p`, with `F_1=D_1`.
The middle coordinate is the constant `F_p=sum_(i<m) H_i G_i`.

For a symmetric Q-direction v, the polynomial changes in both shifted D
and S are `V=J(v ⊙ G)+vG`; replace G by H for a U-direction. For a reflected
pair `v=z^i+z^(p-1-i)`, this is
`V=v(G+G_i J)`, computable with two shifts. For the center, `V=z^m G`.
Thus the derivative of the kth affine combination is
`V_(p-1+k)+V_(k-1)` (the second term is zero at k=1).

The p=53 middle-coordinate argument via a self-dual trace basis is valid,
but an implementation can simply test the constant without depending on it.
These are necessary equations, not a claim that every affine consequence
has been listed. A later complete solver must retain all of F.

## 5. Native arithmetic and robustness

Audited files: `src/exact_orientation_fibers.cpp` and its v2 successor.
The supported range is odd `3<=p<=63`. Fiber dimension is at most p-1<=62,
so 64-bit affine masks and assignment bounds are valid. Polynomial products
and the additional z shift have degree at most 125, within 128 bits. Reversal
widths are p and 2p-1, both within their allocated words. No floating-point
arithmetic enters a mathematical acceptance condition.

The v2 same-side expression uses the coefficientwise identity
`q OR t = q+t+q⊙t`. Its polynomial difference expression is shifted by p to
put lag k at bit k-1; the omitted J² term is the alternating baseline for
odd p. Cross products count each unequal-q, equal-t unordered pair once.
Reversal with width 2p-1 maps sum i+j to bit `2p-2-i-j`, exactly lag-1.
PCLMUL is an exact carryless product and is guarded by a CPU feature check.

Previously reported robustness issues were fixed before the frozen campaign:
initialization is inside the timeout handler; free-affine evaluation and
deadline checks no longer disappear with disabled assertions; output write
and close failures return failure. Completion advances only after a whole
H fiber and its records have been processed.

On timeout, the accepted coverage is `[h_start,h_start+H_completed)`, not
the requested range or H_examined. Partial-fiber statistics are not a coverage
certificate. Later reports of replaced/truncated output files require file
integrity investigation and replay; no source audit can repair missing data.

## 6. Evidence actually available at this audit

The native and older q-by-q implementations agree on the entire orientation
sets for n=34,50,58 (22,28,64 orientations). The independent n=34 certificate
replay is documented in `proof/audit_quad_reduction.md`. A separate Python
direct-edge implementation agrees with the native solver on 76 complete
n=106 fibers, including the 13 initial-pilot orientations; see
`results/algebra_native_fiber_crosscheck_n106.json`.

`tests/verify_folded_solver.py` was authored for extra affine, branching,
small-domain, and selected-fiber checks; at the initial writing of this audit
it had **not been run**, to avoid exceeding the active worker cap. Any later
run must be identified by its saved result, not inferred from this source file.

Independent full-domain replay remains a separate obligation. Agreement on
sampled fibers, or a completed first-parity campaign, does not establish
ordinary length-106 nonexistence. A complete sign-stage search and original
integer correlation verification are still necessary.
