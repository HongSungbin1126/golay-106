# Audit of the exact quad reduction and finite certificates

Date: 2026-11-05. Reviewer: `/root/information_control`.

Scope: binary ordinary aperiodic pairs of one fixed even length n=2m.
This rederives established parity/quad methods. No novelty is claimed.

## 1. Complete parameterization after a proved necessary condition

By `proof/audit_acceptance_and_normalizations.md`, every valid pair satisfies
the mirror condition. Define two-component columns at mirrored positions:

    L_i = (s_i, s_i q_i),
    R_i = (t_i s_i, -t_i s_i q_i),  0<=i<m,

with s_i,q_i,t_i in {+1,-1}. Given a mirror-compatible pair, one recovers
s_i=a_i, q_i=b_i/a_i and t_i=a_(n-1-i)/a_i uniquely. Thus no mirror-compatible
pair is lost by this parameterization. MODE P makes s_0=q_0=t_0=1 using only
proved target-preserving symmetries; no row-sum normalization is added.

## 2. Decomposition of the original integer equations

For i<j, the two same-side products enter lag j-i and sum to

    L_i.L_j + R_i.R_j
      = (1+q_i q_j)(1+t_i t_j)s_i s_j
      = 4 [q_i=q_j][t_i=t_j] s_i s_j.

The two opposite-side products enter lag n-1-i-j and sum to

    L_i.R_j + L_j.R_i
      = (1-q_i q_j)(t_i+t_j)s_i s_j
      = 4 [q_i!=q_j][t_i=t_j] t_i s_i s_j.

Each self-mirror product L_i.R_i vanishes. These categories account for all
unordered pairs of original positions:4*C(m,2)+m=C(2m,2). Therefore every
original r_k is four times the indicated integer sum, with no missing products.

Fix q and assign every unordered pair {i,j} to exactly one selected lag:
j-i if q_i=q_j, and n-1-i-j otherwise. Call this edge set E_k. The edge is
active precisely when t_i=t_j. Its coefficient sigma_e is1 in the equal-q case
and t_i otherwise. Thus

    r_k/4 = sum_(e={i,j} in E_k, active) sigma_e s_i s_j.  (2)

## 3. The two necessary affine systems

Let tau_i=(1-t_i)/2, with tau_0=0. Reducing (2) modulo2 removes every sign.
The active indicator equals1+tau_i+tau_j in F2. Therefore a valid pair must obey

    sum_({i,j} in E_k) (tau_i+tau_j) = |E_k| mod2.  (3)

Every affine solution of (3) is enumerated. The reduction does not claim that
(3) suffices for the original equations.

For fixed t satisfying (3), the number of active edges is even. Hence
S_k=sum_active sigma_e is even. Put u_i=(1-s_i)/2 and u_0=0. Since

    s_i s_j = 1-2(u_i+u_j)+4u_i u_j,

reducing (2) modulo4 gives the necessary equation

    sum_active (u_i+u_j) = S_k/2 mod2.  (4)

The sign sigma_e disappears in this last F2 equation because +1=-1 in F2.
Every affine solution of (4) is enumerated. Remaining candidates are tested
against the original equations. The independent replay deliberately does not
use the C++ solver's row-norm prefilter.

## 4. What the finite certificate proves

`tests/verify_quad_exhaustion.py` builds a certificate in which the array index
enumerates every q-tail mask in0,...,2^(m-1)-1 exactly once. Each first-stage
rejection stores a subset of original F2 equations whose XOR is0=1. Every
consistent stage stores reduced rows and the subset of original equations
producing each row.

The checking path does not solve a Gaussian-elimination problem. It checks:

1. Each derived row is exactly the stated XOR of original rows.
2. Pivot variables are distinct and each pivot occurs in its own row only.
3. Every original row is in the span of the supplied reduced rows.
4. The implied particular solution and independent free-coordinate basis
   enumerate all assignments, in the specified order.
5. Every surviving t assignment is covered, and every surviving s assignment
   is covered.
6. For each final rejection, a specified original nonzero-lag correlation is
   recomputed directly with signed multiplication and is nonzero.

Points1–3 establish equality of the two augmented row spaces, so no equation
is silently added or discarded. Point4 establishes complete affine coverage.
Every possible original solution can be normalized to MODE P and must survive
both necessary systems. Complete coverage and a valid rejection for every
remaining candidate therefore establish fixed-length nonexistence.

The generator obtains rejection values through the independent polynomial
convolution checker. The certificate replay uses the direct signed-product lag
formula. A result can be checked again in a clean process with:

    python3 tests/verify_quad_exhaustion.py \
      --check results/verification_quad_n34_certificate.json \
      --output results/verification_quad_n34_recheck.json

## 5. Trusted base and result labels

This is an auditable finite computational certificate. It is not a Lean theorem,
a formalized proof of all Python semantics, or evidence of a general length
classification. Its trusted base is the audited reduction, the checking source,
the Python runtime and exact integer arithmetic. The C++ program's UNSAT label
and its Gaussian-elimination implementation are not trusted by the certificate
replay.

Length34 nonexistence is already known. Reproducing it independently is a
calibration and verification result. It does not resolve length106 or the
universal Golay length conjecture.
