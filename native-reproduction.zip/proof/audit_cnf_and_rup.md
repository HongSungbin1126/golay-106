# CNF encoding and independent RUP replay audit

Date: 2026-11-05. Role: ADVERSARIAL_VERIFIER.

The direct and full-quad CNF encodings in `src/cnf_golay.py` were checked
against their exact Boolean meanings. Signed XOR and AND gates, cardinality
constraints, MODE P, and the explicit n=106 row normalization are consistent
with their stated models. The orientation-only encoding is a relaxation and
must remain labeled as such.

For the direct encoding, the total number of XOR differences at lag k must
equal n-k, exactly equivalent to the sum of the two integer correlations
being zero. For a signed quad edge sum, the cardinality equation
`sum(positive)+sum(not negative)=number(positive)` is equivalent to equality
of positive and negative active contributions. No periodic acceptance
condition replaces the original aperiodic condition.

`tests/verify_cnf_and_drup.py` passed 900 comparisons of unit propagation
against a separate naive scanner, 64 signed gate assignments, 32 signed
cardinality assignments, 340 direct-domain assignments at n=1..4, 584 quad
assignments at n=2,4,6, 84 orientation assignments, and 12 parser/proof
adversarial cases. The saved result is
`results/verification_cnf_and_drup_tests.json`. Its exact source hashes identify
the tested encoder version; this audit does not silently cover later edits.

## Independent checker semantics

`src/verify_drup.py` implements exact reverse unit propagation with standard
library Python integers and an active clause multiset. A proposed clause is
accepted only when unit propagation, after assuming its negation, produces a
conflict. Unsupported non-RUP steps are rejected. No RAT fallback is claimed.

Two explicitly selected deletion interpretations exist:

- `remove`: actually remove clauses as declared. This is the stricter active
  database interpretation.
- `retain`: parse and check deletion hints, but retain every original clause
  and previously proved RUP clause. This is a sound monotone RUP proof replay,
  not a claim that the original deletion trace passes strict DRUP semantics.

The retention mode is sound because every retained added clause has already
been proved to follow from the original CNF. Inductively, a contradiction
derived from this enlarged database is a contradiction of the original CNF.
Retaining unproved clauses or silently accepting non-RUP additions would not
be sound; the implementation does neither.

This checker certifies a CNF contradiction. The bridge between the CNF and
the mathematical problem remains the separately audited encoding. It is not
a formal proof kernel for the entire mathematical result.

## Actual checked proof files

At n=6, strict deletion mode passed: 27 additions and 46 deletions, with an
empty clause derived. See `results/verification_drup_n6.json`.

At n=12, strict deletion mode **rejected** the trace at line 1956. A separate
naive propagation implementation reproduced that rejection. Those findings
are retained in `results/verification_drup_n12.json` and
`results/verification_drup_n12_diagnostic.json`.

The same n=12 additions passed in the explicitly labeled retention mode:
all 2,285 additions were RUP relative to the retained proved database, 2,837
deletion hints were parsed, and the empty clause was derived. CPU time was
1.943 seconds and peak memory approximately 15 MiB. The result is
`results/verification_rup_n12_retained.json`.

The n=12 CNF SHA256 is
`76ae5673679091e8d350fa9a12b76361b94648033a6f2bfe3c3dec4e45b5310c`;
the proof SHA256 is
`2db742e352d23e21724caccd31951162744e54321aa9bcf7ec8ad65f13bace36`.
An n=18 proof file was produced elsewhere in the project but was not replayed
by this verifier at the time of this audit. Its existence alone is not an
independent verification result.
