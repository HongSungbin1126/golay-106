# Acceptance obligations for a complete length-106 computation

Date: 2026-11-05. Sections 1–6 preserve the verification requirements written
before the complete runs. Their prospective and conditional wording is
historical planning context. **Section 7 records final acceptance after the
required coverage, independent replay, affine-space, and character-certificate
gates passed.** No new computation was performed for that addendum.

## 1. Logical coverage chain

The finite argument must cover every link below.

1. Every ordinary binary Golay pair of length 106 satisfies the established
   mirror identities and can be normalized to MODE P without changing the
   existence question. This gives a quad triple (s,q,t) with
   s_0=q_0=t_0=+1 in sign notation.
2. Its q,t bits satisfy the first quad parity equations F=0.
3. The proved folding identity assigns it exactly one H in [0,2^26),
   represented by the low half of Q+R(Q). Its H is nonzero.
4. The inverse identity uniquely determines K, including its exact p-term
   palindromic, middle-zero representative. The affine fiber includes every
   q,t with these H,K and the required endpoint normalization.
5. Every such fiber is solved completely, with all residual F equations
   retained. Linear consequences may prune; incomplete timeouts may not.
6. Every surviving orientation is passed to a complete sign search, and
   every remaining sign assignment is checked against all original integer
   aperiodic correlations.

A proof of all six links and successful finite coverage could establish
nonexistence at length 106. It would not prove the general Golay length
conjecture or classify every admissible length.

## 2. Exact domain and partition checks

At p=53, J_53 is irreducible. The domain has 67,108,864 H indices. Therefore
there are exactly 67,108,863 unit H values and exactly one nonunit, H=0.
Any additional inverse failure must be treated as an implementation error.

A complete campaign must contain disjoint half-open intervals whose union
is [0,67,108,864). Each accepted interval must have a complete status and
completed-count equal to its endpoint difference. Check these statements
arithmetically from the raw interval manifests; do not infer coverage from
wall time, a progress display, filenames, or a rounded percentage.

Preserve the source, executable, command, compiler options, and hashes.
An interrupted interval must be rerun or resumed from a certified completed
boundary. A timeout is not a negative result for its unfinished suffix.

## 3. Inversion and finite arithmetic

For every H, independently verify the exact identities

\[
zH(H+K)=1\pmod{J_{53}},\qquad R(K)=K,\qquad K_{26}=0.
\]

These checks certify the partner supplied by any inversion implementation,
because the identity makes it unique. The value of H itself must be
recomputed from the loop index, so a duplicated or skipped index cannot be
masked by a correct inverse calculation elsewhere.

Critical conditions should be explicit error checks in a verifier.
Compilation with disabled assertions must not silently remove them.
Integer widths, shift bounds, and polynomial-reversal widths are part of
the implementation audit. At p=53, ordinary products fit in 105 bits and
the recorded parity vector fits in 105 bits.

## 4. Independent implementation route

Repeating the same executable is useful for hardware reproducibility but
does not independently check its enumeration logic. The project's Python
reference and selected complete-fiber comparisons provide stronger evidence
than sampling individual solutions, but still do not cover all 2^26 fibers.

The proposed second full-domain replay should differ structurally:

- Use Q,U=Q+T coordinates and the explicit affine equations in Appendix A
  of `proof/algebra_orientation_fibers.md`.
- Derive correlation parities using separate bitwise reflection/popcount
  formulas or the literal edge definition, rather than reusing the native
  polynomial-multiplication parity routine.
- Form scalar algebraic-normal-form rows and eliminate their nonlinear
  monomials by row Gaussian elimination. The first implementation instead
  projects vector-valued coefficients modulo their quadratic-image span.
- Keep a distinct affine-system solver and exhaustive branch fallback.
  Check every emitted orientation against the literal edge definition.
- Compare complete (H,q,t) sets, not just aggregate counts, with the first
  campaign. Sorting and exact set comparison must also detect duplicates.

The two algorithms are mathematically related through established ElimLin
principles, so this is implementation independence rather than a second
unrelated mathematical proof. Shared assumptions, especially the folding
lemma and MODE P normalization, still need separate proof audits.

## 5. Sign-stage evidence

Each orientation must be paired with its exact sign-linear system, complete
particular solution plus kernel, and an accepted complete search status.
If a sign system is inconsistent, a compact XOR contradiction witness can
be checked directly. If it has a kernel, all kernel assignments or a sound
complete pruning procedure must be covered. The maximum observed nullity
must not become an unproved hard cap.

The final check uses original binary A,B and integer aperiodic correlations;
periodic identities, PSD bounds, row sums, and parity conditions alone are
insufficient. A claimed positive result should store the complete pair and
be passed through the independent original-domain verifier.

## 6. Honest reporting levels

Until both full passes and sign-stage coverage are independently checked,
describe the outcome as a complete solver report under the stated reduction,
with independent proof audits and the exact scope of empirical validation.
Do not call it a formally checked theorem or an independently certified
nonexistence result unless that standard has actually been met.

Even after a successful computation, novelty and publication status remain
separate issues. Recheck the latest ordinary-binary aperiodic literature and
seek expert review before claiming a first result. Periodic and complex
Golay results do not establish the same statement.

## 7. Final acceptance addendum — 2026-11-05

The project's computational acceptance gates are now met. The accepted
evidence combines the proved reductions with two complete first-parity
enumerations, exact agreement of their orientation sets, an independent
audit of all sign spaces, and independently checked integer-character
certificates and positive modular witnesses.

This is an independently reproduced, computer-assisted finite result under
the documented mathematical reductions and trusted arithmetic/software base.
It is not a formal-kernel proof. Novelty, external expert review, and
publication status are separate questions; this addendum makes no priority
claim and does not settle the general Golay length conjecture.

### 7.1 Accepted evidence and the scope of each gate

| Evidence file | Recorded result | What it establishes |
|---|---|---|
| `results/final_primary_coverage_audit.json` | `COMPLETE_ARTIFACT_COVERAGE` | 64 accepted partitions cover all 67,108,864 H indices with no gaps or overlaps; 67,108,863 unit H values, one nonunit, and 102 orientations. |
| `results/final_independent_coverage_audit.json` | `COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY_ACCEPTED` | A structurally distinct implementation covers the same full domain; `exact_primary_set_match` is true for the complete 102-orientation set. |
| `results/campaign_n106_sign_space_audit.json` | `PASS` | All 102 orientations are covered; 94 affine contradictions are independently verified, and the eight remaining particular solutions and complete kernels are audited. |
| `results/exact_sign_character_certificate_checked.json` | `PASS` | All eight audited sign spaces are excluded modulo 64 by checked original-correlation certificates; exactly eight surviving modulo-32 witnesses are reconstructed and checked, with a generated standard-symmetry orbit of size 64. |
| `results/exact_sign_character_certificate_mutations.json` | `PASS` | The checker rejects all eight supplied corruptions, including changed gcd/RHS, false XOR provenance, an omitted free direction or initial space, changed substitution or terminal sign, and a changed original witness. |

The primary audit retains rejected historical receipts for provenance. Its
accepted coverage is supplied by the 64 selected valid partitions, including
replacement runs where needed; rejected receipts are not used as negative
search evidence. Source, executable, input, receipt, and checker hashes are
recorded in the audit artifacts.

Each gate has a deliberately limited scope. A coverage audit alone does not
prove the absence of omitted solutions, and the sign-certificate checker
does not itself enumerate the H domain. Their conclusions are composed only
through the mathematical completeness arguments and the linked input
artifacts. The later analytic first-stage parameterization and fixed second
projection are not hidden dependencies of the frozen independent replay.

### 7.2 Complete implication chain from a modulus-64 pair

For binary rows A,B of length n=106, define the original integer residuals

\[
r_k=\sum_{i=0}^{105-k}a_i a_{i+k}
    +\sum_{i=0}^{105-k}b_i b_{i+k},\qquad1\le k\le105.
\]

Suppose, for contradiction, that every r_k is zero modulo 64.

**Mirror identities already follow modulo four.** Write a_i=1-2x_i,
b_i=1-2y_i and c_i=x_i+y_i modulo two. Expanding r_k, dividing by two,
and reducing modulo two gives

\[
\sum_{i=0}^{k-1}c_i+\sum_{i=106-k}^{105}c_i=k\pmod2.
\]

The k=0 empty-sum identity is also valid. Subtracting consecutive identities
shows c_i+c_(105-i)=1, equivalently

\[
a_i a_{105-i}+b_i b_{105-i}=0.
\tag{A1}
\]

Independently negate the rows to make a_0=b_0=1. Their final signs are
opposite by (A1); interchange rows uniquely if necessary to make
a_105=1 and b_105=-1. These operations preserve every r_k exactly, so this
MODE P normalization also preserves every modular condition.

**The mirror parameterization is exact.** With p=53, write

\[
a_i=s_i,\quad b_i=(-1)^{q_i}s_i,\quad
a_{105-i}=(-1)^{t_i}s_i,\quad
b_{105-i}=-(-1)^{q_i+t_i}s_i,
\]

where q_0=t_0=0 and s_0=1. The quad dot-product calculation in
`proof/algebra_orientation_fibers.md` gives the exact identity

\[
r_k=4\sum_{e\in E_k}\gamma_e s_i s_j,
\qquad\gamma_e\in\{1,-1\}.
\tag{A2}
\]

It accounts for every original column pair, including the vanishing
self-reflected terms.

**Modulus eight gives the complete orientation problem.** Reducing r_k/4
modulo two removes every sign and gives the first parity condition F(q,t)=0.
The folding proof assigns each such orientation exactly one nonzero H and
its unique inverse partner through zH(H+K)=1 modulo J_53. The complete
affine fiber includes every normalized q,t with those folded values. Both
accepted full-domain implementations retain all original parity equations
and complete branch fallbacks. Their matching output consists of exactly
102 orientations; no unfinished partition is counted as an exclusion.

**Modulus sixteen gives the exact second affine system.** Write
s_i=(-1)^(eta_i) and let C_k=sum_(e in E_k) gamma_e. First parity makes C_k
even. Modulo four,

\[
r_k/4\equiv C_k-2\sum_{e\in E_k}\gamma_e(\eta_i+\eta_j)\pmod4.
\tag{A3}
\]

Thus the binary linear condition on eta is equivalent to r_k=0 modulo 16
for all k, once first parity holds. The independent sign-space audit checks
94 inconsistent systems and eight complete affine solution spaces. Their
dimensions are four copies of 4, two copies of 20, and two copies of 26.
The modulus-64 hypothesis must therefore lie in one of those eight spaces.

### 7.3 Safe integer congruences exclude all eight spaces modulo 64

On an audited sign space, every original correlation is represented exactly
as an integer character polynomial

\[
r_k(z)=\sum_\mu c_{k,\mu}(-1)^{\langle\mu,z\rangle}.
\]

The independent checker rebuilds these coefficients from original signed
Gram pair-products. It checks the integer gcds, linear consequences, full
affine restrictions, substitutions, and terminal contradictions. The full
derivations and coordinate masks are in
`proof/algebra_sign_character_certificates.md`.

- In the four dimension-four spaces, a single original correlation is
  r_33=16 chi_10 or r_9=-16 chi_10. Since chi_10 is always +1 or -1, that
  correlation is nonzero modulo 32 and hence cannot be zero modulo 64.
- In the two dimension-26 spaces, the gcd-eight equations at lags 24 and
  28 imply r_24-r_28=16 modulo 32. The two correlations cannot both vanish
  modulo 64.
- In the two dimension-20 spaces, retain only the 18 independently checked
  equations at lags 2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,40.
  Every coefficient gcd is exactly 8. Therefore 64 dividing r_k implies
  r_k/8=0 modulo eight, and in particular modulo four. Those necessary
  equations have rank 18 and leave a complete two-dimensional affine
  space. On that space the original correlation is identically
  r_4=-160=32 modulo 64, a contradiction.

The last case uses no unsafe gcd division. In general, if g=2^v h with h
odd, divisibility of gP by 2^s implies divisibility of P by 2^(s-v) when
v<s. All 18 restricting rows above have v=3. At the terminal constant,
160=2^5*5, so a modulus-64 hypothesis would require the primitive constant
-1 to be even, which it is not.

This closes the chain: **there is no ordered pair of binary length-106
sequences whose every nonzero aperiodic residual is zero modulo 64.**
In particular, no ordinary binary aperiodic Golay pair of length 106 exists,
because an exact zero residual would also be zero modulo 64. This is a
fixed-length conclusion supported by the completed project evidence.

### 7.4 Positive witnesses and exact counts at smaller dyadic moduli

The modulus-32 classification uses the same accepted coverage. The 94
inconsistent systems fail already modulo 16; the dimension-four and
dimension-26 spaces fail modulo 32. In each remaining dimension-20 space,
the same 18 gcd-eight equations are necessary already modulo 32, since
r_k/8 must then be zero modulo four. Their complete two-dimensional
solution contains exactly four assignments.

All four assignments in each of the two orientations were independently
reconstructed and checked against every original integer correlation.
Thus there are exactly eight MODE P pairs modulo 32. For one representative,
the only nonzero positive-lag residuals are

\[
(r_4,r_8,r_{12},r_{16},r_{20})=32(-5,4,-3,2,-1).
\]

The full witness rows, residuals, and independent checks are linked by
`results/exact_sign_character_certificate_checked.json` and stored in
`results/algebra_mod32_witnesses.json`. These witnesses satisfy every
smaller power-of-two modulus as well. Their existence and the modulus-64
exclusion show that 64 is the least power-of-two modulus excluding all
length-106 pairs.

The reductions give exact counts at each earlier stage, not just necessary
upper bounds. Mirror identities are equivalent to divisibility of every
r_k by four: necessity is (A1), and sufficiency is (A2). Each of the 53
quads has three independent signs, while MODE P fixes the first quad,
leaving 156 bits. At modulus eight, each of the 102 orientations allows
all 2^52 normalized sign vectors. Equation (A3) is an equivalence at
modulus sixteen, so the exact count is
4*2^4+2*2^20+2*2^26=136,314,944.

| Required modulus | MODE P ordered pairs | Raw ordered binary pairs |
|---:|---:|---:|
| 4 | 2^156 | 2^159 |
| 8 | 102*2^52 | 102*2^55 |
| 16 | 136,314,944 | 1,090,519,552 |
| 32 | 8 | 64 |
| 64 | 0 | 0 |
| Any larger power of two | 0 | 0 |

### 7.5 Why the raw-count multiplier is exactly eight

For every modulus in the table, the mirror identities hold. The group of
independent row negations and row interchange has eight elements:
(A,B)->(epsilon A,delta B) and (A,B)->(epsilon B,delta A), with
epsilon,delta in {+1,-1}. It preserves every residual exactly.

This action is free on mirror pairs. A nonidentity pure negation cannot
fix a binary row. A stabilizer involving interchange would require A=+B
or A=-B, and either relation contradicts (A1). Each orbit therefore has
eight distinct ordered pairs. It has exactly one MODE P representative:
the two leading signs are normalized uniquely, and the opposite final
signs then determine the row order uniquely. Multiplying the normalized
counts by eight is consequently justified, rather than inferred from a
generic orbit-size assumption.

The independent witness checker additionally generates the standard Golay
symmetry orbit, obtaining 64 raw pairs and precisely the eight normalized
modulus-32 witnesses. This confirms their one-orbit description. The
normalization argument above, together with the complete count of normalized
witnesses, establishes that there are no other raw modulus-32 pairs.

The factor-eight argument is not being extended to modulus two, which does
not imply the mirror identities. All conclusions in this addendum remain
finite, source-linked computer-assisted claims; no formal-kernel or
world-first status is asserted.
