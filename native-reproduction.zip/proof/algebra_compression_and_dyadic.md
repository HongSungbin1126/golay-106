# Exact compression, lifting, and dyadic constraints

Date: 2026-11-05. Role: ALGEBRA_RESEARCHER.

Scope: necessary conditions, an exact lifting equivalence, and independently
checkable small finite experiments. No open Golay length is settled here.
The identities were derived for this project; novelty has not been established.
Polynomial evaluation and periodic compression are standard techniques. The
more useful orientation-fiber search is documented separately in
`proof/algebra_orientation_fibers.md`.

## 1. Domain and conventions

An ordinary binary Golay pair of length n consists of A,B in {+1,-1}^n such
that the sum of their two aperiodic autocorrelations vanishes at every lag
1,...,n-1. For a coefficient polynomial X, write X^-(z)=X(z^{-1}); then the
exact identity is

\[
AA^-+BB^-=2n.
\]

Set n=2p, with p odd. Define length-p ternary polynomials

\[
P_j=(a_j+a_{j+p})/2,\quad D_j=(a_j-a_{j+p})/2,
\]

and Q,E from B in the same way. Their pointwise constraints are

\[
P_jD_j=Q_jE_j=0,\qquad P_j^2+D_j^2=Q_j^2+E_j^2=1.
\tag{1}
\]

Conversely any four ternary sequences satisfying (1) lift uniquely to binary
A,B by a_j=P_j+D_j, a_{j+p}=P_j-D_j, and the corresponding B formulas.

## 2. Exact periodic and negacyclic lifting equivalence

Put

\[
U=PP^-+QQ^-,\quad V=DD^-+EE^-,\quad
W=PD^-+QE^- -DP^- -EQ^-.
\]

U,V are symmetric Laurent polynomials and W is antisymmetric, so W_0=0 and
W_{-k}=-W_k. From A=(1+z^p)P+(1-z^p)D and the analogous B expression,

\[
AA^-+BB^-=2(U+V)+(z^p+z^{-p})(U-V)+(z^p-z^{-p})W.
\tag{2}
\]

Under (1), the original Golay identity is equivalent to all of

\[
U_0=V_0=p,\qquad
U_k+U_{p-k}=0,\qquad V_k-V_{p-k}=0,\qquad
W_k=-(U_k-V_k),\quad 1\le k<p.
\tag{3}
\]

Proof: the coefficient at lag p in (2) is U_0-V_0. Its vanishing, together
with U_0+V_0=2p from (1), gives the first condition. At lag p+k the coefficient
is U_k-V_k+W_k, giving the last condition. Substituting that condition into
the coefficients at k and p-k gives, respectively,

\[
(U_k+U_{p-k})+(V_k-V_{p-k})=0,\qquad
(U_k+U_{p-k})-(V_k-V_{p-k})=0.
\]

Addition and subtraction over the integers give the middle two conditions.
These coefficient calculations also prove the converse.

The U condition is periodic complementarity of P,Q. The V condition is
negacyclic complementarity of D,E. Since p is odd, define
\(\widetilde D_j=(-1)^jD_j\), and similarly for E. Their periodic correlation
sum at lag k is exactly

\[
(-1)^k(V_k-V_{p-k}).
\]

Thus one can instead search for two periodic ternary complementary pairs
(P,Q) and (D-tilde,E-tilde), with coupled pointwise supports and the residual
W equations. The W equations cannot be discarded: periodic compression
alone loses aperiodic information.

For the R106 normalization A(1)=14, B(1)=4, A(-1)=4, B(-1)=14, the row sums
are (P(1),Q(1))=(7,2) and (D-tilde(1),E-tilde(1))=(2,7). Each pair has total
weight 53. These row conditions refer to R106, not simultaneous MODE P
endpoint normalization.

## 3. Exact number of mirror-compatible lifts of a fixed compression

This lemma requires only P,Q in {0,+1,-1}^p and
\(\sum_j(P_j^2+Q_j^2)=p\). **Periodicity is not an assumption.**

Write w_j=P_j^2+Q_j^2 and r=p-1-j. Every zero entry in P,Q supplies one free
binary lift sign. Since there are p zeros, there are exactly 2^p unrestricted
binary lifts. We impose the necessary Golay mirror identities

\[
a_i a_{2p-1-i}+b_i b_{2p-1-i}=0.
\tag{4}
\]

A compression has a lift satisfying (4) if and only if all three tests pass:

1. w_j and w_r have the same parity for every j.
2. The middle support weight w_{(p-1)/2} is 1.
3. Whenever w_j=w_r=2, P_jP_r+Q_jQ_r=0.

Let h be the number of unordered pairs {j,r} with w_j=w_r=2. If the tests
pass, the number of mirror-compatible lifts is exactly

\[
\boxed{2^{(p+1)/2+h}},\qquad 0\le h\le\lfloor(p-1)/4\rfloor.
\tag{5}
\]

Proof: put alpha_j=2P_j^2-1 and beta_j=2Q_j^2-1. In every binary lift,
a_{j+p}=alpha_j a_j and b_{j+p}=beta_j b_j. For a noncentral reflected pair,
the two mirror equations are

\[
\alpha_r a_j a_r+\beta_r b_j b_r=0,\qquad
\alpha_j a_j a_r+\beta_j b_j b_r=0.
\]

They are consistent precisely when alpha_j beta_j=alpha_r beta_r, equivalent
to w_j=w_r modulo 2. They then impose a single sign-product equation. At the
center the equation becomes alpha_j+beta_j=0, equivalent to w_j=1.

For support types (0,0), there are four free signs and one equation. For
(0,2),(2,0),(1,1), there are two free signs and one equation. For (2,2),
there are no free signs; the fixed-sign test is exactly test 3. The total
support weight p forces the number of (0,0) pairs to equal h. The nontrivial
equations occupy disjoint free-sign groups, so their rank is (p-1)/2-h.
Subtracting this rank from the initial p free signs gives (5).

At p=53 this reduces a fixed compressed pair to between 27 and 40 free lift
bits, depending on h. It is a lifting reduction, not a feasible enumeration
of all compressed pairs.

### Finite falsification of a stronger conjecture

Periodicity plus mirror-compatible lifting is insufficient. For p=5, let

\[
P=(0,1,0,1,0),\qquad Q=(0,-1,1,1,0).
\]

The pair is periodically complementary, has total weight 5 and row sums
(2,1), and has exactly 16 mirror-compatible binary lifts. Exhaustive exact
aperiodic checking of all lifts finds zero ordinary Golay lifts.

The implementation checked (5) against direct lifting for every ternary pair
of total weight p at p=1,3,5: 8,228 compression data in total. It also examined
all 100 periodic compressed pairs at p=5 with row sums (2,1). Twenty admit
mirror-compatible lifts; 16 of those compressed pairs admit an ordinary
Golay lift, and four do not. These are labeled finite validation results,
not a proof by experimental agreement.

## 4. Exact fourth-root constraints at length 106

Use the R106 normalization stated above. The even and odd partial sums of A
are 9 and 5; those of B are 9 and -5. Write

\[
A(i)=x+iy,\qquad B(i)=u+iv.
\]

The four variables are odd, and residue-class parities imply

\[
x,y,u\equiv1\pmod4,\qquad v\equiv3\pmod4.
\]

The norm identity at i gives

\[
x^2+y^2+u^2+v^2=212.
\tag{6}
\]

The possible multisets of absolute values are exactly
(13,5,3,3), (11,9,3,1), (9,9,7,1), and (9,9,5,5). Together with the specified
modulo-four residues this yields 54 ordered branches. Their modulo-four
residue sums are

\[
r^A=((9+x)/2,(5+y)/2,(9-x)/2,(5-y)/2),
\]

\[
r^B=((9+u)/2,(-5+v)/2,(9-u)/2,(-5-v)/2).
\]

The symmetry (A,B) -> (alternating B, alternating A) preserves R106 and maps
(x,y,u,v) to (u,-v,x,-y). Exactly two of the 54 branches are fixed:
(9,5,9,-5) and (5,9,5,-9). Thus there are 28 orbits under this symmetry alone.
Additional symmetry normalization is not silently assumed.

## 5. Exact eighth-root constraints and reusable profile table

Let s_j be the sum of coefficients with index j modulo 8. The class sizes
at n=106 are (14,14,13,13,13,13,13,13). For each fourth-root branch, set

\[
d_j=s_j-s_{j+4},\qquad
s_j=(r_j+d_j)/2,\quad s_{j+4}=(r_j-d_j)/2,\quad 0\le j<4.
\]

Each s_j must be an integer of the class-size parity and of magnitude at
most that class size. For zeta=exp(pi i/4),

\[
|d_0+d_1\zeta+d_2\zeta^2+d_3\zeta^3|^2
=\sum_jd_j^2+\sqrt2\,[d_0(d_1-d_3)+d_2(d_1+d_3)].
\]

Consequently, for the A and B difference vectors, the two exact equations are

\[
\sum_j[(d_j^A)^2+(d_j^B)^2]=212,
\]

\[
d_0^A(d_1^A-d_3^A)+d_2^A(d_1^A+d_3^A)
+d_0^B(d_1^B-d_3^B)+d_2^B(d_1^B+d_3^B)=0.
\tag{7}
\]

Every individual d_j has magnitude at most 14 by the first equation. The
bounded enumeration therefore uses only integers in [-14,14], enforces the
class-size constraints, and matches the two rows by the energy and signed
irrational coefficient in (7).

Across all 54 fourth-root branches, there are 18,810 joint integer residue
profiles satisfying these conditions. If the irrational coefficient were
ignored, there would instead be 1,005,350. Each accepted profile was checked
by a separate exact polynomial norm calculation modulo z^4+1, yielding
the constant polynomial 212. No floating-point tolerance is used.

Combined with the first-, second-, and fourth-root constraints, these
conditions enforce the full periodic norm identity modulo z^8-1 for the two
integer residue-compression polynomials. This is a necessary condition on
the original sequences. It is not sufficient for an ordinary Golay pair.

## 6. Reproduction and claim limits

Run from the project root:

```sh
python3 src/algebra_cyclotomic_compression.py --output results/algebra_compression_dyadic_initial.json
```

The program uses exact Python integers, a 240-second CPU limit, and a 1-GiB
address-space limit. The recorded run took approximately one CPU second.

Artifacts:

- `results/algebra_compression_dyadic_initial.json`: counts, failed stronger
  claim, and branch data.
- `results/algebra_n106_q8_residue_profiles.jsonl`: all 18,810 joint profiles;
  each record stores the eight A sums and eight B sums.
- `src/algebra_cyclotomic_compression.py`: derivation-matched enumerator and
  direct finite validators.

The mirror-lift counting proof received a separate algebraic audit from the
project's verifier role. The dyadic table is internally cross-checked by an
independent formula, but has not been promoted to a standalone formal proof
certificate. No claim of new mathematics or a solved open length follows.
