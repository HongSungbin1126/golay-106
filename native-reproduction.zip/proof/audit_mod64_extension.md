# Audit of the stronger modulo-64 obstruction

Date: 2026-11-05. Role: ADVERSARIAL_VERIFIER.

**Logical verdict: PASS, conditional on the accepted complete first-parity
enumeration and independently checked sign-space/congruence certificates.**
The full independent first-stage replay has now completed all 67,108,864 H
values with exact agreement on 102 orientations. Its final root-owned
artifact acceptance and the sign-certificate checks are separate linked
obligations; this note supplies the mathematical congruence implication.

The prospective stronger statement is:

\[
\nexists A,B\in\{-1,+1\}^{106}\quad
\text{such that }C_A(k)+C_B(k)\equiv0\pmod{64}
\quad\text{for every }1\le k<106.
\]

This implies ordinary binary aperiodic nonexistence at length 106, because
exactly zero residuals are divisible by 64. It remains a fixed-length result,
not the universal Golay length conjecture. No claim is made here that 64 is
the smallest obstructing modulus.

## 1. The upstream reductions require weaker congruences

Write `r_k=C_A(k)+C_B(k)`. The mirror derivation uses only `r_k=0 mod 4`:
divide its binary expansion by two and reduce modulo two. The resulting
boundary identities, and their successive differences, give
`a_i a_(n-1-i)+b_i b_(n-1-i)=0`. MODE P is then obtained by sign negations and
interchange, all of which preserve every r_k.

In the quad model, `r_k=4 sum_(e in E_k) sigma_e (-1)^(u_i+u_j)`.
The first active-edge parity equations follow from `r_k=0 mod 8`.
After those hold, the second affine sign equations follow from
`r_k=0 mod 16`. Therefore a hypothetical pair with all residuals divisible
by 64 enters the same complete H domain, the same orientation list, and the
same sign affine spaces used for exact Golay search. These reductions do not
silently require the stronger equality r_k=0.

The 94 inconsistent sign systems reject their orientations already modulo
16. The remaining eight exact sign spaces are the ones in
`results/algebra_sign_character_reductions.json`.

## 2. Congruence extraction from integer characters

For an affine sign parameter x, an original correlation has the exact form

\[
r_k(x)=\sum_m c_m\chi_m(x),\qquad
\chi_m(x)=(-1)^{m\cdot x}.
\]

Let g be the positive gcd of its nonzero coefficients, write c_m=g d_m,
and put `P=sum d_m chi_m`, `S=sum d_m`.

Modulo two every character is one, so `P=S mod 2`. If S is odd, P is
always odd and `v_2(r_k)=v_2(g)`. Such a contradiction is valid modulo 64
provided `v_2(g)<6`; it does not require g to divide 64 as an ordinary integer.

If S is even, then modulo four

\[
P(x)\equiv S-2\sum_m d_m(m\cdot x)\pmod4.
\]

Thus the necessary equation for `P=0 mod 4` is

\[
\left(\bigoplus_{d_m\text{ odd}}m\right)\cdot x=S/2\pmod2.
\]

For an assumed residual congruence modulo 64, this equation is legitimate
when `v_2(g)+2<=6`. A generator that divided by a coefficient gcd and then
used modulo four without this valuation check could prove exact nonexistence
yet fail to establish a modulo-64 obstruction. The actual traces used here
meet the stronger condition.

## 3. Actual valuation and terminal checks

The saved trace was inspected directly:

| Initial dimensions | Used congruence information | Terminal obstruction |
|---|---|---|
| Four spaces of dimension 4 | No affine restriction is needed for the displayed terminal equation | `r_33=16 chi_10` or `r_9=-16 chi_10`, hence nonzero modulo 32 |
| Two spaces of dimension 26 | Every recorded primitive affine equation has coefficient gcd 8, so follows from the original residual being zero modulo 32 | Two equations at the same character mask have opposite right sides; the displayed original difference is `r_24-r_28=16 mod 32` |
| Two spaces of dimension 20 | All 24 primitive affine equations have coefficient gcd 8; their rank-18 system follows from residuals being zero modulo 32 | On its full remaining two-dimensional affine space, the rebuilt original polynomial is exactly `r_4=-160`, nonzero modulo 64 |

The last terminal primitive polynomial has coefficient gcd 160, odd
primitive coefficient sum -1, and only the constant character. Its 2-adic
valuation is 5, so it is a valid modulo-64 contradiction. Treating the
ordinary integer gcd 160 as if it were a modulus divisor is unnecessary.

The dimension-4 trace also records some earlier, unused affine equations
with gcds 8,16,56. Their valuations are 3,4,3, respectively, all compatible
with a modulo-64 implication. Their presence is not needed for the simpler
single-character terminal contradiction.

## 4. Verification obligations and scope

An independent checker must rebuild A,B characters and original lag
polynomials from the declared q,t and sign affine basis; check coefficient
gcds and equation right sides; validate any XOR contradiction provenance;
and verify that the substituted affine basis covers the full solution space.
The fixed-point and XOR updates must use all original character labels.
The hardware agent is implementing that independent certificate check.

The full orientation enumeration remains the large finite coverage obligation.
When its complete domain and the sign certificates are accepted, the stronger
modulo-64 statement follows through the exact implication chain above.
Until then, describe this as an audited extension of the proposed finite
argument, rather than as an already independently completed theorem.
