"""Independent checker for integer-character exclusions of affine sign spaces.

No producer/search imports. Original correlations are rebuilt as the upper
triangle of the signed two-row Gram matrix. Exact coefficient division occurs
over Z, before any congruence is taken. Affine restrictions must describe the
ENTIRE solution space of their verified necessary linear equations.
"""
import argparse
import hashlib
import json
from math import gcd
from pathlib import Path
import time

if not __debug__:
    raise RuntimeError('checker requires assertions enabled; do not use Python -O')


def unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON object key: {key}')
        result[key]=value
    return result


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path):
    return json.loads(path.read_text(),object_pairs_hook=unique_object)


def original_character_polynomials(n,q,t,base,basis):
    """Build all signed pair products first, then collect them by distance."""
    p=n//2
    assert n%2==0 and 2<=n<=126
    assert all(type(v) is int and 0<=v<(1<<p) for v in (q,t,base,*basis))
    assert all(v%2==0 for v in (q,t,base,*basis))
    a=[0]*n
    b=[0]*n
    for i in range(p):
        sign=1 if not(base&(1<<i)) else -1
        qsign=1 if not(q&(1<<i)) else -1
        tsign=1 if not(t&(1<<i)) else -1
        a[i],b[i]=sign,sign*qsign
        a[n-1-i],b[n-1-i]=sign*tsign,-sign*qsign*tsign
    labels=[0]*n
    for variable,flip in enumerate(basis):
        for i in range(p):
            if flip&(1<<i):
                labels[i]|=1<<variable
                labels[n-1-i]|=1<<variable
    polys=[{} for _ in range(n)]
    for left in range(n):
        for right in range(left+1,n):
            coefficient=a[left]*a[right]+b[left]*b[right]
            if coefficient:
                poly=polys[right-left]
                character=labels[left]^labels[right]
                poly[character]=poly.get(character,0)+coefficient
    return [{mask:c for mask,c in poly.items() if c} for poly in polys]


def primitive(poly):
    assert poly
    divisor=0
    for coefficient in poly.values():
        assert type(coefficient) is int and coefficient!=0
        divisor=gcd(divisor,abs(coefficient))
    assert divisor>0 and all(c%divisor==0 for c in poly.values())
    reduced={mask:c//divisor for mask,c in poly.items()}
    assert all(divisor*reduced[mask]==c for mask,c in poly.items())
    return divisor,reduced,sum(reduced.values())


def implied_affine_equation(poly):
    """P=0 => sum c*b_M=sum(c)/2 in Z, then reduce this equality mod2."""
    divisor,reduced,total=primitive(poly)
    assert total%2==0, 'an odd primitive total is already a terminal contradiction'
    mask=0
    for character,coefficient in reduced.items():
        if coefficient%2:
            mask^=character
    return divisor,total,mask,(total//2)%2


def xor_selected(selector,vectors):
    assert type(selector) is int and 0<=selector<(1<<len(vectors))
    result=0
    for i,vector in enumerate(vectors):
        if selector&(1<<i):
            result^=vector
    return result


def rank_provenance(equations,width):
    """Independent high-pivot row basis, retaining exact original-row XORs."""
    augmented=[row['mask']|(row['rhs']<<width) for row in equations]
    coefficient_mask=(1<<width)-1
    pivots={}
    for index,raw in enumerate(augmented):
        row=raw
        provenance=1<<index
        while row&coefficient_mask:
            pivot=(row&coefficient_mask).bit_length()-1
            if pivot not in pivots:
                pivots[pivot]=(row,provenance)
                break
            row^=pivots[pivot][0]
            provenance^=pivots[pivot][1]
    certificate=[]
    for pivot,(row,selector) in sorted(pivots.items(),reverse=True):
        # These checks make the reported lower-rank witness independently
        # inspectable: each row is an exact XOR, with a distinct leading bit.
        assert xor_selected(selector,augmented)==row
        assert (row&coefficient_mask).bit_length()-1==pivot
        certificate.append({'leading_column':pivot,'augmented_row':row,
                            'original_equation_indices':[i for i in range(len(equations)) if selector&(1<<i)]})
    return len(pivots),certificate


def vector_rank(vectors):
    pivots={}
    for raw in vectors:
        value=raw
        while value:
            bit=value.bit_length()-1
            if bit not in pivots:
                pivots[bit]=value
                break
            value^=pivots[bit]
    return len(pivots)


def verify_full_affine_preimage(equations,width,claim):
    assert claim['consistent'] is True
    part=claim['particular']
    basis=claim['kernel']
    assert type(part) is int and 0<=part<(1<<width)
    assert all(type(v) is int and 0<=v<(1<<width) for v in basis)
    assert vector_rank(basis)==len(basis)
    for row in equations:
        assert (row['mask']&part).bit_count()%2==row['rhs']
        assert all((row['mask']&v).bit_count()%2==0 for v in basis)
    rank,certificate=rank_provenance(equations,width)
    assert type(claim['rank']) is int and claim['rank']==rank
    assert rank+len(basis)==width, 'claimed affine restriction omits solutions'
    return certificate


def verify_mod64_strengthening(n,q,t,base,basis,entry):
    """Use an explicit safe subset; never divide a congruence by an arbitrary gcd."""
    polys=original_character_polynomials(n,q,t,base,basis)
    d=len(basis)
    if d==4:
        lag=entry['stages'][-1]['contradiction']['lag']
        poly=polys[lag]
        assert len(poly)==1
        (mask,coefficient),=poly.items()
        assert abs(coefficient)==16 and 0<=mask<(1<<d)
        return {'case':'SINGLE_CHARACTER','modulus':64,'lag':lag,
                'integer_terms':[[mask,coefficient]],'possible_residues_mod64':[16,48],
                'also_excluded_mod32':True,
                'conclusion':'correlation cannot be0 modulo64'}
    if d==26:
        equations=[]
        for lag in (24,28):
            divisor,total,mask,rhs=implied_affine_equation(polys[lag])
            assert divisor==8
            equations.append({'lag':lag,'coefficient_gcd':8,
                              'primitive_coefficient_sum':total,'mask':mask,'rhs':rhs})
        assert equations[0]['mask']==equations[1]['mask']
        assert equations[0]['rhs']^equations[1]['rhs']==1
        return {'case':'OPPOSITE_PARITY_CONSEQUENCES','modulus':64,
                'justification':'r=8P and64 divides r imply8 divides P, hence P=0 modulo4',
                'equations':equations,'xor_mask':0,'xor_rhs':1,
                'also_excluded_mod32':True,
                'conclusion':'the two original correlations cannot both be0 modulo64'}
    assert d==20, 'unexpected sign-space dimension for this explicit strengthening'
    safe_lags=[2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,40]
    equations=[]
    for lag in safe_lags:
        divisor,total,mask,rhs=implied_affine_equation(polys[lag])
        assert divisor==8
        equations.append({'lag':lag,'coefficient_gcd':8,
                          'primitive_coefficient_sum':total,'mask':mask,'rhs':rhs})
    solution=entry['stages'][0]['affine_solution']
    rank_witness=verify_full_affine_preimage(equations,d,solution)
    assert len(rank_witness)==18 and len(solution['kernel'])==2
    new_base=base^xor_selected(solution['particular'],basis)
    new_basis=[xor_selected(v,basis) for v in solution['kernel']]
    final_polys=original_character_polynomials(n,q,t,new_base,new_basis)
    assert final_polys[4]=={0:-160}
    assert (-160)%64==32
    return {'case':'SAFE_LINEAR_RESTRICTION_THEN_CONSTANT','modulus':64,
            'justification':'all18 used rows have r=8P;64 divides r implies P=0 modulo4',
            'safe_lags':safe_lags,'equations':equations,'rank':18,'rank_witness':rank_witness,
            'parameter_particular':solution['particular'],'parameter_kernel':solution['kernel'],
            'restricted_sign_particular':new_base,'restricted_sign_kernel':new_basis,
            'restriction_also_necessary_mod32':True,
            'terminal_lag':4,'constant_correlation':-160,'residue_mod64':32,
            'conclusion':'every remaining assignment violates r4=0 modulo64'}


def signed_pair(n,q,t,u):
    half=n//2
    A=[1 if not(u&(1<<i)) else -1 for i in range(half)]
    B=[A[i]*(1 if not(q&(1<<i)) else -1) for i in range(half)]
    right_A=[A[i]*(1 if not(t&(1<<i)) else -1) for i in range(half)]
    right_B=[-B[i]*(1 if not(t&(1<<i)) else -1) for i in range(half)]
    return A+right_A[::-1],B+right_B[::-1]


def validate_mod32_witnesses(n,verified,certificate_path,witness_path):
    expected={}
    for space in verified:
        proof=space['mod64_strengthening']
        if proof['case']!='SAFE_LINEAR_RESTRICTION_THEN_CONSTANT':
            assert proof['also_excluded_mod32'] is True
            continue
        assert proof['restriction_also_necessary_mod32'] is True
        base=proof['restricted_sign_particular']
        kernel=proof['restricted_sign_kernel']
        assert len(kernel)==2
        for choice in range(4):
            u=base^xor_selected(choice,kernel)
            key=(space['q_bits_mask'],space['t_bits_mask'],u)
            assert key not in expected
            expected[key]=choice
    assert len(expected)==8
    supplied=load_json(witness_path)
    assert supplied['source_certificate_sha256']==digest(certificate_path)
    assert len(supplied['rows'])==len(expected)
    seen=set()
    pairs=[]
    facts=[]
    for row in supplied['rows']:
        key=(row['q_bits_mask'],row['t_bits_mask'],row['sign_bits_mask'])
        assert key in expected and key not in seen
        seen.add(key)
        assert row['reduced_assignment']==expected[key]
        A,B=signed_pair(n,*key)
        assert all(type(value) is int and value in (-1,1) for value in row['A']+row['B'])
        assert row['A']==A and row['B']==B
        residuals=[]
        for lag in range(1,n):
            value=sum(A[i]*A[i+lag]+B[i]*B[i+lag] for i in range(n-lag))
            residuals.append(value)
        assert residuals==row['original_combined_aperiodic_residuals']
        assert all(value%32==0 for value in residuals)
        assert any(value%64!=0 for value in residuals)
        assert row['all_zero_mod32'] is True and row['all_zero_mod64'] is False
        energy=sum(value*value for value in residuals)
        maximum=max(map(abs,residuals))
        assert energy==row['combined_sidelobe_energy']==56320
        assert maximum==row['maximum_absolute_residual']==160
        nonzero=[[i+1,value] for i,value in enumerate(residuals) if value]
        assert [k for k,v in nonzero]==row['nonzero_lags']==[4,8,12,16,20]
        pairs.append((tuple(A),tuple(B)))
        facts.append({'q_bits_mask':key[0],'t_bits_mask':key[1],'sign_bits_mask':key[2],
                      'reduced_assignment':expected[key],'nonzero_original_residuals':nonzero,
                      'energy':energy,'maximum_absolute_residual':maximum})
    assert seen==set(expected) and len(set(pairs))==8
    # A separate finite orbit calculation uses only the explicitly stated
    # symmetries, with no producer canonicalization helper or hash convention.
    orbit={pairs[0]}
    pending=[pairs[0]]
    while pending:
        A,B=pending.pop()
        alternatives=[(tuple(-x for x in A),B),(A,tuple(-x for x in B)),(B,A),
                      (A[::-1],B),(A,B[::-1]),
                      (tuple((-1 if i%2 else 1)*x for i,x in enumerate(A)),
                       tuple((-1 if i%2 else 1)*x for i,x in enumerate(B)))]
        for pair in alternatives:
            if pair not in orbit:
                orbit.add(pair)
                pending.append(pair)
    normalized={pair for pair in orbit if pair[0][0]==pair[1][0]==pair[0][-1]==1 and pair[1][-1]==-1}
    assert normalized==set(pairs)
    assert len(orbit)==64
    reversal_pairs=set()
    position={pair:i for i,pair in enumerate(pairs)}
    for i,(A,B) in enumerate(pairs):
        reversal_pairs.add(tuple(sorted((i,position[(A[::-1],B)]))))
    assert sorted(reversal_pairs)==sorted(tuple(sorted(x)) for x in supplied['A_reversal_orbits'])
    return {'result':'PASS','witness_file_sha256':digest(witness_path),
            'original_signed_correlations_recomputed':True,'verified_mod32_pairs':8,
            'all_eight_fail_mod64':True,'exact_mod32_count_within_supplied_spaces':8,
            'global_count_requires_upstream_orientation_coverage':True,
            'global_count_requires_modular_mirror_and_normalization_proof':True,
            'one_standard_symmetry_orbit':True,'full_generated_orbit_size':64,
            'mode_P_members_in_orbit':8,'witnesses':facts}


def check(n,spaces_path,certificate_path,audit_path=None,witness_path=None):
    started=time.process_time()
    raw=spaces_path.read_bytes()
    assert raw.endswith(b'\n')
    input_rows=[json.loads(line,object_pairs_hook=unique_object) for line in raw.decode().splitlines()]
    inputs={}
    for row in input_rows:
        if row.get('sign_system_consistent') is True:
            key=(row['q_bits_mask'],row['t_bits_mask'])
            assert key not in inputs
            inputs[key]=row
    proof=load_json(certificate_path)
    assert proof['input_sha256']==hashlib.sha256(raw).hexdigest()
    assert proof['method']=='primitive_integer_character_congruences'
    assert len(proof['spaces'])==len(inputs)
    upstream=None
    if audit_path:
        upstream=load_json(audit_path)
        assert upstream['result']=='PASS' and upstream['n']==n
        audited={ (row['q_bits_mask'],row['t_bits_mask']):row for row in upstream['orientations']
                  if row['affine_system']=='CONSISTENT' }
        assert set(audited)==set(inputs)
        for key,row in inputs.items():
            descriptor=(row['sign_particular_bits_mask'],row['sign_kernel_masks'])
            assert any((group['particular_bits_mask'],group['kernel_masks'])==descriptor
                       for group in audited[key]['coordinate_groups'])
    seen=set()
    verified=[]
    for entry in proof['spaces']:
        q,t=entry['q_bits_mask'],entry['t_bits_mask']
        key=(q,t)
        assert key in inputs and key not in seen
        seen.add(key)
        input_row=inputs[key]
        expected_base=input_row['sign_particular_bits_mask']
        expected_basis=input_row['sign_kernel_masks']
        assert entry['initial_dimension']==len(expected_basis)
        assert entry['status']=='EXCLUDED_BY_EXACT_CONGRUENCE' and entry['stages']
        record={'q_bits_mask':q,'t_bits_mask':t,'initial_dimension':len(expected_basis),'stages':[]}
        terminal=False
        for stage_index,stage in enumerate(entry['stages']):
            assert not terminal, 'extra stage after contradiction'
            d=stage['dimension']
            assert type(d) is int and d==len(expected_basis)
            assert stage['sign_particular_bits_mask']==expected_base
            assert stage['sign_kernel_masks']==expected_basis
            polys=original_character_polynomials(n,q,t,expected_base,expected_basis)
            equations=stage['equations']
            checked={'dimension':d,'verified_equation_count':len(equations)}
            for equation in equations:
                lag=equation['lag']
                assert type(lag) is int and 1<=lag<n
                actual=implied_affine_equation(polys[lag])
                claimed=tuple(equation[k] for k in ('coefficient_gcd','primitive_coefficient_sum','mask','rhs'))
                assert all(type(v) is int for v in claimed)
                assert actual==claimed, 'claimed necessary congruence does not match original lag'
                assert 0<=equation['mask']<(1<<d) and equation['rhs'] in (0,1)
            if 'contradiction' in stage:
                contradiction=stage['contradiction']
                assert contradiction['type']=='primitive_polynomial_odd_mod2'
                lag=contradiction['lag']
                assert type(lag) is int and 1<=lag<n
                divisor,reduced,total=primitive(polys[lag])
                assert divisor==contradiction['coefficient_gcd']
                assert total==contradiction['coefficient_sum'] and total%2==1
                assert sorted(reduced.items())==[tuple(x) for x in contradiction['primitive_terms']]
                checked['terminal']={'type':'ODD_INTEGER_CHARACTER_SUM','lag':lag,
                                     'original_integer_terms':sorted(polys[lag].items()),
                                     'coefficient_gcd':divisor,'primitive_sum':total}
                terminal=True
            else:
                solved=stage['affine_solution']
                if solved['consistent'] is False:
                    indices=solved['contradiction_equation_indices']
                    assert indices and len(indices)==len(set(indices))
                    assert all(type(i) is int and 0<=i<len(equations) for i in indices)
                    mask=rhs=0
                    for i in indices:
                        mask^=equations[i]['mask']
                        rhs^=equations[i]['rhs']
                    assert mask==0 and rhs==1, 'XOR provenance does not prove 0=1'
                    checked['terminal']={'type':'VERIFIED_XOR_0_EQ_1',
                                         'equation_indices':indices,
                                         'source_lag_equations':[equations[i] for i in indices]}
                    terminal=True
                else:
                    checked['rank_witness']=verify_full_affine_preimage(equations,d,solved)
                    checked['full_affine_solution_dimension']=len(solved['kernel'])
                    expected_base^=xor_selected(solved['particular'],expected_basis)
                    expected_basis=[xor_selected(v,expected_basis) for v in solved['kernel']]
            record['stages'].append(checked)
        assert terminal, 'certificate ends without contradiction'
        record['result']='EXACT_INTEGER_CHARACTER_EXCLUSION_CHECKED'
        record['mod64_strengthening']=verify_mod64_strengthening(
            n,q,t,input_row['sign_particular_bits_mask'],input_row['sign_kernel_masks'],entry)
        verified.append(record)
    assert seen==set(inputs)
    result={'result':'PASS','claim':'SUPPLIED_AFFINE_SIGN_SPACES_EXCLUDED_BY_CHECKED_INTEGER_CERTIFICATES',
            'n':n,'spaces_checked':len(verified),'space_input_sha256':digest(spaces_path),
            'certificate_sha256':digest(certificate_path),'checker_source_sha256':digest(Path(__file__)),
            'upstream_affine_audit_sha256':digest(audit_path) if audit_path else None,
            'upstream_affine_spaces_linked':bool(audit_path),
            'all_supplied_spaces_excluded_mod64':True,
            'global_first_stage_completeness_verified':False,'formal_kernel':False,
            'method':'original signed Gram products; exact integer gcd; checked mod4 consequences; full affine restrictions',
            'trusted_base':['Python exact integer arithmetic','strict JSON parser','small rank and XOR checks'],
            'spaces':verified}
    if witness_path:
        result['mod32_witness_validation']=validate_mod32_witnesses(n,verified,certificate_path,witness_path)
    result['cpu_seconds']=time.process_time()-started
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--n',type=int,default=106)
    parser.add_argument('--spaces',type=Path,required=True)
    parser.add_argument('--certificate',type=Path,required=True)
    parser.add_argument('--affine-audit',type=Path)
    parser.add_argument('--mod32-witnesses',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=check(args.n,args.spaces,args.certificate,args.affine_audit,args.mod32_witnesses)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ('result','claim','spaces_checked','upstream_affine_spaces_linked','cpu_seconds')},indent=2))


if __name__=='__main__':
    main()
