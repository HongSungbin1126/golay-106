"""Final root-owned integrity/coverage audit of the separate first-stage replay."""
import argparse
from collections import Counter
import json
from pathlib import Path
from audit_fiber_campaign import check_orientation, read_json, require, sha, unique


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--campaign',default='results/campaign_n106_first_parity_independent')
    parser.add_argument('--reference',default='results/campaign_n106_first_parity_orientations.jsonl')
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    folder=Path(args.campaign)
    cfg=read_json(folder/'configuration.json')
    total=1<<26
    require(cfg['total_H_domain']==total and cfg['workers']==4,'wrong campaign target')
    for name,key in [('source_snapshot.cpp','source_sha256'),('binary_snapshot','binary_sha256'),
                     ('controller_snapshot.py','controller_sha256'),
                     ('controller_dependency_snapshot.py','controller_dependency_sha256')]:
        require(sha(folder/name)==cfg[key],f'changed immutable snapshot: {name}')
    require(sha('src/verify_folded_independent_v2.cpp')==cfg['source_sha256'],'current source differs from replay snapshot')
    require(sha(args.reference)==cfg['reference_sha256'],'primary reference changed')
    refrows=[json.loads(x,object_pairs_hook=unique) for x in Path(args.reference).read_text().splitlines()]
    require(refrows[0]['record_type']=='header' and refrows[-1]['record_type']=='footer','reference framing')
    require(refrows[-1]['H_completed']==total,'reference domain count')
    reference={}
    for row in refrows[1:-1]:
        pair=check_orientation(row,53,0,total)
        require(pair not in reference,'duplicate primary orientation')
        reference[pair]=row['h']
    selected=[];orientations={};statistics=Counter();histogram=Counter()
    cursor=0;cpu=0.;peak=0
    receipt_paths=sorted(folder.glob('h*.receipt.json'))
    require(len(receipt_paths)==64,'requires all64 independent partitions')
    for path in receipt_paths:
        rec=read_json(path)
        require(rec['result']=='EXACT_PRIMARY_SET_MATCH_AND_LITERAL_PARITY_PASS','controller did not accept partition')
        require(rec['source_sha256']==cfg['source_sha256'] and rec['binary_sha256']==cfg['binary_sha256'],'partition executable mismatch')
        start,end=rec['h_start'],rec['h_end_exclusive']
        require(start==cursor and end-start==cfg['chunk_size'],'range gap/overlap/wrong chunk size')
        require(rec['H_completed']==end-start,'incomplete receipt')
        stem=f'h{start:09d}'
        require(path.name==stem+'.receipt.json','receipt filename mismatch')
        report_path,orientation_path=folder/(stem+'.json'),folder/(stem+'.jsonl')
        require(Path(rec['report_path']).name==report_path.name and Path(rec['orientation_path']).name==orientation_path.name,'output filename mismatch')
        require(sha(report_path)==rec['report_sha256'] and sha(orientation_path)==rec['orientation_sha256'],'changed committed output bytes')
        report=read_json(report_path)
        require(report['solver']=='independent_row_rref_QU_DC_v2' and report['p']==53 and report['n']==106,'report solver or target mismatch')
        require(report['status']=='COMPLETE_H_PARTITION' and report['source_sha256']==cfg['source_sha256'],'incomplete/wrong-source report')
        require(report['h_start']==start and report['h_end_exclusive']==end and report['covered_end_exclusive']==end,'report covered interval mismatch')
        require(report['H_completed']==end-start,'report completion count')
        stats=report['statistics']
        require(stats['H_examined']==end-start,'examined count differs')
        require(stats['nonunit_H']==int(start==0) and stats['unit_H']==end-start-int(start==0),'J53 inverse coverage failure')
        raw=orientation_path.read_text()
        require(raw.endswith('\n'),'truncated orientation output')
        rows=[json.loads(x,object_pairs_hook=unique) for x in raw.splitlines()]
        require(len(rows)>=2,'missing header/footer')
        header,footer=rows[0],rows[-1]
        require(header['record_type']=='header' and header['format']=='independent_folded_orientations_v2','independent header schema')
        require(header['p']==53 and header['n']==106 and header['source_sha256']==cfg['source_sha256'],'independent header target/source')
        require(header['h_start']==start and header['h_end_exclusive']==end,'header interval')
        require(footer['record_type']=='footer' and footer['status']==report['status'],'footer completion status')
        require(footer['h_start']==start and footer['covered_end_exclusive']==end and footer['H_completed']==end-start,'footer covered interval')
        body=rows[1:-1]
        require(len(body)==report['orientation_records']==footer['orientation_records']==rec['orientation_count']==stats['solutions_including_uncommitted_fiber'],'candidate accounting mismatch')
        current={}
        for row in body:
            pair=check_orientation(row,53,start,end)
            require(pair not in orientations and pair not in current,'duplicate independent orientation')
            current[pair]=row['h']
        expected={pair:h for pair,h in reference.items() if start<=h<end}
        require(current==expected,'independent/primary candidate sets differ')
        orientations.update(current);statistics.update(stats);histogram.update(report['stage_histogram'])
        cpu+=report['cpu_seconds'];peak=max(peak,report['peak_rss_kib'])
        selected.append({'h_start':start,'h_end_exclusive':end,'orientation_count':len(body),
                         'receipt_path':str(path),'receipt_sha256':sha(path),
                         'report_path':str(report_path),'report_sha256':sha(report_path),
                         'orientation_path':str(orientation_path),'orientation_sha256':sha(orientation_path)})
        cursor=end
    require(cursor==total and orientations==reference,'full-domain or full-set disagreement')
    require(statistics['H_examined']==total and statistics['unit_H']==total-1 and statistics['nonunit_H']==1,'global H count')
    state=read_json(folder/'campaign_state.json')
    require(state['status']=='COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY','controller has not reached final acceptance')
    require(state['H_completed']==total and state['completed_partitions']==64,'controller final count incomplete')
    final=read_json(folder/'final_summary.json')
    require(final['status']==state['status'] and final['orientation_count']==len(orientations),'final summary mismatch')
    require(sha(folder/'all_orientations.jsonl')==final['orientation_sha256'],'changed independent aggregate')
    merged=[json.loads(line,object_pairs_hook=unique) for line in (folder/'all_orientations.jsonl').read_text().splitlines()]
    require(merged[0]['record_type']=='header' and merged[-1]['record_type']=='footer','bad global independent framing')
    require(merged[-1]['status']=='COMPLETE_H_DOMAIN' and merged[-1]['H_completed']==total,'bad global independent footer')
    require({(x['q_bits_mask'],x['t_bits_mask']):x['h'] for x in merged[1:-1]}==reference and len(merged)==len(reference)+2,'global aggregate candidate mismatch')
    for half,(lo,hi) in enumerate(((0,1<<25),(1<<25,1<<26)),1):
        checkpoint=read_json(folder/f'half{half}_checkpoint.json')
        require(checkpoint['status']=='HALF_BATCH_CHECKPOINT' and checkpoint['batch_covered_interval']==[lo,hi],'half checkpoint interval mismatch')
        require(checkpoint['batch_wall_seconds']<=cfg['half_batch_wall_limit'],'half exceeded configured wall allowance')
    result={'status':'COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY_ACCEPTED',
            'scope':'exact first-parity orientation enumeration, not by itself original Golay nonexistence',
            'n':106,'domain':[0,total],'covered_H':total,'partition_count':64,
            'orientation_count':len(orientations),'exact_primary_set_match':True,
            'statistics':dict(statistics),'stage_histogram':dict(histogram),
            'aggregate_native_cpu_seconds':cpu,'maximum_worker_rss_kib':peak,
            'controller_wall_seconds':final['wall_seconds'],
            'controller_child_cpu_seconds':final['aggregate_child_cpu_seconds'],
            'source_sha256':cfg['source_sha256'],'binary_sha256':cfg['binary_sha256'],
            'primary_reference_sha256':cfg['reference_sha256'],
            'configuration_sha256':sha(folder/'configuration.json'),
            'auditor_sha256':sha(__file__),'auditor_dependency_sha256':sha('src/audit_fiber_campaign.py'),
            'partitions':selected,'formal_kernel_proof':False}
    Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','covered_H','orientation_count','aggregate_native_cpu_seconds')}))


if __name__=='__main__':main()
