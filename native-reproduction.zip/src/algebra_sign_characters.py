"""Exact symbolic modular reduction of original correlations on sign spaces.

No heuristic pruning and no floating point. Integer character polynomials are
rebuilt from original A/B coefficients after every affine restriction. This
is an established successive-congruence idea, not a novelty claim.
"""
import argparse
from collections import Counter
from functools import reduce
import hashlib
import json
from math import gcd
from pathlib import Path
import resource
import time


def combine(selector, masks):
    value = 0
    while selector:
        low = selector & -selector
        value ^= masks[low.bit_length()-1]
        selector ^= low
    return value


def coefficients(n, q, t, particular, kernel):
    p = n//2
    A, B = [None]*n, [None]*n
    for i in range(p):
        label = sum(((v >> i) & 1) << j for j, v in enumerate(kernel))
        signbit = (particular >> i) & 1
        qb, tb = (q >> i) & 1, (t >> i) & 1
        A[i] = (1-2*signbit, label)
        B[i] = (1-2*(signbit ^ qb), label)
        A[n-1-i] = (1-2*(signbit ^ tb), label)
        B[n-1-i] = (1-2*(signbit ^ tb ^ qb ^ 1), label)
    return A, B


def correlation_polynomials(A, B):
    n = len(A)
    out = []
    for lag in range(1, n):
        poly = Counter()
        for row in (A, B):
            for i in range(n-lag):
                a, u = row[i]
                b, v = row[i+lag]
                poly[u ^ v] += a*b
        out.append({mask: value for mask, value in poly.items() if value})
    return out


def solve_rows(equations, d):
    """RREF with exact XOR provenance in the supplied equation list."""
    rows = [[e["mask"] | (e["rhs"] << d), 1 << i]
            for i, e in enumerate(equations)]
    pivots = []
    rank = 0
    for col in range(d):
        pivot = next((j for j in range(rank, len(rows)) if (rows[j][0] >> col) & 1), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for j in range(len(rows)):
            if j != rank and ((rows[j][0] >> col) & 1):
                rows[j][0] ^= rows[rank][0]
                rows[j][1] ^= rows[rank][1]
        pivots.append(col)
        rank += 1
    for row, proof in rows:
        if row == 1 << d:
            return {"consistent": False,
                    "contradiction_equation_indices": [i for i in range(len(equations)) if (proof >> i) & 1]}
    particular = sum(((rows[j][0] >> d) & 1) << col for j, col in enumerate(pivots))
    kernel = []
    for free in range(d):
        if free in pivots:
            continue
        v = 1 << free
        for j, col in enumerate(pivots):
            v |= ((rows[j][0] >> free) & 1) << col
        kernel.append(v)
    return {"consistent": True, "rank": rank, "particular": particular, "kernel": kernel}


def analyze(row, n, deadline):
    q, t = row["q_bits_mask"], row["t_bits_mask"]
    particular, kernel = row["sign_particular_bits_mask"], row["sign_kernel_masks"][:]
    result = {"q_bits_mask": q, "t_bits_mask": t,
              "initial_dimension": len(kernel), "stages": []}
    while True:
        if time.process_time() > deadline:
            result["status"] = "TIMEOUT"
            return result
        d = len(kernel)
        A, B = coefficients(n, q, t, particular, kernel)
        polys = correlation_polynomials(A, B)
        stage = {"dimension": d, "sign_particular_bits_mask": particular,
                 "sign_kernel_masks": kernel[:], "equations": []}
        result["stages"].append(stage)
        for lag, poly in enumerate(polys, 1):
            if not poly:
                continue
            divisor = reduce(gcd, (abs(c) for c in poly.values()))
            primitive = {mask: c//divisor for mask, c in poly.items()}
            total = sum(primitive.values())
            if total & 1:
                stage["contradiction"] = {
                    "type": "primitive_polynomial_odd_mod2", "lag": lag,
                    "coefficient_gcd": divisor, "coefficient_sum": total,
                    "primitive_terms": sorted(primitive.items())}
                result["status"] = "EXCLUDED_BY_EXACT_CONGRUENCE"
                return result
            mask = 0
            for monomial, coefficient in primitive.items():
                if coefficient & 1:
                    mask ^= monomial
            rhs = (total//2) & 1
            if mask or rhs:
                stage["equations"].append({"lag": lag, "coefficient_gcd": divisor,
                                           "primitive_coefficient_sum": total,
                                           "mask": mask, "rhs": rhs})
        solved = solve_rows(stage["equations"], d)
        stage["affine_solution"] = solved
        if not solved["consistent"]:
            result["status"] = "EXCLUDED_BY_EXACT_CONGRUENCE"
            return result
        if solved["rank"]:
            particular ^= combine(solved["particular"], kernel)
            kernel = [combine(v, kernel) for v in solved["kernel"]]
            continue
        if not any(polys):
            result["status"] = "ORIGINAL_GOLAY_WITNESS"
            result["A"] = [c for c, _ in A]
            result["B"] = [c for c, _ in B]
            return result
        result["status"] = "STALLED_NOT_EXCLUDED"
        result["remaining_nonzero_lags"] = [k for k, p in enumerate(polys, 1) if p]
        return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path,
                        default=Path("results/exact_signs_n106_campaign_kernel_inventory.jsonl"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=50)
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (int(args.seconds)+2, int(args.seconds)+4))
    raw = args.input.read_bytes()
    rows = [r for line in raw.splitlines() if (r := json.loads(line)).get("sign_system_consistent")]
    start = time.process_time()
    result = {"method": "primitive_integer_character_congruences",
              "scope": "only supplied sign spaces; upstream coverage must be verified separately",
              "input_sha256": hashlib.sha256(raw).hexdigest(),
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "spaces": [analyze(row, 106, start+args.seconds) for row in rows]}
    result["cpu_seconds"] = time.process_time()-start
    result["status_counts"] = dict(Counter(r["status"] for r in result["spaces"]))
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"cpu_seconds": result["cpu_seconds"], "status_counts": result["status_counts"],
                      "spaces": [{"q": r["q_bits_mask"], "t": r["t_bits_mask"],
                                  "dimensions": [s["dimension"] for s in r["stages"]],
                                  "status": r["status"]} for r in result["spaces"]]}, indent=2))


if __name__ == "__main__":
    main()
