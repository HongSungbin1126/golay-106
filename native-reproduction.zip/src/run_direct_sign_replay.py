"""Run independent direct signed-correlation replay of audited sign spaces."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import tempfile
import time


ROOT=Path(__file__).resolve().parents[1]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition,message):
    if not condition:raise ValueError(message)


def atomic(path,content):
    path=Path(path);fd,tmp=tempfile.mkstemp(prefix=path.name+'.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(content);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def save(path,obj):atomic(path,(json.dumps(obj,indent=2)+'\n').encode())


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--audit',required=True)
    parser.add_argument('--tag',required=True)
    parser.add_argument('--seconds',type=int,default=1100)
    args=parser.parse_args()
    require(0<args.seconds<=1180,'per-batch CPU limit')
    os.chdir(ROOT)
    report_path=ROOT/'results'/(args.tag+'.json')
    output_path=ROOT/'results'/(args.tag+'.jsonl')
    input_path=ROOT/'results'/(args.tag+'_input.txt')
    require(not report_path.exists() and not output_path.exists(),'refusing to overwrite previous replay')
    audit=json.loads(Path(args.audit).read_text())
    require(audit['result']=='PASS' and audit['complete_declared_input_coverage'],'incomplete sign-space audit')
    require(audit['auditor_source_sha256']==sha(ROOT/'tests/exact_sign_space_audit.py'),'auditor source changed')
    for item in audit['orientation_inputs']+audit['detail_inputs']:
        require(sha(item['path'])==item['sha256'],'audited input changed')
    spaces=[]
    for row in audit['orientations']:
        if row['affine_system']=='INCONSISTENT':continue
        groups=[g for g in row['coordinate_groups'] if g['complete_coordinate_space']]
        require(bool(groups),'missing complete affine coordinates')
        group=groups[0]
        require(len(group['kernel_masks'])==row['nullity'],'nullity mismatch')
        spaces.append({'q':row['q_bits_mask'],'t':row['t_bits_mask'],
                       'base':group['particular_bits_mask'],'basis':group['kernel_masks'],
                       'expected':row['space_size']})
    n=audit['n']
    text=f'{n} {len(spaces)}\n'+''.join(' '.join(map(str,[s['q'],s['t'],s['base'],len(s['basis']),*s['basis']]))+'\n' for s in spaces)
    atomic(input_path,text.encode())
    source=ROOT/'src/verify_signs_direct.cpp'
    binary=ROOT/'src/verify_signs_direct'
    build_command=['g++','-O3','-std=c++17','-Wall','-Wextra',str(source),'-o',str(binary)]
    subprocess.run(build_command,check=True,capture_output=True)
    source_hash,binary_hash=sha(source),sha(binary)
    manifest={'scope':'INDEPENDENT_ORIGINAL_SIGNED_CORRELATION_REPLAY_OF_CERTIFIED_AFFINE_SPACES',
              'n':n,'audit_path':args.audit,'audit_sha256':sha(args.audit),
              'source_sha256':source_hash,'binary_sha256':binary_hash,'wrapper_sha256':sha(__file__),
              'build_command':build_command,'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
              'input_path':str(input_path.relative_to(ROOT)),'input_sha256':sha(input_path),
              'space_count':len(spaces),'expected_sign_assignments':sum(s['expected'] for s in spaces),
              'affine_contradictions_verified_by_prior_audit':audit['affine_contradictions_independently_verified'],
              'first_stage_completeness_obligation':'external; not proved by this program',
              'native_space_claims_checked_by_independent_auditor':True}
    save(ROOT/'results'/(args.tag+'_manifest.json'),manifest)
    start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='golay_direct_signs_') as tmp:
        tmp=Path(tmp)
        private_input,private_output=tmp/'input.txt',tmp/'output.jsonl'
        private_input.write_text(text)
        def limits():
            resource.setrlimit(resource.RLIMIT_CPU,(args.seconds+3,args.seconds+5))
            resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
            resource.setrlimit(resource.RLIMIT_CORE,(0,0))
            resource.setrlimit(resource.RLIMIT_FSIZE,(200*1024**2,200*1024**2))
        command=[str(binary),str(private_input),str(private_output),str(args.seconds)]
        run=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,
                           timeout=args.seconds+15,preexec_fn=limits)
        require(private_output.exists(),'direct replay produced no output')
        raw=private_output.read_bytes()
        atomic(output_path,raw)
    require(sha(source)==source_hash and sha(binary)==binary_hash,'replay executable changed during run')
    rows=[json.loads(line) for line in raw.decode().splitlines()]
    require(len(rows)>=2 and rows[0]['record_type']=='header' and rows[-1]['record_type']=='footer','truncated direct replay')
    header,footer=rows[0],rows[-1]
    require(header['n']==n and header['spaces']==len(spaces),'wrong replay target')
    records=[r for r in rows[1:-1] if r['record_type']=='space']
    positive=[r for r in rows[1:-1] if r['record_type']=='witness']
    complete=run.returncode==0 and footer['status']=='COMPLETE_SUPPLIED_SPACES_NO_PAIR'
    if complete:
        require(not positive and len(rows)==len(spaces)+2 and len(records)==len(spaces) and footer['completed_spaces']==len(spaces),'incomplete sign list')
        total=0
        for i,(record,space) in enumerate(zip(records,spaces)):
            require(record['index']==i and record['q_bits_mask']==space['q'] and record['t_bits_mask']==space['t'],'sign-space identity mismatch')
            require(record['complete'] and record['nullity']==len(space['basis']),'unfinished affine space')
            require(record['expected_assignments']==space['expected']==record['examined_assignments'],'sign interval gap')
            hist=record['first_rejection_lag_histogram']
            require('0' not in hist and all(1<=int(k)<n for k in hist),'invalid rejection histogram')
            require(sum(hist.values())==space['expected'],'unaccounted sign assignment')
            total+=space['expected']
        require(total==footer['total_assignments']==manifest['expected_sign_assignments'],'total count mismatch')
    if positive:
        from verify_independent import verify_pair
        for witness in positive:
            result=verify_pair(witness['A'],witness['B'],expected_n=n)
            require(result['aperiodic_golay'],'claimed direct witness failed independent integer convolution')
    report={**manifest,'status':'COMPLETE_INDEPENDENT_SIGN_REPLAY_NO_PAIR' if complete else footer['status'],
            'returncode':run.returncode,'wall_seconds_including_child_startup':time.monotonic()-start,
            'original_sign_rejections_replayed':complete,'footer':footer,
            'output_path':str(output_path.relative_to(ROOT)),'output_sha256':sha(output_path),
            'stdout':run.stdout,'stderr':run.stderr,'positive_witnesses':positive}
    save(report_path,report)
    print(json.dumps({k:report[k] for k in ('status','space_count','expected_sign_assignments','footer')}))
    return 0 if complete or positive else 1


if __name__=='__main__':
    raise SystemExit(main())
