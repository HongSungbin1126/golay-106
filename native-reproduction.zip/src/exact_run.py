"""Bounded, recorded execution wrapper for the exact quad solver."""
import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from verify_independent import verify_pair


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--n',type=int,required=True)
    p.add_argument('--seconds',type=float,required=True)
    p.add_argument('--q-start',type=int,default=0)
    p.add_argument('--q-limit',type=int,default=0)
    p.add_argument('--tag',default='run1')
    p.add_argument('--solver',default='exact_quad')
    p.add_argument('--orientations',action='store_true')
    a=p.parse_args()
    source=ROOT/'src'/f'{a.solver}.cpp'
    binary=ROOT/'src'/a.solver
    source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    command=[str(binary),'--n',str(a.n),'--seconds',str(a.seconds),
             '--q-start',str(a.q_start),'--q-limit',str(a.q_limit)]
    orientation_path=ROOT/f'results/exact_orientation_n{a.n}_{a.tag}.jsonl'
    if a.orientations:
        command += ['--orientation-output',str(orientation_path),'--source-sha256',source_hash]
    stderr_path=ROOT/f'results/exact_n{a.n}_{a.tag}.stderr.log'
    with stderr_path.open('w') as err:
        proc=subprocess.run(command,stdout=subprocess.PIPE,stderr=err,text=True,check=True)
    record=json.loads(proc.stdout)
    record['command']=command
    record['recorded_utc']=datetime.now(timezone.utc).isoformat()
    record['source_sha256']=source_hash
    record['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
    record['stderr']=stderr_path.read_text()
    record['stderr_path']=str(stderr_path)
    if a.orientations:
        record['orientation_path']=str(orientation_path)
        record['orientation_sha256']=hashlib.sha256(orientation_path.read_bytes()).hexdigest()
    if record['solver_report']=='SAT':
        record['independent_verification']=verify_pair(record['A'],record['B'],expected_n=a.n)
    path=ROOT/f'results/exact_n{a.n}_{a.tag}.json'
    path.write_text(json.dumps(record,indent=2))
    print(json.dumps(record|{'record_path':str(path)},indent=2))


if __name__=='__main__': main()
