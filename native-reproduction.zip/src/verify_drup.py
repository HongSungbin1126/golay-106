"""Small exact checker for textual DRUP proofs using reverse unit propagation.

Each addition C must make the checking CNF unit-inconsistent when all literals
of C are assumed false. In remove mode, deletions remove one active occurrence.
In retain mode, deletion hints are ignored and all previously RUP-proved clauses
are retained. Retaining proved consequences is sound for an RUP-only replay;
this does not assert strict conformance to the trace's deletion semantics.
Unsupported syntax, missing clauses in deletion hints, and non-RUP additions
are rejected. There is no RAT fallback or trust in a solver's UNSAT flag.

This checks propositional unsatisfiability of the supplied DIMACS formula only.
The mathematical encoding and its normalization must be audited separately.
"""

from __future__ import annotations

import argparse
from collections import defaultdict, deque
import hashlib
import json
from pathlib import Path
import resource
import time


class ProofRejected(ValueError):
    pass


class ProofBudgetExceeded(RuntimeError):
    pass


def canonical_clause(literals):
    if any(type(lit) is not int or lit == 0 for lit in literals):
        raise ProofRejected("clause contains a noninteger or zero literal")
    return tuple(sorted(set(literals), key=lambda lit: (abs(lit), lit)))


def parse_dimacs(data):
    header = None
    clauses, pending = [], []
    for number, line in enumerate(data.decode("ascii").splitlines(), 1):
        words = line.split()
        if not words or words[0] == "c":
            continue
        if words[0] == "p":
            if header is not None or pending or clauses or len(words) != 4 or words[1] != "cnf":
                raise ProofRejected(f"invalid DIMACS header at line {number}")
            try:
                header = int(words[2]), int(words[3])
            except ValueError as exc:
                raise ProofRejected("noninteger DIMACS header") from exc
            if min(header) < 0:
                raise ProofRejected("negative DIMACS size")
            continue
        if header is None:
            raise ProofRejected("clauses occur before the DIMACS header")
        try:
            literals = [int(word) for word in words]
        except ValueError as exc:
            raise ProofRejected(f"unsupported DIMACS token at line {number}") from exc
        for literal in literals:
            if literal == 0:
                clauses.append(canonical_clause(pending))
                pending = []
            else:
                if abs(literal) > header[0]:
                    raise ProofRejected("DIMACS literal exceeds declared variable count")
                pending.append(literal)
    if header is None or pending:
        raise ProofRejected("missing header or unterminated DIMACS clause")
    if len(clauses) != header[1]:
        raise ProofRejected("DIMACS clause count does not match header")
    return header[0], clauses


class ClauseDatabase:
    def __init__(self, clauses):
        self.clauses = []
        self.active = []
        self.occurrences = defaultdict(list)
        self.identical = defaultdict(list)
        self.units = []
        self.empties = []
        self.propagated_assignments = 0
        for clause in clauses:
            self.add(clause)

    def add(self, literals):
        clause = canonical_clause(literals)
        index = len(self.clauses)
        self.clauses.append(clause)
        self.active.append(True)
        self.identical[clause].append(index)
        for literal in clause:
            self.occurrences[literal].append(index)
        if len(clause) == 1:
            self.units.append(index)
        elif len(clause) == 0:
            self.empties.append(index)

    def delete(self, literals):
        clause = canonical_clause(literals)
        copies = self.identical.get(clause)
        if not copies:
            raise ProofRejected("deletion does not name an active clause")
        index = copies.pop()
        self.active[index] = False

    def unit_refutes(self, assumptions=()):
        if any(self.active[index] for index in self.empties):
            return True
        remaining = [len(clause) for clause in self.clauses]
        satisfied = bytearray(len(self.clauses))
        assignments = {}
        pending = deque(assumptions)
        pending.extend(self.clauses[index][0] for index in self.units if self.active[index])
        while pending:
            literal = pending.popleft()
            variable, value = abs(literal), literal > 0
            if variable in assignments:
                if assignments[variable] != value:
                    return True
                continue
            assignments[variable] = value
            self.propagated_assignments += 1
            for index in self.occurrences.get(literal, ()):
                if self.active[index]:
                    satisfied[index] = 1
            for index in self.occurrences.get(-literal, ()):
                if not self.active[index] or satisfied[index]:
                    continue
                remaining[index] -= 1
                if remaining[index] == 0:
                    return True
                if remaining[index] == 1:
                    for possible in self.clauses[index]:
                        if abs(possible) not in assignments:
                            pending.append(possible)
                            break
                    else:
                        # No true literal and no unassigned literal: conflict.
                        return True
        return False


def check(cnf_path, proof_path, cpu_seconds=240, deletions_mode="remove"):
    if deletions_mode not in {"remove", "retain"}:
        raise ProofRejected("unknown deletion mode")
    begin = time.process_time()
    raw_cnf, raw_proof = Path(cnf_path).read_bytes(), Path(proof_path).read_bytes()
    variables, clauses = parse_dimacs(raw_cnf)
    database = ClauseDatabase(clauses)
    initial_unit_conflict = database.unit_refutes()
    additions, deletions, max_width = 0, 0, 0
    empty_derived = False
    lines = raw_proof.decode("ascii").splitlines()
    for number, line in enumerate(lines, 1):
        if number % 100 == 1 and time.process_time()-begin > cpu_seconds:
            raise ProofBudgetExceeded(f"CPU budget at proof line {number}; no UNSAT conclusion")
        words = line.split()
        if not words or words[0] == "c":
            continue
        deletion = words[0] == "d"
        if deletion:
            words = words[1:]
        try:
            literals = [int(word) for word in words]
        except ValueError as exc:
            raise ProofRejected(f"unsupported proof syntax at line {number}") from exc
        if not literals or literals[-1] != 0 or 0 in literals[:-1]:
            raise ProofRejected(f"expected exactly one zero terminator at line {number}")
        clause = canonical_clause(literals[:-1])
        if deletion:
            try:
                if deletions_mode == "remove":
                    database.delete(clause)
                elif not database.identical.get(clause):
                    raise ProofRejected("deletion hint does not name an available clause")
            except ProofRejected as exc:
                raise ProofRejected(f"line {number}: {exc}") from exc
            deletions += 1
        else:
            if not database.unit_refutes([-literal for literal in clause]):
                raise ProofRejected(
                    f"addition at line {number} is not RUP; RAT or unsupported reasoning is not accepted"
                )
            database.add(clause)
            additions += 1
            max_width = max(max_width, len(clause))
            if not clause:
                empty_derived = True
    if not (empty_derived or initial_unit_conflict):
        raise ProofRejected("no checked empty clause and no initial unit contradiction")
    return {
        "checker": "text_rup_exact_unit_propagation_v2",
        "result": "PASS", "claim": "DIMACS_CNF_UNSAT_CERTIFIED",
        "deletions_mode": deletions_mode,
        "proof_semantics": (
            "strict deletion replay, every addition RUP"
            if deletions_mode == "remove" else
            "monotone RUP replay retaining all previously proved clauses; deletion hints parsed"
        ),
        "encoding_equivalence": "REQUIRES_SEPARATE_MATHEMATICAL_AUDIT",
        "cnf_path": str(cnf_path), "proof_path": str(proof_path),
        "cnf_sha256": hashlib.sha256(raw_cnf).hexdigest(),
        "proof_sha256": hashlib.sha256(raw_proof).hexdigest(),
        "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "declared_variables": variables, "input_clauses": len(clauses),
        "proof_lines": len(lines), "checked_additions": additions,
        "checked_deletions": deletions, "maximum_added_clause_width": max_width,
        "empty_clause_derived": empty_derived, "initial_unit_conflict": initial_unit_conflict,
        "propagated_assignments": database.propagated_assignments,
        "cpu_seconds": time.process_time()-begin,
        "formal_kernel": False,
        "trusted_base": ["Python exact integer/Boolean operations", "DIMACS parser", "unit propagation checker"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cnf", type=Path, required=True)
    parser.add_argument("--proof", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cpu-seconds", type=int, default=240)
    parser.add_argument("--deletions", choices=("remove", "retain"), default="remove")
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU, (args.cpu_seconds+5, args.cpu_seconds+6))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    wall = time.monotonic()
    exit_code = 0
    try:
        report = check(args.cnf, args.proof, args.cpu_seconds, args.deletions)
    except (ProofRejected, UnicodeError) as exc:
        report = {"result": "REJECTED", "reason": str(exc), "allowed_conclusion": "NO_CONCLUSION"}
        exit_code = 2
    except ProofBudgetExceeded as exc:
        report = {"result": "INCOMPLETE", "reason": str(exc), "allowed_conclusion": "NO_CONCLUSION"}
        exit_code = 3
    report.update({"date": "2026-11-05", "wall_seconds": time.monotonic()-wall,
                   "peak_memory_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024})
    args.output.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
