"""Exact finite experiments for Golay compression and dyadic root constraints.

This is not a solver for an open length.  All calculations use Python integers.
One process, RLIMIT_CPU=240 s, address-space limit=1 GiB.
"""
import argparse
from collections import Counter, defaultdict
import itertools
import json
from pathlib import Path
import resource
import time


def ac(a):
    return tuple(sum(a[i] * a[i+k] for i in range(len(a)-k))
                 for k in range(1, len(a)))


def pac(a):
    p = len(a)
    return tuple(sum(a[i] * a[(i+k) % p] for i in range(p))
                 for k in range(1, (p+1)//2))


def is_golay(a, b):
    return all(x+y == 0 for x, y in zip(ac(a), ac(b)))


def compressed_pair(a, b):
    p = len(a)//2
    return (tuple((a[j]+a[j+p])//2 for j in range(p)),
            tuple((b[j]+b[j+p])//2 for j in range(p)))


def all_binary_lifts(P, Q):
    """No symmetry or filtering: exactly two choices for each zero."""
    p = len(P)
    zeros = [(r, j) for r, c in enumerate((P, Q))
             for j, v in enumerate(c) if v == 0]
    for signs in itertools.product((-1, 1), repeat=len(zeros)):
        fronts = [list(P), list(Q)]
        for (r, j), v in zip(zeros, signs):
            fronts[r][j] = v
        a = fronts[0] + [2*P[j]-fronts[0][j] for j in range(p)]
        b = fronts[1] + [2*Q[j]-fronts[1][j] for j in range(p)]
        yield a, b


def mirror_ok(a, b):
    n = len(a)
    return all(a[j]*a[n-1-j] + b[j]*b[n-1-j] == 0
               for j in range(n//2))


def mirror_lift_prediction(P, Q):
    """The proposed exact count of MIRROR-consistent lifts, not Golay lifts."""
    p = len(P)
    assert p % 2 == 1 and len(Q) == p
    assert all(v in (-1, 0, 1) for v in P+Q)
    w = tuple(P[j]*P[j] + Q[j]*Q[j] for j in range(p))
    assert sum(w) == p
    if w[p//2] != 1:
        return {"count": 0, "reason": "center_support"}
    h00 = h22 = 0
    for j in range(p//2):
        r = p-1-j
        if w[j] % 2 != w[r] % 2:
            return {"count": 0, "reason": "support_parity"}
        if w[j] == w[r] == 0:
            h00 += 1
        if w[j] == w[r] == 2:
            h22 += 1
            if P[j]*P[r] + Q[j]*Q[r] != 0:
                return {"count": 0, "reason": "fixed_sign"}
    assert h00 == h22
    free = (p+1)//2 + h22
    return {"count": 1 << free, "reason": "passes", "h": h22,
            "free_bits": free}


def validate_mirror_formula_small(max_p=5):
    """All ternary compression data with total weight p, even nonperiodic."""
    checked = 0
    hist = Counter()
    for p in range(1, max_p+1, 2):
        for flat in itertools.product((-1, 0, 1), repeat=2*p):
            if sum(v*v for v in flat) != p:
                continue
            P, Q = flat[:p], flat[p:]
            prediction = mirror_lift_prediction(P, Q)
            observed = sum(mirror_ok(a, b) for a, b in all_binary_lifts(P, Q))
            assert observed == prediction["count"], (P, Q, prediction, observed)
            hist[(p, prediction["reason"])] += 1
            checked += 1
    return {"compression_candidates_checked": checked,
            "histogram": {str(k): v for k, v in sorted(hist.items())}}


def periodic_ternary_pairs(p, rowP, rowQ):
    """Generate ALL ordered compressed candidates with fixed row sums."""
    b_table = defaultdict(list)
    a_candidates = []
    counts = Counter()
    for seq in itertools.product((-1, 0, 1), repeat=p):
        row = sum(seq)
        if row not in (rowP, rowQ):
            continue
        weight = sum(v*v for v in seq)
        if weight > p:
            continue
        profile = pac(seq)
        if row == rowP:
            a_candidates.append((seq, weight, profile))
            counts["first_sequences"] += 1
        if row == rowQ:
            b_table[(weight, profile)].append(seq)
            counts["second_sequences"] += 1
    for P, weight, profile in a_candidates:
        key = (p-weight, tuple(-v for v in profile))
        for Q in b_table.get(key, ()):
            yield P, Q


def survey_small_compressions(p, rowP, rowQ, exhaustive_lifts=True):
    hist = Counter()
    free_hist = Counter()
    examples = {}
    first_failed_lift = None
    for P, Q in periodic_ternary_pairs(p, rowP, rowQ):
        hist["periodic_compressed_pairs"] += 1
        pred = mirror_lift_prediction(P, Q)
        hist[pred["reason"]] += 1
        if pred["count"]:
            free_hist[pred["free_bits"]] += 1
        examples.setdefault(pred["reason"], {"P": P, "Q": Q})
        if not exhaustive_lifts:
            continue
        mirror_count = golay_count = 0
        first_golay = None
        for a, b in all_binary_lifts(P, Q):
            mo = mirror_ok(a, b)
            mirror_count += mo
            go = is_golay(a, b)
            assert not go or mo
            golay_count += go
            if go and first_golay is None:
                first_golay = {"A": a, "B": b}
        assert mirror_count == pred["count"]
        hist["all_golay_lifts"] += golay_count
        hist["compressed_pairs_with_golay_lift"] += int(golay_count > 0)
        if pred["count"] and not golay_count and first_failed_lift is None:
            first_failed_lift = {"P": P, "Q": Q,
                                 "mirror_lifts": pred["count"],
                                 "exact_golay_lifts": 0}
    return {"p": p, "rows": [rowP, rowQ], "counts": dict(hist),
            "mirror_free_bits_histogram": dict(free_hist),
            "examples": examples,
            "counterexample_to_mirror_periodic_sufficiency": first_failed_lift,
            "all_lifts_checked": exhaustive_lifts}


def q4_branches_106():
    opts = [x for x in range(-13, 14) if x % 4 == 1]
    last = [x for x in range(-13, 14) if x % 4 == 3]
    out = []
    for x, y, u, v in itertools.product(opts, opts, opts, last):
        if x*x+y*y+u*u+v*v != 212:
            continue
        a = ((9+x)//2, (5+y)//2, (9-x)//2, (5-y)//2)
        b = ((9+u)//2, (-5+v)//2, (9-u)//2, (-5-v)//2)
        out.append({"differences": (x, y, u, v),
                    "residue_sums_A": a, "residue_sums_B": b})
    return out


def q8_row_profiles(q4_sums):
    sizes = (14, 14, 13, 13, 13, 13, 13, 13)
    opts = []
    for j, r in enumerate(q4_sums):
        col = []
        for d in range(-14, 15):
            if (r+d) % 2:
                continue
            s, t = (r+d)//2, (r-d)//2
            if (abs(s) <= sizes[j] and abs(t) <= sizes[j+4]
                    and s % 2 == sizes[j] % 2
                    and t % 2 == sizes[j+4] % 2):
                col.append(d)
        opts.append(col)
    for d in itertools.product(*opts):
        energy = sum(x*x for x in d)
        if energy > 212:
            continue
        cross = d[0]*(d[1]-d[3]) + d[2]*(d[1]+d[3])
        yield energy, cross, d


def root_norm_reduced(coeffs):
    """Exact Laurent norm modulo z^h+1, h=len(coeffs)."""
    h = len(coeffs)
    result = [0]*h
    for i, x in enumerate(coeffs):
        for j, y in enumerate(coeffs):
            r = (i-j) % (2*h)
            result[r % h] += x*y*(1 if r < h else -1)
    return result


def dyadic_survey_106():
    branches = q4_branches_106()
    assert len(branches) == 54
    orbits = {min(d, (d[2], -d[3], d[0], -d[1]))
              for d in (r["differences"] for r in branches)}
    assert len(orbits) == 28
    total_q8 = total_energy_only = 0
    all_profiles = []
    for branch in branches:
        A = list(q8_row_profiles(branch["residue_sums_A"]))
        B = list(q8_row_profiles(branch["residue_sums_B"]))
        table = defaultdict(list)
        energy_hist = Counter()
        for e, c, d in B:
            table[e, c].append(d)
            energy_hist[e] += 1
        count = energy_only = 0
        for e, c, da in A:
            energy_only += energy_hist[212-e]
            for db in table[212-e, -c]:
                # Independent exact cyclotomic polynomial calculation.
                na, nb = root_norm_reduced(da), root_norm_reduced(db)
                assert [x+y for x, y in zip(na, nb)] == [212, 0, 0, 0]
                a = [(r+d)//2 for r, d in zip(branch["residue_sums_A"], da)]
                a += [(r-d)//2 for r, d in zip(branch["residue_sums_A"], da)]
                b = [(r+d)//2 for r, d in zip(branch["residue_sums_B"], db)]
                b += [(r-d)//2 for r, d in zip(branch["residue_sums_B"], db)]
                all_profiles.append((a, b))
                count += 1
        branch["q8_lifts"] = count
        branch["energy_only_q8_lifts"] = energy_only
        total_q8 += count
        total_energy_only += energy_only
    return ({"q4_ordered_branches": len(branches), "q4_residual_symmetry_orbits": len(orbits),
             "q8_joint_residue_profiles": total_q8,
             "q8_energy_only_residue_profiles": total_energy_only,
             "q4_branches": branches}, all_profiles)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--small-max-p", type=int, default=5)
    parser.add_argument("--periodic-p13", action="store_true")
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU, (240, 250))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    start_cpu, start_wall = time.process_time(), time.monotonic()
    result = {"claim_scope": "exact necessary constraints and finite validation; no open length solved"}
    result["mirror_formula_exhaustive_check"] = validate_mirror_formula_small(args.small_max_p)
    result["p5_compression_survey"] = survey_small_compressions(5, 2, 1)
    result["p9_compression_survey"] = survey_small_compressions(9, 3, 0)
    if args.periodic_p13:
        result["p13_compression_survey"] = survey_small_compressions(13, 3, 2, False)
    result["n106_dyadic"], profiles = dyadic_survey_106()
    # Small exact table for reuse; one candidate's 16 signed residue sums per line.
    table_path = args.output.with_name("algebra_n106_q8_residue_profiles.jsonl")
    with table_path.open("w") as out:
        for a, b in profiles:
            out.write(json.dumps({"A": a, "B": b}, separators=(",", ":")) + "\n")
    result["q8_profile_table"] = str(table_path)
    result["cpu_seconds"] = time.process_time()-start_cpu
    result["wall_seconds"] = time.monotonic()-start_wall
    result["peak_rss_kib"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"status": "PASS", "output": str(args.output),
                      "cpu_seconds": result["cpu_seconds"],
                      "q8_profiles": len(profiles),
                      "mirror_candidates": result["mirror_formula_exhaustive_check"]["compression_candidates_checked"]}))


if __name__ == "__main__":
    main()
