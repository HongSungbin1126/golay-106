// Independent exhaustive rejection of already certified affine sign spaces.
// No search-code includes, no Gray traversal, no row-norm prefilter, and no
// population-count representation of the original correlation equations.
// The separate Python auditor must certify that these spaces cover precisely
// the necessary second-parity systems of ALL first-parity orientations.
#include <array>
#include <chrono>
#include <cstdint>
#include <ctime>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using Bits = std::uint64_t;
struct Space { Bits q,t,base; std::vector<Bits> basis; };

static bool original_golay(const std::array<int,126>& a,
                           const std::array<int,126>& b,unsigned n,
                           unsigned& rejecting_lag) {
    for (unsigned k=1;k<n;++k) {
        int residual=0;
        for (unsigned i=0;i<n-k;++i)
            residual += a[i]*a[i+k] + b[i]*b[i+k];
        if (residual) {rejecting_lag=k;return false;}
    }
    rejecting_lag=0;
    return true;
}

int main(int argc,char** argv) {
    if (argc!=4) {std::cerr<<"usage: verify_signs_direct INPUT OUTPUT CPU_SECONDS\n";return 2;}
    try {
        const double allowance=std::stod(argv[3]);
        if (!(allowance>0)) throw std::runtime_error("invalid budget");
        std::ifstream input(argv[1]);
        unsigned n;std::size_t count;
        if (!(input>>n>>count) || n<2 || n>126 || (n&1))
            throw std::runtime_error("invalid sign-space header");
        const unsigned p=n/2;
        std::vector<Space> spaces;
        for (std::size_t r=0;r<count;++r) {
            Space s;unsigned d;
            if (!(input>>s.q>>s.t>>s.base>>d) || d>=63 || d>p-1)
                throw std::runtime_error("invalid sign-space row");
            s.basis.resize(d);
            for (Bits& v:s.basis)if (!(input>>v))throw std::runtime_error("truncated basis");
            if (((s.q|s.t|s.base)&1) || (s.q>>p) || (s.t>>p) || (s.base>>p))
                throw std::runtime_error("invalid MODE P space");
            for (Bits v:s.basis)if ((v&1)||(v>>p))throw std::runtime_error("invalid basis direction");
            spaces.push_back(std::move(s));
        }
        std::string trailing;
        if (input>>trailing)throw std::runtime_error("unexpected trailing input");
        std::ofstream out(argv[2]);
        if (!out)throw std::runtime_error("cannot create output");
        out<<"{\"record_type\":\"header\",\"format\":\"direct_signed_correlation_replay_v1\",\"n\":"<<n
           <<",\"spaces\":"<<spaces.size()<<"}\n";
        const auto wall_start=std::chrono::steady_clock::now();
        const std::clock_t cpu_start=std::clock();
        std::uint64_t total=0;
        bool timed_out=false,found=false;
        std::size_t completed_spaces=0;
        for (std::size_t r=0;r<spaces.size();++r) {
            const Space& s=spaces[r];
            const Bits size=Bits(1)<<s.basis.size();
            Bits examined=0;
            std::array<Bits,126> reject_counts{};
            for (Bits index=0;index<size;++index) {
                if (!(index&4095) && double(std::clock()-cpu_start)/CLOCKS_PER_SEC>=allowance) {
                    timed_out=true;break;
                }
                Bits u=s.base;
                // Ordinary binary enumeration: this intentionally does not
                // depend on the search program's Gray code or ctz updates.
                for (unsigned j=0;j<s.basis.size();++j)
                    if ((index>>j)&1)u^=s.basis[j];
                std::array<int,126> a{},b{};
                for (unsigned i=0;i<p;++i) {
                    a[i]=((u>>i)&1)?-1:1;
                    b[i]=(((u^s.q)>>i)&1)?-1:1;
                    a[n-1-i]=(((u^s.t)>>i)&1)?-1:1;
                    b[n-1-i]=(((u^s.q^s.t)>>i)&1)?1:-1;
                }
                unsigned reject;
                bool valid=original_golay(a,b,n,reject);
                ++examined;++total;++reject_counts[reject];
                if (valid) {
                    found=true;
                    out<<"{\"record_type\":\"witness\",\"space_index\":"<<r<<",\"binary_index\":"<<index<<",\"A\":[";
                    for (unsigned i=0;i<n;++i){if(i)out<<",";out<<a[i];}
                    out<<"],\"B\":[";
                    for (unsigned i=0;i<n;++i){if(i)out<<",";out<<b[i];}
                    out<<"]}\n";
                    break;
                }
            }
            const bool done=examined==size;
            if (done)++completed_spaces;
            out<<"{\"record_type\":\"space\",\"index\":"<<r<<",\"q_bits_mask\":"<<s.q
               <<",\"t_bits_mask\":"<<s.t<<",\"nullity\":"<<s.basis.size()
               <<",\"expected_assignments\":"<<size<<",\"examined_assignments\":"<<examined
               <<",\"complete\":"<<(done?"true":"false")<<",\"first_rejection_lag_histogram\":{";
            bool first=true;
            for (unsigned k=0;k<n;++k)if(reject_counts[k]){
                if(!first)out<<",";
                first=false;
                out<<"\""<<k<<"\":"<<reject_counts[k];
            }
            out<<"}}\n";
            out.flush();if(!out)throw std::runtime_error("output write failed");
            if (timed_out||found)break;
        }
        std::string status=found?"ORIGINAL_PAIR_FOUND":timed_out?"TIMEOUT":"COMPLETE_SUPPLIED_SPACES_NO_PAIR";
        double cpu=double(std::clock()-cpu_start)/CLOCKS_PER_SEC;
        out<<"{\"record_type\":\"footer\",\"status\":\""<<status<<"\",\"completed_spaces\":"<<completed_spaces
           <<",\"total_assignments\":"<<total<<",\"cpu_seconds\":"<<cpu
           <<",\"wall_seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-wall_start).count()<<"}\n";
        out.close();if(!out)throw std::runtime_error("output close failed");
        std::cout<<"{\"status\":\""<<status<<"\",\"completed_spaces\":"<<completed_spaces
                 <<",\"assignments\":"<<total<<",\"cpu_seconds\":"<<cpu<<"}\n";
        return timed_out?1:0;
    } catch(const std::exception& error) {
        std::cerr<<error.what()<<"\n";return 2;
    }
}
