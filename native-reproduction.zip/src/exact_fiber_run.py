"""Record a bounded native folded-orientation run, with immutable input hashes."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import subprocess
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def atomic_install(raw,path):
    with tempfile.NamedTemporaryFile(dir=path.parent,prefix=path.name+'.install_',delete=False) as f:
        stage=Path(f.name)
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    os.replace(stage,path)
    assert hashlib.sha256(raw).hexdigest()==digest(path)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--p', type=int, required=True)
    p.add_argument('--seconds', type=float, default=60)
    p.add_argument('--h-start', type=int, default=0)
    p.add_argument('--h-limit', type=int, default=0)
    p.add_argument('--tag', default='run1')
    p.add_argument('--solver', default='exact_orientation_fibers')
    p.add_argument('--compare-jsonl', type=Path)
    a = p.parse_args()
    source = ROOT/f'src/{a.solver}.cpp'
    binary = ROOT/f'src/{a.solver}'
    stem = ROOT/f'results/exact_fibers_n{2*a.p}_{a.tag}'
    output, orientations, stderr = (stem.with_suffix(x) for x in ('.json', '.jsonl', '.stderr.log'))
    manifest=stem.with_suffix('.manifest.json')
    if any(path.exists() for path in (output,orientations,stderr,manifest)):
        raise FileExistsError('result tag already exists; use a new tag')
    def limits():
        resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
        resource.setrlimit(resource.RLIMIT_CPU, (math.ceil(a.seconds)+3, math.ceil(a.seconds)+5))
    with tempfile.TemporaryDirectory(prefix='golay_exact_fiber_') as scratch:
        scratch=Path(scratch)
        local_output,local_orientations,local_stderr=(scratch/name for name in ('report.json','orientations.jsonl','stderr.log'))
        command = [str(binary),'--p',str(a.p),'--seconds',str(a.seconds),
                   '--h-start',str(a.h_start),'--h-limit',str(a.h_limit),
                   '--output',str(local_output),'--orientations',str(local_orientations),
                   '--source-sha256',digest(source)]
        provenance = {'source_sha256':digest(source), 'binary_sha256':digest(binary),
                      'wrapper_sha256':digest(Path(__file__)), 'command':command,
                      'started_utc':datetime.now(timezone.utc).isoformat(),
                      'cpu_soft_limit_seconds':math.ceil(a.seconds)+3,
                      'cpu_hard_limit_seconds':math.ceil(a.seconds)+5,
                      'address_space_limit_bytes':1024**3,'private_temporary_outputs':True}
        atomic_install((json.dumps(provenance,indent=2)+'\n').encode(),manifest)
        with local_stderr.open('w') as err:
            result = subprocess.run(command,stdout=subprocess.PIPE,stderr=err,
                                    text=True,preexec_fn=limits)
        atomic_install(local_stderr.read_bytes(),stderr)
        if local_orientations.exists():
            atomic_install(local_orientations.read_bytes(),orientations)
        if result.returncode!=0 or not local_output.exists():
            record=dict(provenance,status='EXECUTION_FAILED',returncode=result.returncode,
                        stdout=result.stdout,stderr_path=str(stderr))
            atomic_install((json.dumps(record,indent=2)+'\n').encode(),output)
            raise RuntimeError(f'native fiber process failed with return code {result.returncode}')
        atomic_install(local_output.read_bytes(),output)
        record=json.loads(local_output.read_text())
        raw=local_orientations.read_text()
        assert raw.endswith('\n')
        parsed=[json.loads(line) for line in raw.splitlines()]
        assert len(parsed)>=2 and parsed[0].get('record_type')=='header' and parsed[-1].get('record_type')=='footer'
        assert parsed[0]['source_sha256']==provenance['source_sha256'] and parsed[0]['n']==2*a.p
        assert parsed[0]['h_start']==record['h_start']==a.h_start
        assert parsed[0]['h_end_exclusive']==record['h_end_exclusive']
        assert parsed[-1]['H_completed']==record['H_completed'] and parsed[-1]['status']==record['status']
        assert all(r.get('record_type')=='orientation' and r['n']==2*a.p and
                   a.h_start<=r['h']<a.h_start+record['H_completed'] for r in parsed[1:-1])
        if record['status'].startswith('COMPLETE_'):
            assert len(parsed)-2==record['statistics'].get('solutions',0)
        record.update(provenance,recorded_utc=datetime.now(timezone.utc).isoformat(),
                      manifest_path=str(manifest),committed_orientation_records=len(parsed)-2,
                      orientation_path=str(orientations),orientation_sha256=digest(orientations),
                      stderr_path=str(stderr))
    if a.compare_jsonl:
        def pairs(path):
            return sorted((r['q_bits_mask'],r['t_bits_mask'])
                          for r in (json.loads(x) for x in path.read_text().splitlines())
                          if r.get('record_type')=='orientation')
        expected, actual = pairs(a.compare_jsonl), pairs(orientations)
        assert record['status']=='COMPLETE_H_DOMAIN'
        assert expected == actual, (len(expected),len(actual))
        record['comparison']={'result':'PASS','complete_orientation_count':len(actual),
                              'reference':str(a.compare_jsonl),'reference_sha256':digest(a.compare_jsonl)}
    atomic_install((json.dumps(record,indent=2)+'\n').encode(),output)
    print(json.dumps({key:record[key] for key in ('status','n','H_completed','statistics','cpu_seconds')},indent=2))

if __name__=='__main__':
    main()
