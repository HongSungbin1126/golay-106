"""Check only the eight reduced d20 assignments, with exact original correlations."""
import hashlib
import itertools
import json
from pathlib import Path
import time


def reconstruct(q, t, signs, n=106):
    A, B = [0]*n, [0]*n
    for i in range(n//2):
        s = 1-2*((signs >> i) & 1)
        qs = 1-2*((q >> i) & 1)
        ts = 1-2*((t >> i) & 1)
        A[i], B[i] = s, s*qs
        A[n-1-i], B[n-1-i] = ts*s, -ts*s*qs
    return A, B


def direct_residuals(A, B):
    n = len(A)
    return [sum(A[i]*A[i+k]+B[i]*B[i+k] for i in range(n-k))
            for k in range(1, n)]


def convolution_residuals(A, B):
    n = len(A)
    coeffs = [0]*(2*n-1)
    for row in (A, B):
        backward = row[::-1]
        for i, a in enumerate(row):
            for j, b in enumerate(backward):
                coeffs[i+j] += a*b
    assert coeffs[n-1] == 2*n
    assert coeffs == coeffs[::-1]
    return coeffs[n:]


def standard_canonical(A, B):
    candidates = []
    n = len(A)
    for ra, rb, na, nb, swap, alt in itertools.product((0, 1), repeat=6):
        a, b = (A[::-1] if ra else A), (B[::-1] if rb else B)
        a = [x*((-1)**(na+(i*alt))) for i, x in enumerate(a)]
        b = [x*((-1)**(nb+(i*alt))) for i, x in enumerate(b)]
        if swap:
            a, b = b, a
        candidates.append(tuple(a+b))
    return min(candidates)


def main():
    start = time.process_time()
    source = Path('results/algebra_sign_character_reductions.json')
    data = json.loads(source.read_text())
    rows = [x for x in data['spaces'] if x['initial_dimension'] == 20]
    assert len(rows) == 2
    results = []
    reversal_orbits, standard_orbits = {}, {}
    for row in rows:
        final = row['stages'][-1]
        particular, kernel = final['sign_particular_bits_mask'], final['sign_kernel_masks']
        assert len(kernel) == 2
        for assignment in range(4):
            signbits = particular
            for j, mask in enumerate(kernel):
                if (assignment >> j) & 1:
                    signbits ^= mask
            A, B = reconstruct(row['q_bits_mask'], row['t_bits_mask'], signbits)
            residuals = direct_residuals(A, B)
            assert residuals == convolution_residuals(A, B)
            revkey = min(tuple(A+B), tuple(A[::-1]+B))
            stdkey = standard_canonical(A, B)
            reversal_orbits.setdefault(revkey, []).append(len(results))
            standard_orbits.setdefault(stdkey, []).append(len(results))
            results.append({
                'q_bits_mask': row['q_bits_mask'], 't_bits_mask': row['t_bits_mask'],
                'sign_bits_mask': signbits, 'reduced_assignment': assignment,
                'A': A, 'B': B, 'original_combined_aperiodic_residuals': residuals,
                'all_zero_mod32': all(r % 32 == 0 for r in residuals),
                'all_zero_mod64': all(r % 64 == 0 for r in residuals),
                'combined_sidelobe_energy': sum(r*r for r in residuals),
                'maximum_absolute_residual': max(map(abs, residuals)),
                'nonzero_lags': [i+1 for i, r in enumerate(residuals) if r],
                'standard_canonical_sha256': hashlib.sha256(bytes(1 if x == 1 else 0 for x in stdkey)).hexdigest(),
            })
    out = {
        'status': 'PASS', 'scope': 'exactly eight specified assignments; no search or global energy optimum',
        'source_certificate_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'energy_definition': 'sum_{k=1}^{105} (C_A(k)+C_B(k))^2',
        'rows': results,
        'A_reversal_orbits': list(reversal_orbits.values()),
        'standard_symmetry_orbits': list(standard_orbits.values()),
        'all_eight_zero_mod32': all(r['all_zero_mod32'] for r in results),
        'all_eight_fail_mod64': all(not r['all_zero_mod64'] for r in results),
        'cpu_seconds': time.process_time()-start,
    }
    Path('results/algebra_mod32_witnesses.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({
        'status': out['status'], 'all_eight_zero_mod32': out['all_eight_zero_mod32'],
        'all_eight_fail_mod64': out['all_eight_fail_mod64'],
        'energies': sorted(set(r['combined_sidelobe_energy'] for r in results)),
        'max_residuals': sorted(set(r['maximum_absolute_residual'] for r in results)),
        'A_reversal_orbits': out['A_reversal_orbits'],
        'standard_symmetry_orbits': out['standard_symmetry_orbits'],
        'cpu_seconds': out['cpu_seconds'],
    }, indent=2))


if __name__ == '__main__':
    main()
