"""Exact independent acceptance checker for ordinary binary aperiodic pairs.

The acceptance computation is integer polynomial convolution, not a lag loop,
FFT, periodic convolution, or an import of a searcher's scoring code.  With
N = n - 1, multiply A(z) by z**N A(z**-1), and likewise for B.  The original
Golay equations hold precisely when their sum equals 2*n*z**N coefficientwise.

Arithmetic diagnostics are necessary conditions only and never replace the
full coefficient test.  The checker certifies a supplied pair, not novelty or
nonexistence.  Python's arbitrary precision integers are used throughout.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


CHECKER_VERSION = "integer-convolution-v1"


def _signs(values: Any, name: str) -> list[int]:
    if not isinstance(values, (list, tuple)) or not values:
        raise ValueError(f"{name} must be a nonempty list or tuple")
    out = []
    for value in values:
        if type(value) is not int or value not in {-1, 1}:
            raise ValueError(f"{name} coefficients must be exact integers +1 or -1")
        out.append(value)
    return out


def polynomial_product(left: list[int], right: list[int]) -> list[int]:
    """Schoolbook coefficient convolution over Z, without periodic wraparound."""
    if not left or not right:
        return []
    coefficients = [0] * (len(left) + len(right) - 1)
    for degree_left, coefficient_left in enumerate(left):
        for degree_right, coefficient_right in enumerate(right):
            coefficients[degree_left + degree_right] += (
                coefficient_left * coefficient_right
            )
    return coefficients


def known_length_witness(n: int) -> dict[str, int] | None:
    """Construct a,b,c with n=2**a*10**b*26**c, independently of factor test.

    This direct bounded generator intentionally does not use the bootstrap's
    prime-exponent criterion.  An absent witness certifies n outside this set,
    not the absence of a Golay pair at n.
    """
    if type(n) is not int or n < 1:
        return None
    power_26, c = 1, 0
    while power_26 <= n:
        power_10, b = 1, 0
        while power_26 * power_10 <= n:
            denominator = power_26 * power_10
            quotient, remainder = divmod(n, denominator)
            if remainder == 0 and quotient & (quotient - 1) == 0:
                return {"a": quotient.bit_length() - 1, "b": b, "c": c}
            power_10 *= 10
            b += 1
        power_26 *= 26
        c += 1
    return None


def verify_pair(a: Any, b: Any, expected_n: int | None = None) -> dict[str, Any]:
    a, b = _signs(a, "A"), _signs(b, "B")
    n = len(a)
    if len(b) != n:
        raise ValueError("A and B must have the same positive length")
    if expected_n is not None and (
        type(expected_n) is not int or expected_n != n
    ):
        raise ValueError("n must be an exact integer equal to both sequence lengths")

    pa = polynomial_product(a, list(reversed(a)))
    pb = polynomial_product(b, list(reversed(b)))
    combined = [u + v for u, v in zip(pa, pb)]
    target = [0] * (2 * n - 1)
    target[n - 1] = 2 * n
    failures = [
        {"laurent_exponent": i - (n - 1), "actual": value, "expected": target[i]}
        for i, value in enumerate(combined)
        if value != target[i]
    ]
    valid = not failures
    residuals = combined[n:]
    # The positive exponents correspond to the positive-lag equations.  All
    # positive and negative exponents and the central coefficient are accepted
    # only via combined == target, not by trusting this derived residual list.
    witness = known_length_witness(n)
    normalized_record = {"n": n, "A": a, "B": b}
    serialized = json.dumps(
        normalized_record, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    row_sums = [sum(a), sum(b)]
    even_sums = [sum(a[::2]), sum(b[::2])]
    odd_sums = [sum(a[1::2]), sum(b[1::2])]
    alternating_sums = [u - v for u, v in zip(even_sums, odd_sums)]
    mirror_residuals = (
        [a[i] * a[n - 1 - i] + b[i] * b[n - 1 - i] for i in range(n // 2)]
        if n % 2 == 0 else None
    )
    mode_r106 = None
    if n == 106:
        mode_r106 = (
            even_sums == [9, 9] and odd_sums == [5, -5]
        )
    return {
        "checker": CHECKER_VERSION,
        "n": n,
        "aperiodic_golay": valid,
        "energy": sum(value * value for value in residuals),
        "residuals": residuals,
        "combined_polynomial_coefficients": combined,
        "failed_coefficients": failures,
        "in_known_length_semigroup": witness is not None,
        "known_length_witness": witness,
        "target_conjecture_counterexample": valid and witness is None,
        "candidate_sha256": hashlib.sha256(serialized).hexdigest(),
        "diagnostics": {
            "row_sums": row_sums,
            "alternating_sums": alternating_sums,
            "even_index_sums": even_sums,
            "odd_index_sums": odd_sums,
            "row_sum_squares_equal_2n": sum(v * v for v in row_sums) == 2 * n,
            "alternating_sum_squares_equal_2n": (
                sum(v * v for v in alternating_sums) == 2 * n
            ),
            "mirror_residuals_even_n": mirror_residuals,
            "mirror_constraint_holds_even_n": (
                all(v == 0 for v in mirror_residuals)
                if mirror_residuals is not None else None
            ),
            "mode_r106_block_sums": mode_r106,
        },
        "claim_scope": (
            "Exact validity of the supplied ordinary binary aperiodic pair; "
            "no novelty claim and no nonexistence or universal conclusion."
        ),
    }


def _unique_json_object(items: list[tuple[str, Any]]) -> dict[str, Any]:
    obj = {}
    for key, value in items:
        if key in obj:
            raise ValueError(f"duplicate JSON key: {key}")
        obj[key] = value
    return obj


def load_candidate(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_unique_json_object)
    if not isinstance(obj, dict) or not {"n", "A", "B"}.issubset(obj):
        raise ValueError("candidate must be an object containing n, A and B")
    if type(obj["n"]) is not int or obj["n"] < 1:
        raise ValueError("n must be a positive exact integer")
    return obj


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    obj = load_candidate(args.candidate)
    result = verify_pair(obj["A"], obj["B"], expected_n=obj["n"])
    result["source_path"] = str(args.candidate.resolve())
    result["source_file_sha256"] = hashlib.sha256(args.candidate.read_bytes()).hexdigest()
    result["checker_file_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output is not None:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    # A well-formed near-pair is a valid measurement but not a Golay certificate.
    return 0 if result["aperiodic_golay"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
