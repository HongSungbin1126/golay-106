"""Exact, dependency-free bootstrap for the binary APERIODIC Golay project.
This is a validator/calibration program, not a solver for the open conjecture.
"""
import argparse
import hashlib
import itertools
import json
import random
from pathlib import Path


def validate_pair(a, b):
    if not isinstance(a, (list, tuple)) or not isinstance(b, (list, tuple)):
        raise ValueError("A and B must be lists or tuples")
    if not a or len(a) != len(b):
        raise ValueError("nonempty equal lengths required")
    if any(type(v) is not int or v not in (-1, 1) for v in (*a, *b)):
        raise ValueError("entries must be exact Python integers -1 or +1")


def ac(a):
    n = len(a)
    return [sum(a[i] * a[i+k] for i in range(n-k))
            for k in range(1, n)]


def residuals_direct(a, b):
    validate_pair(a, b)
    return [x+y for x, y in zip(ac(a), ac(b))]


def residuals_bitcount(a, b):
    validate_pair(a, b)
    n = len(a)
    ma = sum((v == -1) << i for i, v in enumerate(a))
    mb = sum((v == -1) << i for i, v in enumerate(b))
    out = []
    for k in range(1, n):
        mask = (1 << (n-k)) - 1
        changes = (((ma ^ (ma >> k)) & mask).bit_count()
                   + ((mb ^ (mb >> k)) & mask).bit_count())
        out.append(2*(n-k) - 2*changes)
    return out


def known_length(n):
    if type(n) is not int or n < 1:
        return False
    rem = n
    exponents = []
    for p in (2, 5, 13):
        v = 0
        while rem % p == 0:
            rem //= p
            v += 1
        exponents.append(v)
    return rem == 1 and exponents[0] >= exponents[1] + exponents[2]


def verify(a, b):
    r = residuals_direct(a, b)
    r2 = residuals_bitcount(a, b)
    if r != r2:
        raise ArithmeticError("independent correlation implementations disagree")
    n = len(a)
    valid = all(v == 0 for v in r)
    record = {"n": n, "A": list(a), "B": list(b)}
    encoded = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    return {
        "n": n,
        "aperiodic_golay": valid,
        "energy": sum(v*v for v in r),
        "residuals": r,
        "in_known_length_semigroup": known_length(n),
        "target_conjecture_counterexample": valid and not known_length(n),
        "candidate_sha256": hashlib.sha256(encoded).hexdigest()
    }


def periodic_residuals(a, b):
    validate_pair(a, b)
    n = len(a)
    return [sum(a[i]*a[(i+k) % n] + b[i]*b[(i+k) % n]
                for i in range(n)) for k in range(1, n)]


def double_pair(a, b):
    validate_pair(a, b)
    return list(a) + list(b), list(a) + [-v for v in b]


def multiply_pairs(a, b, c, d):
    """A convenient exact convention for standard Golay multiplication."""
    validate_pair(a, b)
    validate_pair(c, d)
    s = [(x+y)//2 for x, y in zip(c, d)]
    t = [(x-y)//2 for x, y in zip(c, d)]
    m = len(a)
    e = [a[j]*s[r] + b[j]*t[r] for j in range(m) for r in range(len(c))]
    f = [-b[m-1-j]*s[r] + a[m-1-j]*t[r]
         for j in range(m) for r in range(len(c))]
    return e, f


def brute_profile_exists(n):
    """Complete existence test after the sound normalization a[0]=b[0]=+1.
    Stores one sequence per complete APERIODIC correlation vector.
    Restrict to small n; this remains exponential.
    """
    profiles = {}
    for tail in itertools.product((-1, 1), repeat=n-1):
        a = (1,) + tail
        ca = tuple(ac(a))
        b = profiles.get(tuple(-v for v in ca))
        if b is not None:
            return list(a), list(b)
        # Pairing a sequence with itself is legal; needed at n=1.
        if all(v == 0 for v in ca):
            return list(a), list(a)
        profiles.setdefault(ca, a)
    return None


SEEDS = {
    1: ([1], [1]),
    2: ([1, 1], [1, -1]),
    10: (
        [1, 1, -1, 1, -1, 1, -1, -1, 1, 1],
        [1, 1, -1, 1, 1, 1, 1, 1, -1, -1]
    ),
    26: (
        [1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, 1, -1,
         1, -1, -1, 1, -1, 1, 1, 1, -1, -1, 1, 1, 1],
        [1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, 1, 1,
         1, 1, 1, -1, 1, -1, -1, -1, 1, 1, -1, -1, -1]
    )
}


def self_test():
    checks = 0
    for n, (a, b) in SEEDS.items():
        assert len(a) == len(b) == n
        assert verify(a, b)["aperiodic_golay"]
        checks += 1
        variants = [
            (b, a), ([-v for v in a], b), (a, [-v for v in b]),
            (a[::-1], b), (a, b[::-1]),
            ([(-1)**i*v for i, v in enumerate(a)],
             [(-1)**i*v for i, v in enumerate(b)])
        ]
        for aa, bb in variants:
            assert verify(aa, bb)["aperiodic_golay"]
            checks += 1

    generated = {}
    for m in (1, 2, 10, 26):
        for n in (1, 2, 10, 26):
            a, b = multiply_pairs(*SEEDS[m], *SEEDS[n])
            assert len(a) == m*n
            assert verify(a, b)["aperiodic_golay"]
            generated[m*n] = True
            checks += 1

    # A periodic pair that must FAIL the target aperiodic checker.
    a = [1, 1, 1, -1]
    b = [1, 1, -1, 1]
    assert verify(a, b)["aperiodic_golay"]
    shifted_b = b[-1:] + b[:-1]
    assert periodic_residuals(a, shifted_b) == [0, 0, 0]
    assert not verify(a, shifted_b)["aperiodic_golay"]
    checks += 3

    expected = {1, 2, 4, 8, 10}
    found = []
    for n in range(1, 13):
        pair = brute_profile_exists(n)
        assert (pair is not None) == (n in expected)
        if pair is not None:
            assert verify(*pair)["aperiodic_golay"]
            found.append(n)
        checks += 1

    rng = random.Random(20261105)
    for n in range(2, 33):
        for _ in range(20):
            a = [rng.choice((-1, 1)) for _ in range(n)]
            b = [rng.choice((-1, 1)) for _ in range(n)]
            r = residuals_direct(a, b)
            assert r == residuals_bitcount(a, b)
            assert sum(v*v for v in r) % 4 == 0
            p = periodic_residuals(a, b)
            assert p == [r[k-1] + r[n-k-1] for k in range(1, n)]
            checks += 3

    for bad in ([True, 1], [1.0, 1], [1, 0], [1, 1j]):
        try:
            verify(bad, [1, -1])
        except ValueError:
            pass
        else:
            raise AssertionError("invalid alphabet/type accepted")
        checks += 1

    for n in (106, 116, 122, 130, 136):
        assert not known_length(n)
        checks += 1
    for n in (1, 2, 10, 20, 26, 52, 100, 104, 260, 676):
        assert known_length(n)
        checks += 1

    row_pairs = [(u, v) for u in range(0, 107, 2)
                 for v in range(0, u+1, 2) if u*u + v*v == 212]
    assert row_pairs == [(14, 4)]
    alt_pairs = []
    for t in range(-106, 107, 2):
        for u in range(-106, 107, 2):
            if t*t+u*u != 212:
                continue
            ae, ao = (14+t)//2, (14-t)//2
            be, bo = (4+u)//2, (4-u)//2
            if all(abs(s) <= 53 and s % 2 for s in (ae, ao, be, bo)):
                alt_pairs.append((t, u))
    assert sorted(alt_pairs) == [(-4, -14), (-4, 14), (4, -14), (4, 14)]
    assert [(53-s)//2 for s in (9, 5, 9, -5)] == [22, 24, 22, 29]
    checks += 3

    return {
        "status": "PASS",
        "checks": checks,
        "exhaustive_existence_n_le_12": found,
        "seed_lengths": sorted(SEEDS),
        "multiplication_lengths_verified": sorted(generated),
        "n106_nonnegative_row_sums": row_pairs,
        "n106_alternating_sum_branches": sorted(alt_pairs),
        "scope": "bootstrap validation only; no open length has been solved"
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--candidate", type=Path)
    args = p.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), indent=2))
    elif args.candidate:
        obj = json.loads(args.candidate.read_text())
        if type(obj.get("n")) is not int or obj["n"] != len(obj.get("A", [])):
            raise ValueError("n must be an exact integer equal to len(A)")
        print(json.dumps(verify(obj["A"], obj["B"]), indent=2))
    else:
        p.error("select --self-test or --candidate FILE")


if __name__ == "__main__":
    main()
