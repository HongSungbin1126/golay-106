#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <sys/resource.h>

// Exact objective; heuristic proposals only. Mirror identity is preserved.
struct Search {
    int n, m;
    std::vector<int> a,b,r;
    long long energy=0;
    std::mt19937_64 rng;
    explicit Search(int nn,uint64_t seed):n(nn),m(nn/2),a(nn),b(nn),r(nn),rng(seed) {
        if(n<2 || n%2) throw std::runtime_error("positive even n>=2 required");
    }
    int sign(){return (rng()&1)?1:-1;}
    long long recompute(bool check=false) {
        long long e=0;
        for(int k=1;k<n;k++) {
            int z=0;for(int i=0;i<n-k;i++) z+=a[i]*a[i+k]+b[i]*b[i+k];
            if(check && r[k]!=z) throw std::runtime_error("incremental residual mismatch");
            r[k]=z;e+=1LL*z*z;
        }
        if(check && e!=energy) throw std::runtime_error("incremental energy mismatch");
        energy=e;return e;
    }
    void init(){
        for(int i=0;i<m;i++){int j=n-1-i;a[i]=sign();a[j]=sign();b[i]=sign();b[j]=-a[i]*a[j]*b[i];}
        recompute();
    }
    void flip(int row,int pos){
        auto& s=row?b:a;
        const int v=s[pos];
        for(int k=1;k<n;k++){
            int d=0;
            if(pos>=k)d-=2*v*s[pos-k];
            if(pos+k<n)d-=2*v*s[pos+k];
            energy+=1LL*d*(2*r[k]+d);r[k]+=d;
        }
        s[pos]=-v;
    }
    // Toggle a_i, a_j, b_i independent signs; the dependent b_j follows.
    void move(int i,int mask){
        int j=n-1-i;
        if(mask&1)flip(0,i);
        if(mask&2)flip(0,j);
        if(mask&4)flip(1,i);
        if(__builtin_popcount((unsigned)mask)&1)flip(1,j);
    }
    void write(const std::string& path,uint64_t steps,uint64_t restarts,double elapsed,long long best){
        std::ofstream f(path);if(!f)throw std::runtime_error("cannot write witness");
        f<<"{\n\"n\":"<<n<<",\n\"A\":[";
        for(int i=0;i<n;i++)f<<(i?",":"")<<a[i];
        f<<"],\n\"B\":[";for(int i=0;i<n;i++)f<<(i?",":"")<<b[i];
        f<<"],\n\"energy\":"<<best<<",\n\"steps\":"<<steps
         <<",\n\"restarts\":"<<restarts<<",\n\"wall_seconds\":"<<elapsed
         <<",\n\"status\":\""<<(best==0?"EXACT_CANDIDATE_REQUIRES_INDEPENDENT_CHECK":"HEURISTIC_NEAR_PAIR")<<"\"\n}\n";
    }
};

int main(int argc,char**argv){
    if(argc<5){std::cerr<<"usage: search_anneal N SEED SECONDS OUTPUT [sweep_length] [T_high] [T_low] [initial_txt]\n";return 2;}
    int n=std::stoi(argv[1]);uint64_t seed=std::stoull(argv[2]);double seconds=std::stod(argv[3]);
    std::string output=argv[4];
    uint64_t sweep=argc>5?std::stoull(argv[5]):250000;
    double thigh=argc>6?std::stod(argv[6]):std::max(12.,0.45*n),tlow=argc>7?std::stod(argv[7]):2.;
    if(seconds<=0||sweep==0||tlow<=0||thigh<tlow)throw std::runtime_error("invalid budget or temperature");
    Search s(n,seed);s.init();
    std::vector<int> initial_a,initial_b;
    if(argc>8){
        std::ifstream f(argv[8]);int length=0;f>>length;
        if(length!=n)throw std::runtime_error("initial length mismatch");
        for(int& v:s.a)f>>v;
        for(int& v:s.b)f>>v;
        if(!f)throw std::runtime_error("invalid initial pair");
        for(int i=0;i<n;i++)if(std::abs(s.a[i])!=1||std::abs(s.b[i])!=1)throw std::runtime_error("invalid initial sign");
        for(int i=0;i<s.m;i++)if(s.a[i]*s.a[n-1-i]+s.b[i]*s.b[n-1-i])throw std::runtime_error("initial pair violates mirror");
        initial_a=s.a;initial_b=s.b;s.recompute();
    }
    auto start=std::chrono::steady_clock::now();
    auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
    long long best=s.energy;uint64_t steps=0,restarts=0;
    std::vector<int> best_a=s.a,best_b=s.b;
    s.write(output,steps,restarts,elapsed(),best);
    std::uniform_real_distribution<double> uniform(0.,1.);
    std::vector<double> temps(sweep);for(uint64_t j=0;j<sweep;j++)temps[j]=thigh*std::pow(tlow/thigh,(double)j/sweep);
    for(;;){
        uint64_t phase=steps%sweep;
        if(phase==0 && steps){
            restarts++;
            if(initial_a.empty() || restarts%4==0)s.init();
            else{
                s.a=(restarts%4==1)?initial_a:best_a;
                s.b=(restarts%4==1)?initial_b:best_b;
                s.recompute();
                int perturb=1+s.rng()%std::max(2,s.m/8);
                for(int j=0;j<perturb;j++)s.move(s.rng()%s.m,1+s.rng()%7);
            }
        }
        long long previous=s.energy;
        int pos=s.rng()%s.m,mask=1+(s.rng()%7);
        s.move(pos,mask);long long delta=s.energy-previous;
        // E/16 is the integer reduced energy within the mirror-constrained domain.
        if(delta>0 && uniform(s.rng)>=std::exp(-double(delta)/(16.*temps[phase])))s.move(pos,mask);
        steps++;
        if(s.energy<best){
            best=s.energy;s.recompute(true);best_a=s.a;best_b=s.b;s.write(output,steps,restarts,elapsed(),best);
            std::cout<<"{\"event\":\"improvement\",\"n\":"<<n<<",\"seed\":"<<seed<<",\"energy\":"<<best<<",\"steps\":"<<steps<<",\"seconds\":"<<elapsed()<<"}"<<std::endl;
            if(best==0)break;
        }
        if((steps&4095)==0){
            if((steps&65535)==0)s.recompute(true);
            if(elapsed()>=seconds)break;
        }
    }
    struct rusage usage{};getrusage(RUSAGE_SELF,&usage);
    std::cout<<"{\"event\":\"complete\",\"n\":"<<n<<",\"seed\":"<<seed<<",\"best_energy\":"<<best<<",\"steps\":"<<steps<<",\"restarts\":"<<restarts<<",\"seconds\":"<<elapsed()<<",\"peak_rss_kib\":"<<usage.ru_maxrss<<"}"<<std::endl;
}
