"""Resume-safe, resource-bounded independent H-partition campaign.

Outputs concern the FIRST PARITY relaxation only. They never assert Golay UNSAT.
Only completed prefixes count as covered. A crashed/incomplete partition is kept
for diagnosis and must be explicitly resumed, never counted as exhausted.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import subprocess
import time


def save(path,obj):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def live_cpu(pid):
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        return (int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')
    except (FileNotFoundError,ProcessLookupError):return 0.


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--p',type=int,required=True);p.add_argument('--binary',required=True)
    p.add_argument('--source',required=True);p.add_argument('--tag',required=True)
    p.add_argument('--chunk-size',type=int,default=1<<20)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--per-chunk-seconds',type=int,default=1100)
    p.add_argument('--cpu-budget',type=float,default=14400)
    p.add_argument('--h-start',type=int,default=0);p.add_argument('--h-count',type=int,default=0)
    a=p.parse_args()
    if not(1<=a.workers<=4 and 0<a.per_chunk_seconds<=1180):p.error('resource bounds')
    total=1<<((a.p-1)//2);end=total if not a.h_count else min(total,a.h_start+a.h_count)
    if not(0<=a.h_start<end):p.error('invalid H range')
    out=Path('results')/a.tag;out.mkdir(exist_ok=True)
    source_hash=digest(a.source);binary_hash=digest(a.binary)
    snapshots=Path('experiments/source_snapshots');snapshots.mkdir(exist_ok=True)
    (snapshots/(source_hash+'.cpp')).write_bytes(Path(a.source).read_bytes())
    pending=[(i,min(a.chunk_size,end-i)) for i in range(a.h_start,end,a.chunk_size)]
    completed=[];failed=[];active=[];start=time.monotonic();cpu0=resource.getrusage(resource.RUSAGE_CHILDREN)
    limits_cpu=a.per_chunk_seconds
    def limits():
        resource.setrlimit(resource.RLIMIT_CPU,(limits_cpu+3,limits_cpu+5))
        resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        resource.setrlimit(resource.RLIMIT_FSIZE,(200*1024**2,200*1024**2))
    last_status=0.;stop=False
    while pending or active:
        cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
        measured=cpu.ru_utime+cpu.ru_stime-cpu0.ru_utime-cpu0.ru_stime
        if measured+sum(live_cpu(j['proc'].pid) for j in active)>=a.cpu_budget:stop=True
        while pending and len(active)<a.workers and not stop:
            h,count=pending.pop(0);name=f'h{h:09d}_count{count:09d}'
            report=out/(name+'.json');orientations=out/(name+'.jsonl')
            receipt=out/(name+'_receipt.json')
            if report.exists() and receipt.exists():
                previous=json.loads(receipt.read_text());r=json.loads(report.read_text())
                if previous['source_sha256']!=source_hash or previous['binary_sha256']!=binary_hash:
                    raise RuntimeError('existing partition uses another executable; choose a new tag')
                if previous['returncode']==0 and r.get('H_completed')==count and r.get('h_start')==h and r.get('h_end_exclusive')==h+count:
                    completed.append(previous);continue
                raise RuntimeError('existing incomplete partition: choose explicit uncovered range and new tag')
            cmd=[a.binary,'--p',str(a.p),'--seconds',str(a.per_chunk_seconds),'--h-start',str(h),'--h-limit',str(count),'--output',str(report),'--orientations',str(orientations),'--source-sha256',source_hash]
            log=(out/(name+'.log')).open('w')
            proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
            active.append({'proc':proc,'log':log,'h':h,'count':count,'report':report,'orientations':orientations,'receipt':receipt,'command':cmd,'started':time.monotonic()})
        for job in list(active):
            proc=job['proc']
            if proc.poll() is None and (time.monotonic()-job['started']>a.per_chunk_seconds+15 or stop):
                proc.terminate()
                try:proc.wait(timeout=2)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()
            if proc.poll() is None:continue
            job['log'].close();active.remove(job)
            r=json.loads(job['report'].read_text()) if job['report'].exists() else {}
            rec={'h_start':job['h'],'h_count':job['count'],'command':job['command'],'returncode':proc.returncode,'wall_seconds':time.monotonic()-job['started'],'source_sha256':source_hash,'binary_sha256':binary_hash,'report_path':str(job['report']),'orientation_path':str(job['orientations']),'H_completed':r.get('H_completed',0),'status':r.get('status','NO_COMPLETE_REPORT'),'cpu_seconds':r.get('cpu_seconds'),'orientation_sha256':digest(job['orientations']) if job['orientations'].exists() else None}
            save(job['receipt'],rec)
            if proc.returncode==0 and rec['H_completed']==job['count'] and r.get('h_start')==job['h'] and r.get('h_end_exclusive')==job['h']+job['count']:
                completed.append(rec)
            else:failed.append(rec);stop=True
            print(json.dumps({'event':'partition_finished','h_start':rec['h_start'],'h_count':rec['h_count'],'H_completed':rec['H_completed'],'status':rec['status'],'returncode':rec['returncode'],'cpu_seconds':rec['cpu_seconds']}),flush=True)
        now=time.monotonic()
        if now-last_status>=20 or (not active and (not pending or stop)):
            usage=resource.getrusage(resource.RUSAGE_CHILDREN)
            measured=usage.ru_utime+usage.ru_stime-cpu0.ru_utime-cpu0.ru_stime
            state={'target':'FIRST_QUAD_PARITY_RELAXATION_ONLY','p':a.p,'n':2*a.p,'requested_h_range':[a.h_start,end],'full_h_domain_size':total,'source_sha256':source_hash,'binary_sha256':binary_hash,'elapsed_wall_seconds':now-start,'completed_child_cpu_seconds':measured,'completed_partitions':completed,'failed_partitions':failed,'active':[{k:v for k,v in j.items() if k in ['h','count','started']} for j in active],'pending_ranges':pending,'status':'STOPPED_INCOMPLETE' if stop else 'RUNNING' if active or pending else 'REQUESTED_H_RANGE_COMPLETE'}
            save(out/'campaign_state.json',state)
            print(json.dumps({'event':'status','tag':a.tag,'completed_H':sum(x['H_completed'] for x in completed),'requested_H':end-a.h_start,'active_workers':len(active),'pending_partitions':len(pending),'elapsed_seconds':now-start,'state':state['status']}),flush=True)
            last_status=now
        if stop and not active:break
        time.sleep(1)


if __name__=='__main__':main()
