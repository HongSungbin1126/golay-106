"""Produce a complete correlation-profile certificate for a small negative n.

This generator uses XOR/popcount.  The separate checker reconstructs every
sequence and uses direct signed multiplication.  No quad/mirror lemma is used.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path


def make(n):
    if type(n) is not int or not 1 <= n <= 20:
        raise ValueError("the bounded profile generator supports 1 <= n <= 20")
    start = time.process_time()
    profiles = []
    first = {}
    for tail in range(1 << (n-1)):
        bits = tail << 1  # the first entry is +1
        p = tuple(n-k-2*((bits ^ (bits >> k)) & ((1 << (n-k))-1)).bit_count()
                  for k in range(1, n))
        opposite = tuple(-v for v in p)
        if opposite in first or all(v == 0 for v in p):
            other = first.get(opposite, tail)
            seq = lambda t: [1] + [1-2*((t >> i) & 1) for i in range(n-1)]
            return {"format": "golay_exact_profile_v1", "n": n,
                    "claim": "SAT", "A": seq(tail), "B": seq(other),
                    "cpu_seconds": time.process_time()-start}
        profiles.append(list(p))
        first.setdefault(p, tail)
    return {"format": "golay_exact_profile_v1", "n": n,
            "claim": "NO_BINARY_APERIODIC_PAIR_AT_THIS_LENGTH",
            "normalization": "FIRST_ENTRY_PLUS_ONE_IN_EACH_SEQUENCE",
            "enumeration": "tail_bits_little_endian; sign=1-2*bit",
            "sequences_covered": len(profiles),
            "profiles_in_tail_order": profiles,
            "unique_profiles": len(first),
            "cpu_seconds": time.process_time()-start}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    obj = make(args.n)
    data = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(data)
    print(json.dumps({k: v for k, v in obj.items() if k != "profiles_in_tail_order"}
                     | {"path": str(args.output), "sha256": hashlib.sha256(data).hexdigest(),
                        "bytes": len(data)}, indent=2))


if __name__ == "__main__":
    main()
