"""Bounded single-process heuristic run with independent exact candidate check."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import resource
import subprocess
import time
from verify_independent import verify_pair


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--n',type=int,required=True)
    p.add_argument('--seed',type=int,required=True)
    p.add_argument('--seconds',type=float,required=True)
    p.add_argument('--sweep',type=int,default=250000)
    p.add_argument('--thigh',type=float,default=4.)
    p.add_argument('--tlow',type=float,default=.2)
    p.add_argument('--initial')
    p.add_argument('--tag',required=True)
    args=p.parse_args()
    if not args.tag.replace('_','').replace('-','').isalnum():p.error('tag must be a safe identifier')
    target=Path('data/pairs')/f'anneal_{args.tag}.json'
    log=Path('experiments')/f'anneal_{args.tag}.jsonl'
    cmd=['build/search_anneal',str(args.n),str(args.seed),str(args.seconds),str(target),str(args.sweep),str(args.thigh),str(args.tlow)]
    if args.initial:cmd.append(args.initial)
    def limits():
        resource.setrlimit(resource.RLIMIT_CPU,(math.ceil(args.seconds)+3,math.ceil(args.seconds)+5))
        resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        resource.setrlimit(resource.RLIMIT_FSIZE,(200*1024**2,200*1024**2))
    t=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    with log.open('w') as stream:
        r=subprocess.run(cmd,stdout=stream,stderr=subprocess.PIPE,text=True,timeout=args.seconds+10,preexec_fn=limits)
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    payload=json.loads(target.read_text())
    check=verify_pair(payload['A'],payload['B'],expected_n=args.n)
    if check['energy']!=payload['energy']:
        raise ArithmeticError('search energy differs from exact validation')
    row={'run_id':args.tag,'target':'BINARY_APERIODIC_GOLAY_LENGTH_CONJECTURE','scope':'mirror-constrained heuristic; not exhaustive','command':cmd,'source_sha256':hashlib.sha256(Path('src/search_anneal.cpp').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest(),'wall_seconds':time.monotonic()-t,'cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'peak_child_ram_bytes':after.ru_maxrss*1024,'returncode':r.returncode,'stderr':r.stderr,'best_energy':check['energy'],'verification':check,'candidate_path':str(target),'log_path':str(log),'final_log':json.loads(log.read_text().splitlines()[-1]),'allowed_conclusion':'EXACT_PAIR_VERIFIED' if check['aperiodic_golay'] else 'NO_CONCLUSION_ON_EXISTENCE'}
    row['reported_children_rss_upper_bound_bytes']=row.pop('peak_child_ram_bytes')
    row['peak_solver_ram_bytes']=row['final_log'].get('peak_rss_kib',0)*1024 or None
    Path('results',f'anneal_{args.tag}.json').write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k not in ['verification','stderr']},indent=2),flush=True)


if __name__=='__main__':main()
