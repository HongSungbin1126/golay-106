#!/usr/bin/env python3
"""Link accepted archived evidence; not a replacement for enumeration or proofs.

Run from any directory. Recreates only CLAIMS.json and final_acceptance.json.
No solver is invoked. Mathematical proof audits are explicitly human-readable
dependencies, not automatically verified theorem-kernel derivations.
"""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = {}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def unique_object(items):
    out = {}
    for key, value in items:
        require(key not in out, 'duplicate JSON key: ' + key)
        out[key] = value
    return out


def digest(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


def record(path):
    EVIDENCE[path] = {'sha256': digest(path), 'bytes': (ROOT / path).stat().st_size}
    return EVIDENCE[path]['sha256']


def read(path):
    record(path)
    return json.loads((ROOT / path).read_text(), object_pairs_hook=unique_object)


def linked(path, expected):
    actual = record(path)
    require(actual == expected, 'hash mismatch: ' + path)


def write(path, obj):
    target = ROOT / path
    temporary = target.with_name(target.name + '.finalizing')
    temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
    os.replace(temporary, target)


def main():
    p = read('results/final_primary_coverage_audit.json')
    i = read('results/final_independent_coverage_audit.json')
    a = read('results/campaign_n106_sign_space_audit.json')
    c = read('results/exact_sign_character_certificate_checked.json')
    m = read('results/exact_sign_character_certificate_mutations.json')
    d = read('results/campaign_n106_direct_sign_replay.json')
    s = read('results/exact_signs_n106_campaign_full_signs.json')
    v = read('results/campaign_n106_first_parity_independent/final_summary.json')
    smoke = read('results/primary_driver_positive_smoke_audit.json')

    require(p['status'] == 'COMPLETE_ARTIFACT_COVERAGE', 'primary not complete')
    require(p['domain'] == [0, 1 << 26] and p['valid_partition_count'] == 64,
            'primary domain/count')
    require(not p['gaps'] and not p['overlaps'], 'primary interval defect')
    require(p['orientation_count'] == 102, 'primary orientations')
    require(p['statistics']['unit_H'] == (1 << 26) - 1 and
            p['statistics']['nonunit_H'] == 1, 'primary unit accounting')
    linked('src/exact_orientation_fibers_v2.cpp', p['source_sha256'])
    linked('src/exact_orientation_fibers_v2', p['binary_sha256'])
    linked('src/audit_fiber_campaign.py', p['auditor_sha256'])

    require(i['status'] == 'COMPLETE_INDEPENDENT_FIRST_PARITY_REPLAY_ACCEPTED',
            'independent not accepted')
    require(i['domain'] == [0, 1 << 26] and i['covered_H'] == 1 << 26 and
            i['partition_count'] == 64 and i['orientation_count'] == 102 and
            i['exact_primary_set_match'] is True, 'independent coverage/match')
    linked('src/verify_folded_independent_v2.cpp', i['source_sha256'])
    linked('results/campaign_n106_first_parity_independent/source_snapshot.cpp',
           i['source_sha256'])
    linked('results/campaign_n106_first_parity_independent/binary_snapshot',
           i['binary_sha256'])
    linked('src/audit_independent_campaign.py', i['auditor_sha256'])
    orientation_path = 'results/campaign_n106_first_parity_orientations.jsonl'
    linked(orientation_path, i['primary_reference_sha256'])
    linked('results/campaign_n106_first_parity_independent/all_orientations.jsonl',
           v['orientation_sha256'])
    require(v['H_completed'] == 1 << 26 and v['orientation_count'] == 102 and
            v['completed_partitions'] == 64, 'independent summary')

    require(a['result'] == 'PASS' and a['input_orientation_count'] == 102 and
            a['complete_declared_orientation_count'] == 102 and
            a['affine_contradictions_independently_verified'] == 94 and
            a['complete_declared_input_coverage'] is True and
            a['summary_provenance_linked'] is True, 'sign-space coverage')
    require(len(a['orientation_inputs']) == 1 and
            a['orientation_inputs'][0]['sha256'] == digest(orientation_path),
            'sign-space orientation link')
    spaces = [x for x in a['orientations'] if x['affine_system'] == 'CONSISTENT']
    require(len(spaces) == 8 and sorted(x['nullity'] for x in spaces) ==
            [4, 4, 4, 4, 20, 20, 26, 26], 'sign-space dimensions')
    sign_count = sum(x['space_size'] for x in spaces)
    require(sign_count == 136314944 and all(
        x['space_size'] == 1 << x['nullity'] for x in spaces), 'sign-space sizes')
    require(s['status'] == 'COMPLETE_INPUT_NO_PAIR' and
            s['completed_orientations'] == 102 and s['skipped_kernel_bound'] == 0 and
            s['sign_assignments_examined'] == sign_count, 'native signs incomplete')
    linked('results/exact_signs_n106_campaign_full_signs.jsonl', s['details_sha256'])
    require(s['input_sha256'] == digest(orientation_path), 'native input link')
    require(a['summary_inputs'][0]['sha256'] ==
            digest('results/exact_signs_n106_campaign_full_signs.json'),
            'affine summary hash link')

    require(c['result'] == 'PASS' and c['spaces_checked'] == 8 and
            c['upstream_affine_spaces_linked'] is True and
            c['all_supplied_spaces_excluded_mod64'] is True,
            'mod64 character certificate not accepted')
    linked('results/exact_signs_n106_campaign_kernel_inventory.jsonl',
           c['space_input_sha256'])
    linked('results/algebra_sign_character_reductions.json', c['certificate_sha256'])
    linked('src/exact_sign_character_certificate_check.py', c['checker_source_sha256'])
    linked('results/campaign_n106_sign_space_audit.json',
           c['upstream_affine_audit_sha256'])
    w = c['mod32_witness_validation']
    require(w['result'] == 'PASS' and w['verified_mod32_pairs'] == 8 and
            w['exact_mod32_count_within_supplied_spaces'] == 8 and
            w['original_signed_correlations_recomputed'] is True and
            w['all_eight_fail_mod64'] is True and
            w['one_standard_symmetry_orbit'] is True and
            w['full_generated_orbit_size'] == 64 and
            w['mode_P_members_in_orbit'] == 8, 'mod32 classification')
    linked('results/algebra_mod32_witnesses.json', w['witness_file_sha256'])
    require(m['result'] == 'PASS' and len(set(m['mutations_rejected'])) == 8 and
            m['checker_source_sha256'] == c['checker_source_sha256'],
            'certificate mutation verification')

    require(d['status'] == 'COMPLETE_INDEPENDENT_SIGN_REPLAY_NO_PAIR' and
            d['returncode'] == 0 and d['original_sign_rejections_replayed'] is True
            and d['footer']['completed_spaces'] == 8 and
            d['footer']['total_assignments'] == sign_count and
            not d['positive_witnesses'], 'direct replay incomplete')
    linked('results/campaign_n106_sign_space_audit.json', d['audit_sha256'])
    linked('results/campaign_n106_direct_sign_replay.jsonl', d['output_sha256'])
    linked('results/campaign_n106_direct_sign_replay_input.txt', d['input_sha256'])
    linked('src/verify_signs_direct.cpp', d['source_sha256'])
    linked('src/verify_signs_direct', d['binary_sha256'])
    require(smoke['status'] == 'COMPLETE_ARTIFACT_COVERAGE' and
            smoke['domain'] == [0, 4] and smoke['orientation_count'] == 4 and
            not smoke['invalid_receipts'], 'portable driver smoke')

    proof_files = [
        'proof/audit_quad_reduction.md',
        'proof/audit_acceptance_and_normalizations.md',
        'proof/algebra_orientation_fibers.md',
        'proof/audit_folded_solver.md',
        'proof/audit_independent_replay_engine.md',
        'proof/algebra_full_domain_verification.md',
        'proof/algebra_sign_character_certificates.md',
        'proof/audit_mod64_extension.md',
        'results/exact_sign_character_proof.md',
        'proof/algebra_analytic_first_stage.md',
        'proof/algebra_second_projection.md',
        'sources/status_ledger.jsonl',
        'sources/algebra_prior_work_ledger.jsonl',
        'RESEARCH_PROTOCOL.md',
        'src/finalize_research_claims.py',
    ]
    for path in proof_files:
        record(path)

    counts = [(4, 1 << 156, '2^156'), (8, 102 * (1 << 52), '102*2^52'),
              (16, sign_count, '136314944'), (32, 8, '8'), (64, 0, '0')]
    claims = {
        'schema': 'golay106_accepted_claims_v1', 'as_of': '2026-11-05',
        'status': 'COMPLETE_COMPUTER_ASSISTED_FINITE_RESULT',
        'target': {'alphabet': [-1, 1], 'sequence_count': 2, 'equal_length': 106,
                   'correlation': 'APERIODIC', 'pair_order_matters': True,
                   'residual': 'r_k=sum(i=0..105-k)(a_i*a_(i+k)+b_i*b_(i+k)), k=1..105'},
        'main_claim': 'No pair has r_k divisible by64 for all k=1..105.',
        'corollary': 'No ordinary binary aperiodic Golay pair has length106.',
        'normalization': {'name': 'MODE P', 'a0': 1, 'b0': 1, 'a105': 1,
                          'b105': -1, 'raw_ordered_count_multiplier': 8},
        'exact_modular_counts': [
            {'modulus': mod, 'mode_P_count_decimal': str(count),
             'mode_P_count_formula': formula, 'raw_ordered_count_decimal': str(8*count)}
            for mod, count, formula in counts],
        'mod32_orbit': {'mode_P_pairs': 8, 'raw_ordered_pairs': 64,
                        'standard_symmetry_orbits': 1},
        'enumeration': {'H_domain': [0, 1 << 26], 'independent_full_implementations': 2,
                        'orientations': 102, 'inconsistent_sign_systems': 94,
                        'remaining_sign_spaces': 8, 'sign_assignments': sign_count,
                        'exact_candidate_set_agreement': True},
        'verification_level': 'complete finite enumeration plus reviewed mathematical reductions and separately checked exact integer certificates',
        'formal_kernel_proof': False, 'external_peer_review': False,
        'publication_priority': 'NOT_ESTABLISHED',
        'human_frontier_improvement': 'NOVELTY_REVIEW_REQUIRED',
        'general_length_conjecture': 'NOT_SOLVED',
        'not_claimed': ['global minimum energy', 'other untested lengths excluded',
                        'a fast character check redoes complete H enumeration'],
        'shared_mathematical_dependencies': [
            'mirror equivalence for mod4 and complete MODE P normalization',
            'quad parity equivalence for mod8 and affine sign equivalence for mod16',
            'folded inverse necessity and complete affine-fiber parameterization',
            'sound complete quadratic elimination/branching',
            'safe exact integer congruence reductions for mod32/mod64'],
        'trusted_base': ['reviewed mathematical reductions', 'C++ enumeration source',
                         'Python/C++ integer verifiers', 'compiler/runtime/hardware'],
        'linker_scope': 'cross-file metadata/hash consistency; not a mathematical theorem kernel or a fresh solver run',
        'timing_seconds': {
            'primary_selected_partition_native_cpu': p['cpu_seconds_selected_partitions'],
            'independent_child_cpu': i['controller_child_cpu_seconds'],
            'independent_wall': i['controller_wall_seconds'],
            'independent_native_cpu_sum': i['aggregate_native_cpu_seconds'],
            'direct_sign_native_cpu': d['footer']['cpu_seconds'],
            'character_checker_cpu': c['cpu_seconds']},
        'evidence': dict(sorted(EVIDENCE.items()))}
    write('CLAIMS.json', claims)
    write('results/final_acceptance.json', {
        'status': 'PASS_ALL_FINAL_EVIDENCE_LINKS', 'as_of': '2026-11-05',
        'accepted_scope': claims['verification_level'],
        'claims_sha256': digest('CLAIMS.json'),
        'linker_source_sha256': digest('src/finalize_research_claims.py'),
        'evidence_file_count': len(EVIDENCE),
        'all_required_scope_and_count_gates_passed': True,
        'mathematical_proof_audits_are_external_to_this_linker': True,
        'formal_kernel_proof': False, 'publication_priority': 'NOT_ESTABLISHED'})
    print(json.dumps({'status': 'PASS_ALL_FINAL_EVIDENCE_LINKS',
                      'evidence_files': len(EVIDENCE), 'n': 106,
                      'mod32_mode_P_pairs': 8, 'mod64_pairs': 0}))


if __name__ == '__main__':
    main()
