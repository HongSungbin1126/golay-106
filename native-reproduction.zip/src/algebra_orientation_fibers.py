"""Exact folded orientation search; ONLY the first quad parity system.

Outer variable H=Q+reverse(Q) has (p-1)/2 bits for odd p=n/2.
H must be invertible modulo J_p; K=T+reverse(T) is then determined.
Within a fiber, preserve all residual quadratic equations while repeatedly
extracting affine consequences by quotienting their quadratic output span.
If this stalls, branch: no rank conjecture is needed for completeness.
"""
import argparse
from collections import Counter
import itertools
import json
from pathlib import Path
import random
import resource
import time


def reverse(a, p):
    return sum(((a >> i) & 1) << (p-1-i) for i in range(p))


def gf2_mod(a, f):
    while a and a.bit_length() >= f.bit_length():
        a ^= f << (a.bit_length()-f.bit_length())
    return a


def gf2_mul(a, b):
    out = 0
    while b:
        if b & 1:
            out ^= a
        a <<= 1
        b >>= 1
    return out


def gf2_inv(a, f):
    u, v, x, y = gf2_mod(a, f), f, 1, 0
    while u != 1:
        if not u:
            return None
        j = u.bit_length()-v.bit_length()
        if j < 0:
            u, v, x, y = v, u, y, x
            j = -j
        u ^= v << j
        x ^= y << j
    return gf2_mod(x, f)


def fold_polynomial(h, p):
    m = (p-1)//2
    assert 0 <= h < (1 << m)
    return h ^ reverse(h, p)


def inverse_partner(H, p):
    J = (1 << p)-1
    inv = gf2_inv(H, J)
    if inv is None:
        return None
    K = gf2_mod(H ^ gf2_mul(1 << (p-1), inv), J)
    # Two representatives modulo J of degree at most p-1; exactly one has
    # middle coefficient zero.  This representative must be palindromic.
    if (K >> (p//2)) & 1:
        K ^= J
    assert reverse(K, p) == K and not ((K >> (p//2)) & 1)
    assert gf2_mod(gf2_mul(H, H ^ K) << 1, J) == 1
    return K


def parity_output(q, t, p):
    """Bit k-1 is the active-edge count at lag k, modulo two."""
    out = 0
    for i in range(p):
        for j in range(i+1, p):
            if ((t >> i) ^ (t >> j)) & 1:
                continue
            k = 2*p-1-i-j if ((q >> i) ^ (q >> j)) & 1 else j-i
            out ^= 1 << (k-1)
    return out


def span_basis(columns):
    basis = {}
    for c in columns:
        while c:
            j = c.bit_length()-1
            if j in basis:
                c ^= basis[j]
            else:
                basis[j] = c
                break
    return basis


def reduce_span(c, basis):
    for j in sorted(basis, reverse=True):
        if (c >> j) & 1:
            c ^= basis[j]
    return c


def affine_preimage(columns, target):
    """Solve XOR_i(columns[i]*x_i)=target; return particular and kernel."""
    basis = {}
    kernel = []
    for i, c in enumerate(columns):
        combination = 1 << i
        while c:
            j = c.bit_length()-1
            if j in basis:
                c ^= basis[j][0]
                combination ^= basis[j][1]
            else:
                basis[j] = (c, combination)
                break
        if not c:
            kernel.append(combination)
    particular = 0
    for j in sorted(basis, reverse=True):
        if (target >> j) & 1:
            target ^= basis[j][0]
            particular ^= basis[j][1]
    return None if target else (particular, kernel)


def xor_directions(mask, directions):
    q = t = 0
    while mask:
        low = mask & -mask
        i = low.bit_length()-1
        q ^= directions[i][0]
        t ^= directions[i][1]
        mask ^= low
    return q, t


class FiberSolver:
    def __init__(self, p, deadline_cpu):
        self.p = p
        self.deadline_cpu = deadline_cpu
        self.stats = Counter()
        self.stage_hist = Counter()

    def evaluate(self, q, t):
        self.stats["parity_evaluations"] += 1
        if not self.stats["parity_evaluations"] % 1024:
            if time.process_time() > self.deadline_cpu:
                raise TimeoutError("CPU deadline; incomplete enumeration")
        return parity_output(q, t, self.p)

    def solve_affine_space(self, base, directions):
        self.stats["affine_nodes"] += 1
        while True:
            q, t = base
            c = self.evaluate(q, t)
            d = len(directions)
            if d == 0:
                if c == 0:
                    self.stats["solutions"] += 1
                    yield q, t
                return
            linear = [self.evaluate(q ^ x, t ^ y) ^ c for x, y in directions]
            quadratic = []
            for i, (x, y) in enumerate(directions):
                for j, (u, v) in enumerate(directions[:i]):
                    quadratic.append(self.evaluate(q ^ x ^ u, t ^ y ^ v)
                                     ^ linear[i] ^ linear[j] ^ c)
            quad_basis = span_basis(quadratic)
            projected_c = reduce_span(c, quad_basis)
            projected_columns = [reduce_span(a, quad_basis) for a in linear]
            preimage = affine_preimage(projected_columns, projected_c)
            if preimage is None:
                self.stats["linear_contradictions"] += 1
                self.stage_hist[f"{d}/{len(quad_basis)}/INCONSISTENT"] += 1
                return
            particular, kernel = preimage
            self.stage_hist[f"{d}/{len(quad_basis)}/{len(kernel)}"] += 1
            if len(kernel) < d:
                x, y = xor_directions(particular, directions)
                base = q ^ x, t ^ y
                directions = [xor_directions(v, directions) for v in kernel]
                self.stats["affine_reductions"] += 1
                continue
            if not quad_basis:
                # Projection is identity, and rank zero means the full
                # equation is identically zero on this affine space.
                assert c == 0 and all(a == 0 for a in linear)
                self.stats["free_affine_solution_spaces"] += 1
                for mask in range(1 << d):
                    x, y = xor_directions(mask, directions)
                    assert self.evaluate(q ^ x, t ^ y) == 0
                    self.stats["solutions"] += 1
                    yield q ^ x, t ^ y
                return
            # This branch is essential: affine reduction is not assumed to
            # decide every fiber.  The two child spaces partition the parent.
            self.stats["branch_nodes"] += 1
            direction = directions[-1]
            yield from self.solve_affine_space(base, directions[:-1])
            yield from self.solve_affine_space((q ^ direction[0], t ^ direction[1]),
                                              directions[:-1])
            return

    def solve_h(self, h):
        p = self.p
        m = (p-1)//2
        H = fold_polynomial(h, p)
        K = inverse_partner(H, p)
        self.stats["H_examined"] += 1
        if K is None:
            self.stats["nonunit_H"] += 1
            return []
        self.stats["unit_H"] += 1
        low_mask = (1 << m)-1
        # Left representatives and centers zero; reflected half carries H,K.
        base = H ^ (H & low_mask), K ^ (K & low_mask)
        symmetric = [(1 << i) ^ (1 << (p-1-i)) for i in range(1, m)]
        symmetric.append(1 << m)
        directions = [(v, 0) for v in symmetric] + [(0, v) for v in symmetric]
        solutions = list(self.solve_affine_space(base, directions))
        for q, t in solutions:
            assert not (q & 1) and not (t & 1)
            assert q ^ reverse(q, p) == H
            assert t ^ reverse(t, p) == K
            assert parity_output(q, t, p) == 0
        return solutions


def independent_q_enumeration(p):
    """Old q-by-q linear system, independent of folding/projection."""
    out = []
    for qi in range(1 << (p-1)):
        q = qi << 1
        c = parity_output(q, 0, p)
        cols = [parity_output(q, 1 << i, p) ^ c for i in range(1, p)]
        pre = affine_preimage(cols, c)
        if pre is None:
            continue
        t0, ker = pre
        for choices in range(1 << len(ker)):
            t = t0
            for i, k in enumerate(ker):
                if choices >> i & 1:
                    t ^= k
            out.append((q, t << 1))
    return sorted(out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--p", type=int, required=True)
    parser.add_argument("--seconds", type=float, default=60)
    parser.add_argument("--sample", type=int, default=0,
                        help="0 means every H; positive is a fixed-seed sample")
    parser.add_argument("--compare-old", action="store_true")
    parser.add_argument("--compare-jsonl", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert args.p >= 3 and args.p % 2
    resource.setrlimit(resource.RLIMIT_CPU, (int(args.seconds)+3, int(args.seconds)+5))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    start_cpu, start_wall = time.process_time(), time.monotonic()
    solver = FiberSolver(args.p, start_cpu+args.seconds)
    total = 1 << ((args.p-1)//2)
    hs = range(total) if not args.sample else sorted(random.Random(20261105).sample(range(total), min(total,args.sample)))
    result = {"scope": "first quad parity system only; no original Golay existence conclusion",
              "p": args.p, "n": 2*args.p, "total_H_domain": total,
              "sampled_H": bool(args.sample), "solutions": []}
    last_h = None
    try:
        for h in hs:
            solutions = solver.solve_h(h)
            result["solutions"].extend({"h": h, "q_bits_mask": q, "t_bits_mask": t}
                                       for q, t in solutions)
            last_h = h
        result["status"] = "COMPLETE_SAMPLE" if args.sample else "COMPLETE_H_DOMAIN"
    except TimeoutError:
        result["status"] = "TIMEOUT"
    if result["status"] == "COMPLETE_H_DOMAIN":
        found = sorted((r["q_bits_mask"],r["t_bits_mask"]) for r in result["solutions"])
        if args.compare_old:
            old = independent_q_enumeration(args.p)
            assert found == old
            result["independent_q_enumeration_match"] = True
        if args.compare_jsonl:
            old = []
            for line in args.compare_jsonl.read_text().splitlines():
                record = json.loads(line)
                if record["record_type"] == "orientation":
                    old.append((record["q_bits_mask"], record["t_bits_mask"]))
            assert found == sorted(old)
            result["upstream_complete_orientation_match"] = str(args.compare_jsonl)
    result["last_completed_H"] = last_h
    result["statistics"] = dict(solver.stats)
    result["stage_histogram_dim_quadrank_nextdim"] = dict(solver.stage_hist)
    result["cpu_seconds"] = time.process_time()-start_cpu
    result["wall_seconds"] = time.monotonic()-start_wall
    result["peak_rss_kib"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ("status","n","total_H_domain","statistics","cpu_seconds")},indent=2))


if __name__ == "__main__":
    main()
