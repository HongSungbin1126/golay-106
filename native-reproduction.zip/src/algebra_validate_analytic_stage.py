"""Bounded exact validation of the analytic first affine stage.

Uses literal i<j parity evaluation and an independently constructed affine
system; compares the complete analytic affine space, then enumerates all
small residual assignments. It proves no open-length conclusion.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import resource
import time

from algebra_orientation_fibers import (
    affine_preimage, fold_polynomial, gf2_mod, gf2_mul, inverse_partner,
    parity_output, reduce_span, reverse, span_basis, xor_directions,
)


def norm0(value, p):
    J = (1 << p)-1
    value = gf2_mod(value, J)
    return value ^ (J if value & 1 else 0)


def rotate(value, k, p):
    mask = (1 << p)-1
    k %= p
    return ((value << k) | (value >> (p-k))) & mask if k else value


def linear_output_from_f(f, p):
    out = 0
    for r in range(p-1):
        bit = ((f >> r) ^ (f >> (2*p-r-2))) & 1
        out |= bit << r
    return out


def linear_output(q, u, p):
    return linear_output_from_f(parity_output(q, q ^ u, p), p)


def analytic_space(H, G, p):
    """Return full L=0 affine space, expressed in Q/U coefficient masks."""
    m = (p-1)//2
    upper = ((1 << p)-1) ^ ((1 << (m+1))-1)
    qb, ub = H & upper, G & upper
    residual = linear_output(qb, ub, p)
    assert not (residual >> (p-1))
    assert reverse(residual, p-1) == residual
    correction = norm0(gf2_mul(G, residual) << 1, p)
    assert correction & 1 == 0 and reverse(correction, p) == correction
    base = qb, ub ^ correction
    directions = []
    J = (1 << p)-1
    for k in range(1, m+1):
        dq = rotate(H, k, p) ^ rotate(H, -k, p)
        du = rotate(G, k, p) ^ rotate(G, -k, p)
        dq ^= J if dq & 1 else 0
        du ^= J if du & 1 else 0
        assert reverse(dq, p) == dq and not (dq & 1)
        assert reverse(du, p) == du and not (du & 1)
        directions.append((dq, du))
    return base, directions


def original_space(H, G, p):
    m = (p-1)//2
    low = (1 << (m+1))-1
    base = H & ~low, G & ~low
    one = [(1 << i) ^ (0 if i == m else 1 << (p-1-i))
           for i in range(1, m+1)]
    return base, [(v, 0) for v in one] + [(0, v) for v in one]


def encode(point, p):
    return point[0] | (point[1] << p)


def native_set(path):
    result = set()
    for line in path.read_text().splitlines():
        row = json.loads(line)
        if row.get("record_type") == "orientation":
            result.add((row["q_bits_mask"], row["t_bits_mask"]))
    return result


def validate(p, deadline, enumerate_residual=True):
    m = (p-1)//2
    stats = Counter()
    solutions = set()
    for h in range(1 << m):
        if time.process_time() > deadline:
            raise TimeoutError("bounded validation incomplete")
        H = fold_polynomial(h, p)
        K = inverse_partner(H, p)
        stats["H_examined"] += 1
        if K is None:
            stats["nonunit_H"] += 1
            continue
        G = H ^ K
        stats["unit_H"] += 1
        base, directions = analytic_space(H, G, p)
        assert linear_output(*base, p) == 0
        assert base[0] ^ reverse(base[0], p) == H
        assert base[1] ^ reverse(base[1], p) == G

        # Build the original 2m-variable affine equations directly from edges.
        old_base, old_dirs = original_space(H, G, p)
        constant = linear_output(*old_base, p)
        columns = [linear_output(old_base[0] ^ a, old_base[1] ^ b, p) ^ constant
                   for a, b in old_dirs]
        for i, (a, b) in enumerate(old_dirs):
            for j in range(i):
                c, d = old_dirs[j]
                mixed = (linear_output(old_base[0] ^ a ^ c,
                                       old_base[1] ^ b ^ d, p)
                         ^ columns[i] ^ columns[j] ^ constant)
                assert mixed == 0, (p, h, "affine consequence was nonlinear", i, j)
        direct = affine_preimage(columns, constant)
        assert direct is not None, (p, h, "L system inconsistent")
        particular, kernels = direct
        assert len(kernels) == m, (p, h, "wrong rank", len(kernels))
        offset = xor_directions(particular, old_dirs)
        direct_base = (old_base[0] ^ offset[0], old_base[1] ^ offset[1])
        direct_dirs = [xor_directions(v, old_dirs) for v in kernels]
        direct_span = span_basis([encode(v, p) for v in direct_dirs])
        analytic_span = span_basis([encode(v, p) for v in directions])
        assert len(direct_span) == len(analytic_span) == m
        assert all(reduce_span(encode(v, p), direct_span) == 0 for v in directions)
        assert all(reduce_span(encode(v, p), analytic_span) == 0 for v in direct_dirs)
        assert reduce_span(encode(base, p) ^ encode(direct_base, p), direct_span) == 0
        stats["affine_spaces_exactly_matched"] += 1

        middle = ((H & G) & ((1 << m)-1)).bit_count() & 1
        if middle:
            stats["constant_middle_obstruction"] += 1
        if enumerate_residual:
            for selector in range(1 << m):
                a, b = xor_directions(selector, directions)
                q, u = base[0] ^ a, base[1] ^ b
                f = parity_output(q, q ^ u, p)
                assert linear_output_from_f(f, p) == 0
                assert ((f >> (p-1)) & 1) == middle
                stats["residual_assignments_checked"] += 1
                if not f:
                    solutions.add((q, q ^ u))
    comparison = None
    if p == 17:
        path = Path("results/exact_orientation_n34_orientations.jsonl")
        if path.exists():
            expected = native_set(path)
            assert solutions == expected
            comparison = {"path": str(path), "exact_solution_set_match": True,
                          "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    return {"p": p, "n": 2*p, "statistics": dict(stats),
            "first_parity_orientations": len(solutions),
            "orientation_set": [list(v) for v in sorted(solutions)],
            "native_comparison": comparison}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--p", type=int, nargs="+", default=[3, 5, 7, 9, 13, 17])
    parser.add_argument("--seconds", type=float, default=30)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if any(p < 3 or p > 17 or p % 2 == 0 for p in args.p):
        parser.error("bounded exhaustive validation supports odd 3<=p<=17")
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (int(args.seconds)+2, int(args.seconds)+4))
    start = time.process_time()
    result = {"status": "PASS", "claim_scope": "complete small-domain validation only",
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "domains": []}
    try:
        for p in args.p:
            result["domains"].append(validate(p, start+args.seconds))
    except TimeoutError as error:
        result["status"] = "TIMEOUT"
        result["error"] = str(error)
    result["cpu_seconds"] = time.process_time()-start
    result["peak_rss_kib"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"status": result["status"], "cpu_seconds": result["cpu_seconds"],
                      "domains": [{"p": d["p"], "unit_H": d["statistics"].get("unit_H", 0),
                                   "orientations": d["first_parity_orientations"]}
                                  for d in result["domains"]]}, indent=2))


if __name__ == "__main__":
    main()
