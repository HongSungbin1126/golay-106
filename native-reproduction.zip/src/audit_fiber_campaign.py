"""Strictly audit saved first-parity partitions before any global conclusion.

This checks coverage/provenance/output integrity and every listed orientation.
It does NOT independently prove that the search omitted no unlisted solutions.
That obligation is discharged by the reduction proof and separate full replay.
"""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def unique(pairs):
    obj = {}
    for k, v in pairs:
        if k in obj:
            raise ValueError(f"duplicate JSON key: {k}")
        obj[k] = v
    return obj


def read_json(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def reverse(x, p):
    return sum(((x >> i) & 1) << (p - 1 - i) for i in range(p))


def carryless(a, b):
    value = 0
    while b:
        if b & 1:
            value ^= a
        a <<= 1
        b >>= 1
    return value


def remainder(a, f):
    while a.bit_length() >= f.bit_length():
        a ^= f << (a.bit_length() - f.bit_length())
    return a


def check_orientation(row, p, lower, upper):
    require(set(row) == {'record_type','n','h','q_bits_mask','t_bits_mask'}, 'orientation schema')
    require(row['record_type'] == 'orientation' and row['n'] == 2*p, 'wrong target')
    h, q, t = (row[k] for k in ('h','q_bits_mask','t_bits_mask'))
    require(all(type(x) is int for x in (h,q,t)), 'masks must be exact integers')
    require(lower <= h < upper, 'H outside declared partition')
    require(0 <= q < 1 << p and 0 <= t < 1 << p and not ((q | t) & 1), 'invalid MODE P masks')
    H, K = q ^ reverse(q,p), t ^ reverse(t,p)
    m = (p-1)//2
    require(H == (h ^ reverse(h,p)) and not ((H | K) >> m & 1), 'fold mismatch')
    require(remainder(carryless(H,H^K) << 1,(1<<p)-1) == 1, 'inverse identity fails')
    parity = [0]*(2*p)
    for i in range(p):
        for j in range(i+1,p):
            if ((t >> i) ^ (t >> j)) & 1:
                continue
            k = 2*p-1-i-j if ((q >> i) ^ (q >> j)) & 1 else j-i
            parity[k] ^= 1
    require(not any(parity), 'direct edge parity fails')
    return q,t


def audit_partition(receipt_path, source_hash, binary_hash, p):
    rec = read_json(receipt_path)
    require(rec['returncode'] == 0, 'nonzero process return code')
    require(rec['source_sha256'] == source_hash and rec['binary_sha256'] == binary_hash, 'wrong executable provenance')
    report_path, orientation_path = Path(rec['report_path']), Path(rec['orientation_path'])
    report = read_json(report_path)
    require(sha(orientation_path) == rec['orientation_sha256'], 'orientation bytes changed after receipt')
    lower, count = rec['h_start'], rec['h_count']
    upper = lower + count
    require(type(lower) is int and type(count) is int and count > 0, 'bad interval')
    require(report['p'] == p and report['n'] == 2*p, 'report target mismatch')
    require(report['source_sha256'] == source_hash, 'report source mismatch')
    require(report['status'] in ('COMPLETE_H_PARTITION','COMPLETE_H_DOMAIN'), 'report incomplete')
    require(report['h_start'] == lower and report['h_end_exclusive'] == upper, 'report interval mismatch')
    require(report['H_completed'] == count and rec['H_completed'] == count, 'incomplete interval count')
    stats = report['statistics']
    require(stats['H_examined'] == count, 'examined count mismatch')
    require(stats.get('unit_H',0) + stats.get('nonunit_H',0) == count, 'unit accounting mismatch')
    if p == 53:
        expected_nonunit = int(lower == 0)
        require(stats.get('nonunit_H',0) == expected_nonunit, 'J53 inverse accounting failure')
    lines = orientation_path.read_text().splitlines()
    require(len(lines) >= 2 and all(lines), 'missing/truncated header or footer')
    objs = [json.loads(x,object_pairs_hook=unique) for x in lines]
    header, footer = objs[0], objs[-1]
    require(header['record_type'] == 'header' and header['format'] == 'exact_fiber_orientations_v1', 'bad header')
    require(header['n'] == 2*p and header['h_start'] == lower and header['h_end_exclusive'] == upper, 'header interval mismatch')
    require(header['source_sha256'] == source_hash, 'header source mismatch')
    require(footer['record_type'] == 'footer' and footer['status'] == report['status'], 'footer status mismatch')
    require(footer['H_completed'] == count, 'footer coverage mismatch')
    rows = objs[1:-1]
    require(len(rows) == stats.get('solutions',0), 'reported/exported candidate mismatch')
    identities = [check_orientation(x,p,lower,upper) for x in rows]
    require(len(set(identities)) == len(identities), 'duplicate orientation in partition')
    return {'h_start':lower,'h_end_exclusive':upper,'H_completed':count,
            'receipt_path':str(receipt_path),'receipt_sha256':sha(receipt_path),
            'report_path':str(report_path),'report_sha256':sha(report_path),
            'orientation_path':str(orientation_path),'orientation_sha256':sha(orientation_path),
            'statistics':stats,'cpu_seconds':report['cpu_seconds'],
            'wall_seconds':report['wall_seconds'],'rows':rows}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--campaign',action='append',required=True)
    parser.add_argument('--source',default='src/exact_orientation_fibers_v2.cpp')
    parser.add_argument('--binary',default='src/exact_orientation_fibers_v2')
    parser.add_argument('--p',type=int,default=53)
    parser.add_argument('--output',required=True)
    parser.add_argument('--orientations')
    args = parser.parse_args()
    source_hash,binary_hash = sha(args.source),sha(args.binary)
    require(args.p >= 3 and args.p & 1, 'requires odd p')
    valid,invalid,duplicates = {},[],[]
    for folder in args.campaign:
        for path in sorted(Path(folder).glob('*_receipt.json')):
            try:
                item = audit_partition(path,source_hash,binary_hash,args.p)
                key = item['h_start'],item['h_end_exclusive']
                if key in valid:
                    earlier = valid[key]
                    require(sorted(earlier['rows'],key=lambda x:(x['q_bits_mask'],x['t_bits_mask'])) == sorted(item['rows'],key=lambda x:(x['q_bits_mask'],x['t_bits_mask'])), 'replays disagree')
                    duplicates.append({'interval':key,'earlier':earlier['receipt_path'],'later':str(path)})
                else:
                    valid[key] = item
            except (ValueError,KeyError,OSError,json.JSONDecodeError) as exc:
                invalid.append({'receipt_path':str(path),'reason':str(exc)})
    partitions = sorted(valid.values(),key=lambda x:x['h_start'])
    end,total = 0,1<<((args.p-1)//2)
    gaps,overlaps,rows = [],[],[]
    for item in partitions:
        if item['h_start'] > end:
            gaps.append([end,item['h_start']])
        elif item['h_start'] < end:
            overlaps.append([item['h_start'],min(end,item['h_end_exclusive'])])
        end = max(end,item['h_end_exclusive'])
        rows.extend(item['rows'])
    if end < total:
        gaps.append([end,total])
    require(end <= total, 'coverage exceeds domain')
    pairs = [(r['q_bits_mask'],r['t_bits_mask']) for r in rows]
    require(len(set(pairs)) == len(pairs), 'duplicate orientation across partitions')
    stats = Counter()
    for part in partitions:
        stats.update(part['statistics'])
    complete = not gaps and not overlaps and end == total
    if complete:
        require(stats['H_examined'] == total, 'aggregate H count mismatch')
        if args.p == 53:
            require(stats['unit_H'] == total-1 and stats['nonunit_H'] == 1, 'aggregate J53 inverse accounting failure')
    report = {'status':'COMPLETE_ARTIFACT_COVERAGE' if complete else 'INCOMPLETE_ARTIFACT_COVERAGE',
              'scope':'FIRST_PARITY_OUTPUT_INTEGRITY_AND_RANGE_COVERAGE_ONLY',
              'not_certified_here':'absence of omitted first-parity solutions; original Golay nonexistence',
              'p':args.p,'n':2*args.p,'source_sha256':source_hash,'binary_sha256':binary_hash,
              'auditor_sha256':sha(__file__),'domain':[0,total],
              'valid_partition_count':len(partitions),'invalid_receipts':invalid,'duplicate_valid_replays':duplicates,
              'gaps':gaps,'overlaps':overlaps,'statistics':dict(stats),'orientation_count':len(rows),
              'cpu_seconds_selected_partitions':sum(x['cpu_seconds'] for x in partitions),
              'partitions':[{k:v for k,v in x.items() if k!='rows'} for x in partitions]}
    if args.orientations and complete:
        rows.sort(key=lambda x:(x['h'],x['q_bits_mask'],x['t_bits_mask']))
        header = {'record_type':'header','format':'exact_fiber_orientations_v1','n':2*args.p,
                  'h_start':0,'h_end_exclusive':total,'source_sha256':source_hash}
        footer = {'record_type':'footer','status':'COMPLETE_H_DOMAIN','H_completed':total}
        Path(args.orientations).write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in [header,*rows,footer]))
        report['aggregated_orientation_path'] = args.orientations
        report['aggregated_orientation_sha256'] = sha(args.orientations)
    Path(args.output).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','valid_partition_count','gaps','overlaps','orientation_count')}))
    print(json.dumps({'invalid_receipts':invalid}))
    return 0 if complete else 1


if __name__ == '__main__':
    raise SystemExit(main())
