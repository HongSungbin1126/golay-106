"""Independent-reference comparison on dispersed and positive n=106 fibers."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random
import resource
import subprocess
import tempfile
import time

from algebra_orientation_fibers import FiberSolver, parity_output


def main():
    resource.setrlimit(resource.RLIMIT_CPU, (85, 90))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    start = time.process_time()
    project = Path(__file__).resolve().parents[1]
    native = project / 'src/exact_orientation_fibers'
    sample = json.loads((project/'results/algebra_orientation_fibers_n106_sample64.json').read_text())
    assert sample['status'] == 'COMPLETE_SAMPLE'
    assert sample['statistics']['H_examined'] == 64
    hs = sorted(random.Random(20261105).sample(range(1 << 26), 64))
    reference = defaultdict(list)
    for row in sample['solutions']:
        reference[row['h']].append((row['q_bits_mask'], row['t_bits_mask']))
    pilot = []
    for line in (project/'results/exact_fibers_n106_pilot4096.jsonl').read_text().splitlines():
        row = json.loads(line)
        if row['record_type'] == 'orientation':
            pilot.append(row)
    positive_h = sorted({r['h'] for r in pilot})
    solver = FiberSolver(53, start + 75)
    for h in positive_h:
        reference[h] = solver.solve_h(h)
        expected = [(r['q_bits_mask'], r['t_bits_mask']) for r in pilot if r['h'] == h]
        assert sorted(reference[h]) == sorted(expected), ('pilot discrepancy', h)
    all_hs = sorted(set(hs+positive_h))
    records = []
    with tempfile.TemporaryDirectory(prefix='algebra_crosscheck_', dir=project/'results') as td:
        td = Path(td)
        for h in all_hs:
            report, orient = td/'report.json', td/'orientation.jsonl'
            proc = subprocess.run([str(native),'--p','53','--h-start',str(h),
                                   '--h-limit','1','--seconds','2',
                                   '--output',str(report),'--orientations',str(orient)],
                                  capture_output=True,text=True,timeout=5)
            assert proc.returncode == 0, proc.stderr
            rows = [json.loads(line) for line in orient.read_text().splitlines()]
            assert rows[-1]['status'] == 'COMPLETE_H_PARTITION', rows[-1]
            observed = sorted((r['q_bits_mask'],r['t_bits_mask']) for r in rows
                              if r['record_type'] == 'orientation')
            assert observed == sorted(reference[h]), (h, observed, reference[h])
            assert all(parity_output(q,t,53) == 0 for q,t in observed)
            records.append({'h':h,'orientations':observed,'matched':True})
    out = {'status':'PASS','scope':'selected complete first-parity fibers only',
           'random_seed':20261105,'random_fibers':64,'positive_fibers':len(positive_h),
           'distinct_fibers':len(all_hs),'positive_orientations':sum(map(len,reference.values())),
           'native_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),
           'python_source_sha256':hashlib.sha256((project/'src/algebra_orientation_fibers.py').read_bytes()).hexdigest(),
           'cpu_seconds_this_check':time.process_time()-start,
           'prior_sample_cpu_seconds':sample['cpu_seconds'],
           'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
           'checks':records}
    (project/'results/algebra_native_fiber_crosscheck_n106.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in out if k!='checks'},indent=2))


if __name__ == '__main__':
    main()
