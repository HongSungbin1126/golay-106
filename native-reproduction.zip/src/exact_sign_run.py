"""Bounded recorded sign-kernel refinement of explicit first-parity masks."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import subprocess
import tempfile
from verify_independent import verify_pair

ROOT=Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def atomic_install(raw,path):
    """Only finalized bytes enter the shared result directory."""
    with tempfile.NamedTemporaryFile(dir=path.parent,prefix=path.name+'.install_',delete=False) as f:
        stage=Path(f.name)
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    os.replace(stage,path)
    assert hashlib.sha256(raw).hexdigest()==digest(path), 'installed artifact hash mismatch'

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--n',type=int,required=True)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--seconds',type=float,default=60)
    p.add_argument('--max-nullity',type=int,default=24)
    p.add_argument('--s-start',type=int,default=0)
    p.add_argument('--s-limit',type=int,default=0)
    p.add_argument('--tag',default='run1')
    a=p.parse_args()
    source=ROOT/'src/exact_sign_refine.cpp'
    dependency=ROOT/'src/exact_quad_v3.cpp'
    binary=ROOT/'src/exact_sign_refine'
    stem=ROOT/f'results/exact_signs_n{a.n}_{a.tag}'
    output,details,stderr=(stem.with_suffix(x) for x in ('.json','.jsonl','.stderr.log'))
    manifest=stem.with_suffix('.manifest.json')
    if any(path.exists() for path in (output,details,stderr,manifest)):
        raise FileExistsError('result tag already exists; use a new tag to preserve prior evidence')
    input_raw=a.input.read_bytes()
    parsed=[json.loads(line) for line in input_raw.decode().splitlines()]
    assert input_raw.endswith(b'\n') and len(parsed)>=2
    assert parsed[0].get('record_type')=='header' and parsed[-1].get('record_type')=='footer'
    assert parsed[0]['n']==a.n
    assert all(r.get('record_type')=='orientation' and r['n']==a.n for r in parsed[1:-1])
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
        resource.setrlimit(resource.RLIMIT_CPU,(math.ceil(a.seconds)+3,math.ceil(a.seconds)+5))
    hashes=dict(source_sha256=digest(source),dependency_sha256=digest(dependency),binary_sha256=digest(binary),
                input_sha256=hashlib.sha256(input_raw).hexdigest(),wrapper_sha256=digest(Path(__file__)))
    with tempfile.TemporaryDirectory(prefix='golay_exact_sign_') as scratch:
        scratch=Path(scratch)
        local_input,local_output,local_details,local_stderr=(scratch/name for name in ('input.jsonl','report.json','details.jsonl','stderr.log'))
        local_input.write_bytes(input_raw)
        command=[str(binary),'--n',str(a.n),'--seconds',str(a.seconds),
                 '--max-nullity',str(a.max_nullity),'--s-start',str(a.s_start),'--s-limit',str(a.s_limit),
                 '--input',str(local_input),'--output',str(local_output),'--details',str(local_details)]
        provenance=dict(hashes,command=command,input_path=str(a.input.resolve()),
                        input_orientation_count=len(parsed)-2,private_temporary_outputs=True,
                        started_utc=datetime.now(timezone.utc).isoformat())
        atomic_install((json.dumps(provenance,indent=2)+'\n').encode(),manifest)
        with local_stderr.open('w') as err:
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=err,text=True,preexec_fn=limits)
        atomic_install(local_stderr.read_bytes(),stderr)
        if local_details.exists():
            atomic_install(local_details.read_bytes(),details)
        if result.returncode!=0 or not local_output.exists():
            record=dict(provenance,status='EXECUTION_FAILED',returncode=result.returncode,
                        stdout=result.stdout,stderr_path=str(stderr))
            atomic_install((json.dumps(record,indent=2)+'\n').encode(),output)
            raise RuntimeError(f'native sign process failed with return code {result.returncode}')
        record=json.loads(local_output.read_text())
        assert record['input_orientations']==len(parsed)-2
        record.update(provenance,recorded_utc=datetime.now(timezone.utc).isoformat(),
                      details_path=str(details),details_sha256=digest(details),stderr_path=str(stderr))
    if record['status']=='ORIGINAL_PAIR_FOUND':
        record['independent_pair_verification']=verify_pair(record['A'],record['B'],expected_n=a.n)
    atomic_install((json.dumps(record,indent=2)+'\n').encode(),output)
    print(json.dumps(record,indent=2))

if __name__=='__main__':
    main()
