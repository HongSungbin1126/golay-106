#define main exact_quad_reference_main
#include "exact_quad_v3.cpp"
#undef main
#include <map>
#include <sstream>

// Consume explicit (q,t) masks; enumerate the complete second-parity sign
// space up to the stated bounds, then test the original integer equations.
// A complete-input negative result concerns only the listed orientations.
static U json_uint(const std::string& line,const std::string& key) {
    std::size_t pos=line.find("\""+key+"\"");
    if(pos==std::string::npos)throw std::runtime_error("missing field "+key);
    pos=line.find(':',pos)+1;
    return std::stoull(line.substr(pos));
}
int main(int argc,char**argv) {
    int n=0,max_nullity=24;double seconds=60;
    U s_start=0,s_limit=0;
    std::string input,output,details;
    for(int i=1;i<argc;++i) {
        std::string arg=argv[i];
        if(i+1>=argc)return 2;
        if(arg=="--n")n=std::stoi(argv[++i]);
        else if(arg=="--seconds")seconds=std::stod(argv[++i]);
        else if(arg=="--max-nullity")max_nullity=std::stoi(argv[++i]);
        else if(arg=="--s-start")s_start=std::stoull(argv[++i]);
        else if(arg=="--s-limit")s_limit=std::stoull(argv[++i]);
        else if(arg=="--input")input=argv[++i];
        else if(arg=="--output")output=argv[++i];
        else if(arg=="--details")details=argv[++i];
        else return 2;
    }
    if(n<2 || n>126 || n%2 || seconds<=0 || max_nullity<0 || max_nullity>62 || input.empty() || output.empty() || details.empty())return 2;
    std::ifstream in(input);
    if(!in){std::cerr<<"cannot read input\n";return 2;}
    std::vector<std::pair<U,U>> orientations;
    std::string line;
    while(std::getline(in,line))if(line.find("\"orientation\"")!=std::string::npos) {
        if(json_uint(line,"n")!=U(n)){std::cerr<<"n mismatch\n";return 2;}
        orientations.emplace_back(json_uint(line,"q_bits_mask"),json_uint(line,"t_bits_mask"));
    }
    unsigned m=n/2,vars=m-1;
    U half_mask=(U(1)<<m)-1,rhs_bit=U(1)<<vars;
    std::vector<Edge> edges;
    for(unsigned i=0;i<m;++i)for(unsigned j=i+1;j<m;++j) {
        U vm=(i ? U(1)<<(i-1) : 0)^(U(1)<<(j-1));
        edges.push_back({i,j,int(j-i),n-1-int(i+j),vm});
    }
    std::vector<U> rows(n-1);
    std::vector<int> signed_sum(n-1);
    std::ofstream detail(details);
    if(!detail){std::cerr<<"cannot write details\n";return 2;}
    auto wall_start=std::chrono::steady_clock::now();
    std::clock_t cpu_start=std::clock();
    auto cpu=[&](){return double(std::clock()-cpu_start)/CLOCKS_PER_SEC;};
    U signs=0,row_rejects=0,original_tests=0,completed=0,inconsistent=0,skipped=0;
    std::map<unsigned,U> hist;
    bool found=false,timeout=false;
    W wa=0,wb=0;
    for(std::size_t oi=0;oi<orientations.size() && !found && !timeout;++oi) {
        U q=orientations[oi].first,t=orientations[oi].second;
        if((q|t)&~half_mask || (q&1) || (t&1)){std::cerr<<"invalid normalized masks\n";return 3;}
        std::fill(rows.begin(),rows.end(),0);std::fill(signed_sum.begin(),signed_sum.end(),0);
        for(const Edge&e:edges) {
            if(((t>>e.i)^(t>>e.j))&1)continue;
            bool cross=((q>>e.i)^(q>>e.j))&1;
            int lag=cross ? e.cross:e.diff,sg=(cross && ((t>>e.i)&1)) ? -1:1;
            rows[lag-1]^=e.var_mask;signed_sum[lag-1]+=sg;
        }
        for(int k=0;k<n-1;++k) {
            if(signed_sum[k]%2){std::cerr<<"input fails first parity\n";return 3;}
            if((signed_sum[k]/2)%2)rows[k]^=rhs_bit;
        }
        Affine ss=solve_f2(rows,vars);
        detail<<"{\"orientation_index\":"<<oi<<",\"q_bits_mask\":"<<q<<",\"t_bits_mask\":"<<t
              <<",\"sign_system_consistent\":"<<(ss.consistent?"true":"false");
        if(!ss.consistent) {
            ++inconsistent;++completed;detail<<",\"status\":\"SECOND_PARITY_INCONSISTENT\"}\n";continue;
        }
        unsigned nullity=ss.basis.size();++hist[nullity];
        detail<<",\"sign_nullity\":"<<nullity<<",\"sign_particular_bits_mask\":"<<(ss.particular<<1)<<",\"sign_kernel_masks\":[";
        for(unsigned j=0;j<nullity;++j){if(j)detail<<",";detail<<(ss.basis[j]<<1);}
        detail<<"]";
        U total=U(1)<<nullity;
        if(int(nullity)>max_nullity || s_start>=total) {
            ++skipped;detail<<",\"status\":\"NOT_SEARCHED_KERNEL_BOUND\",\"sign_space_size\":"<<total<<"}\n";continue;
        }
        U end=s_limit ? s_start+std::min(s_limit,total-s_start):total;
        U gray=s_start^(s_start>>1),small=ss.particular;
        for(unsigned j=0;j<nullity;++j)if((gray>>j)&1)small^=ss.basis[j];
        U count=0;
        for(U si=s_start;si<end;++si) {
            if(si>s_start)small^=ss.basis[__builtin_ctzll(si)];
            if(!(count&4095) && cpu()>=seconds){timeout=true;break;}
            U u=small<<1;
            W a=W(u)|(W(reverse_bits(u^t,m))<<m);
            W b=W(u^q)|(W(reverse_bits((u^q^t)^half_mask,m))<<m);
            ++signs;++count;
            int sa=n-2*int(pop(a)),sb=n-2*int(pop(b));
            if(sa*sa+sb*sb!=2*n){++row_rejects;continue;}
            ++original_tests;
            bool valid=true;
            for(int k=1;k<n;++k) {
                W mask=(W(1)<<(n-k))-1;
                if(pop((a^(a>>k))&mask)+pop((b^(b>>k))&mask)!=unsigned(n-k)){valid=false;break;}
            }
            if(valid){found=true;wa=a;wb=b;break;}
        }
        bool full=!timeout && !found && s_start==0 && end==total;
        if(full)++completed;
        detail<<",\"sign_space_size\":"<<total<<",\"s_start\":"<<s_start<<",\"s_end_exclusive\":"<<end
              <<",\"sign_assignments_examined\":"<<count<<",\"status\":\""
              <<(found?"ORIGINAL_PAIR_FOUND":timeout?"TIMEOUT":full?"COMPLETE_NO_PAIR":"PARTIAL_SIGN_INTERVAL")<<"\"}\n";
        detail.flush();
    }
    std::string status=found?"ORIGINAL_PAIR_FOUND":timeout?"TIMEOUT":completed==orientations.size()?"COMPLETE_INPUT_NO_PAIR":"INCOMPLETE_INPUT_NO_PAIR_FOUND";
    struct rusage ru{};getrusage(RUSAGE_SELF,&ru);
    detail.close();if(!detail){std::cerr<<"details write failure\n";return 3;}
    std::ofstream out(output);
    if(!out){std::cerr<<"report open failure\n";return 3;}
    out<<"{\n\"solver\":\"exact_sign_refine_v1\",\n\"n\":"<<n<<",\n\"status\":\""<<status
       <<"\",\n\"scope\":\"only input orientations and stated sign ranges; no global Golay nonexistence conclusion\",\n"
       <<"\"certification\":\"SOLVER_REPORT_NOT_INDEPENDENTLY_CERTIFIED\",\n\"input_orientations\":"<<orientations.size()
       <<",\n\"completed_orientations\":"<<completed<<",\n\"second_parity_inconsistent\":"<<inconsistent
       <<",\n\"skipped_kernel_bound\":"<<skipped<<",\n\"sign_assignments_examined\":"<<signs
       <<",\n\"row_norm_rejections\":"<<row_rejects<<",\n\"original_equation_tests\":"<<original_tests
       <<",\n\"sign_nullity_histogram\":{";
    bool first=true;for(const auto&e:hist){if(!first)out<<",";first=false;out<<"\""<<e.first<<"\":"<<e.second;}
    out<<"},\n\"cpu_seconds\":"<<cpu()<<",\n\"wall_seconds\":"
       <<std::chrono::duration<double>(std::chrono::steady_clock::now()-wall_start).count()
       <<",\n\"peak_rss_kib\":"<<ru.ru_maxrss;
    if(found) {
        auto seq=[&](const char* key,W bits){out<<",\n\""<<key<<"\":[";for(int i=0;i<n;++i){if(i)out<<",";out<<(((bits>>i)&1)?-1:1);}out<<"]";};
        seq("A",wa);seq("B",wb);
    }
    out<<"\n}\n";
    out.close();if(!out){std::cerr<<"report write failure\n";return 3;}
    std::cout<<"{\"status\":\""<<status<<"\",\"n\":"<<n<<",\"input_orientations\":"<<orientations.size()
             <<",\"completed_orientations\":"<<completed<<",\"sign_assignments_examined\":"<<signs<<",\"cpu_seconds\":"<<cpu()<<"}\n";
    return 0;
}
