"""Exact CNF encodings; all SAT witnesses are checked in original coordinates.

The quad encoding uses the documented necessary mirror lemma and MODE_P only.
An orientation-only model is a relaxation and is never a Golay certificate.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import resource
import signal
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'third_party/python_packages'))
from pysat.formula import CNF, IDPool
from pysat.card import CardEnc, EncType
from pysat.solvers import Solver
from verify_independent import verify_pair


class Circuit:
    def __init__(self):
        self.pool=IDPool();self.cnf=CNF();self.xors=[]
    def var(self,name=None):return self.pool.id(name)
    def clause(self,*lits):self.cnf.append(list(lits))
    def xor2(self,a,b):
        z=self.var()
        self.cnf.extend([[-a,-b,-z],[a,b,-z],[a,-b,z],[-a,b,z]])
        self.xors.append(([a,b,z],False))
        return z
    def conjunction(self,a,b):
        z=self.var();self.cnf.extend([[-z,a],[-z,b],[z,-a,-b]])
        return z
    def parity(self,lits,value=False):
        if not lits:
            if value:self.cnf.append([])
            return
        z=lits[0]
        for v in lits[1:]:z=self.xor2(z,v)
        self.clause(z if value else -z)
    def cardinality(self,lits,bound,encoding='totalizer'):
        self.cnf.extend(CardEnc.equals(lits=lits,bound=bound,vpool=self.pool,encoding=getattr(EncType,encoding)).clauses)


def build_direct(n,mirror=True,mode='P',encoding='totalizer'):
    if n<1:raise ValueError('positive n')
    c=Circuit();a=[c.var(('A',i)) for i in range(n)];b=[c.var(('B',i)) for i in range(n)]
    for k in range(1,n):
        diffs=[c.xor2(row[i],row[i+k]) for row in (a,b) for i in range(n-k)]
        c.cardinality(diffs,n-k,encoding)
    if mode=='P':
        c.clause(-a[0]);c.clause(-b[0])
        if n>1:c.clause(-a[-1]);c.clause(b[-1])
    elif mode=='R106':
        if n!=106:raise ValueError('R106 requires n106')
        for row,parity,bound in [(a,0,22),(a,1,24),(b,0,22),(b,1,29)]:
            c.cardinality(row[parity::2],bound,encoding)
    elif mode!='none':raise ValueError('unknown normalization')
    if mirror and n%2==0:
        for i in range(n//2):c.parity([a[i],a[n-1-i],b[i],b[n-1-i]],True)
    return c,{'A':a,'B':b,'mode':mode,'model':'direct','n':n}


def build_quad(n,orientation_only=False,encoding='totalizer',redundant_parity=True):
    if n<2 or n%2:raise ValueError('even n>=2')
    m=n//2;c=Circuit()
    q=[c.var(('q',i)) for i in range(m)]
    t=[c.var(('t',i)) for i in range(m)]
    s=[] if orientation_only else [c.var(('s',i)) for i in range(m)]
    c.clause(-q[0]);c.clause(-t[0])
    if s:c.clause(-s[0])
    active=[[] for _ in range(n)]
    positive=[[] for _ in range(n)];negative=[[] for _ in range(n)]
    for i in range(m):
        for j in range(i+1,m):
            dq=c.xor2(q[i],q[j]);dt=c.xor2(t[i],t[j])
            left=c.conjunction(-dq,-dt);cross=c.conjunction(dq,-dt)
            kd=j-i;kx=n-1-i-j
            active[kd].append(left);active[kx].append(cross)
            if not orientation_only:
                ss=c.xor2(s[i],s[j]);sscross=c.xor2(ss,t[i])
                for lag,enable,sgn in [(kd,left,ss),(kx,cross,sscross)]:
                    positive[lag].append(c.conjunction(enable,-sgn))
                    negative[lag].append(c.conjunction(enable,sgn))
    for k in range(1,n):
        if redundant_parity or orientation_only:c.parity(active[k],False)
        if not orientation_only and positive[k]:
            c.cardinality(positive[k]+[-v for v in negative[k]],len(positive[k]),encoding)
    return c,{'q':q,'t':t,'s':s,'mode':'P','model':'orientation' if orientation_only else 'quad','n':n}


def decode(model,meta):
    yes={x for x in model if x>0}
    sg=lambda v:-1 if v in yes else 1
    if meta['model']=='direct':return [sg(x) for x in meta['A']],[sg(x) for x in meta['B']]
    q=[sg(x) for x in meta['q']];t=[sg(x) for x in meta['t']]
    if meta['model']=='orientation':return {'q':q,'t':t}
    s=[sg(x) for x in meta['s']]
    a=s+[x*y for x,y in zip(s,t)][::-1]
    b=[x*y for x,y in zip(s,q)]+[-x*y*z for x,y,z in zip(s,q,t)][::-1]
    return a,b


def run(n,kind,solver,seconds,tag,encoding='totalizer',save_proof=False,mode='P'):
    start=time.monotonic();cpu0=time.process_time()
    c,meta=build_direct(n,mode=mode,encoding=encoding) if kind=='direct' else build_quad(n,orientation_only=kind=='orientation',encoding=encoding)
    build_wall=time.monotonic()-start
    formula=ROOT/'certificates'/f'cnf_{tag}.cnf'
    c.cnf.to_file(str(formula))
    (ROOT/'certificates'/f'cnf_{tag}_map.json').write_text(json.dumps(meta,indent=2)+'\n')
    # Glucose supports timer-driven interrupts; exact elapsed CPU is also recorded.
    with Solver(name=solver,bootstrap_with=c.cnf,with_proof=save_proof) as sat:
        timer=threading.Timer(seconds,sat.interrupt);timer.daemon=True;timer.start()
        try:answer=sat.solve_limited(expect_interrupt=True)
        finally:timer.cancel()
        stats=sat.accum_stats();model=sat.get_model() if answer else None
        proof=sat.get_proof() if answer is False and save_proof else None
    result={'n':n,'encoding':kind,'solver':solver,'cardinality_encoding':encoding,'mode':meta['mode'],'formula_vars':c.cnf.nv,'formula_clauses':len(c.cnf.clauses),'build_wall_seconds':build_wall,'cpu_seconds':time.process_time()-cpu0,'wall_seconds':time.monotonic()-start,'answer':answer,'solver_stats':stats,'formula_sha256':hashlib.sha256(formula.read_bytes()).hexdigest(),'formula_path':str(formula.relative_to(ROOT)),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'allowed_conclusion':'NO_CONCLUSION','proof_check':'NOT_RUN'}
    if answer is True:
        decoded=decode(model,meta)
        if kind=='orientation':
            result['orientation']=decoded;result['allowed_conclusion']='RELAXATION_SAT_ONLY'
        else:
            a,b=decoded;v=verify_pair(a,b,expected_n=n)
            if not v['aperiodic_golay']:
                raise ArithmeticError('SAT encoding produced invalid pair')
            result['verification']=v;result['allowed_conclusion']='EXACT_PAIR_VERIFIED'
            (ROOT/'data/pairs'/f'cnf_{tag}.json').write_text(json.dumps({'n':n,'A':a,'B':b},indent=2)+'\n')
    elif answer is False:
        result['allowed_conclusion']='UNSAT_SOLVER_REPORT_ONLY'
        if proof is not None:
            path=ROOT/'certificates'/f'cnf_{tag}.drup';path.write_text('\n'.join(proof)+'\n')
            result['proof_path']=str(path.relative_to(ROOT));result['proof_lines']=len(proof)
    (ROOT/'results'/f'cnf_{tag}.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,required=True)
    p.add_argument('--kind',choices=['direct','quad','orientation'],default='quad')
    p.add_argument('--solver',default='glucose42');p.add_argument('--seconds',type=float,default=30)
    p.add_argument('--tag',required=True);p.add_argument('--encoding',default='totalizer')
    p.add_argument('--proof',action='store_true');p.add_argument('--mode',default='P')
    a=p.parse_args()
    resource.setrlimit(resource.RLIMIT_AS,(1536*1024**2,1536*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU,(int(a.seconds)+30,int(a.seconds)+35))
    resource.setrlimit(resource.RLIMIT_FSIZE,(200*1024**2,200*1024**2))
    print(json.dumps(run(a.n,a.kind,a.solver,a.seconds,a.tag,a.encoding,a.proof,a.mode),indent=2),flush=True)


if __name__=='__main__':main()
