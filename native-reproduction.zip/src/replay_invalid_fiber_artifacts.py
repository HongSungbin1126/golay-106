"""Recompute bad artifact partitions; preserve the original evidence unchanged.

Child output lives in private /tmp paths until the child has exited. Completed
bytes are copied into the project with atomic replacement. This avoids holding
open output streams under a synchronized project directory. It is an artifact
repair, NOT a mathematically independent algorithmic replay.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import tempfile
import time


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_bytes(path,data):
    path = Path(path)
    fd,tmp = tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def save(path,obj):
    atomic_bytes(path,(json.dumps(obj,indent=2)+'\n').encode())


def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(300,302))
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_FSIZE,(200*1024**2,200*1024**2))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--audit',required=True)
    parser.add_argument('--tag',required=True)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--source',default='src/exact_orientation_fibers_v2.cpp')
    parser.add_argument('--binary',default='src/exact_orientation_fibers_v2')
    args=parser.parse_args()
    if not 1<=args.workers<=4:parser.error('workers must be between1and4')
    audit=json.loads(Path(args.audit).read_text())
    pending=[]
    for bad in audit['invalid_receipts']:
        rec=json.loads(Path(bad['receipt_path']).read_text())
        pending.append((rec['h_start'],rec['h_count'],bad['receipt_path'],bad['reason']))
    pending=sorted(set(pending))
    out=Path('results')/args.tag
    out.mkdir(exist_ok=False)
    source_hash,binary_hash=digest(args.source),digest(args.binary)
    if (source_hash,binary_hash)!=(audit['source_sha256'],audit['binary_sha256']):
        raise ValueError('source or binary differs from audited campaign')
    started=time.monotonic();active=[];completed=[];failed=[]
    with tempfile.TemporaryDirectory(prefix='golay_artifact_replay_') as private:
        private=Path(private)
        while pending or active:
            while pending and len(active)<args.workers:
                h,count,old_receipt,reason=pending.pop(0)
                name=f'h{h:09d}_count{count:09d}'
                report,orientation,logpath=(private/(name+suffix) for suffix in ('.json','.jsonl','.log'))
                command=[str(Path(args.binary).resolve()),'--p',str(audit['p']),'--seconds','290',
                         '--h-start',str(h),'--h-limit',str(count),'--output',str(report),
                         '--orientations',str(orientation),'--source-sha256',source_hash]
                log=logpath.open('w')
                proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
                active.append({'h':h,'count':count,'name':name,'report':report,'orientation':orientation,
                               'logpath':logpath,'log':log,'proc':proc,'command':command,
                               'started':time.monotonic(),'original_receipt':old_receipt,'reason':reason})
            for job in list(active):
                proc=job['proc']
                if proc.poll() is None and time.monotonic()-job['started']>310:
                    proc.terminate()
                    try:proc.wait(timeout=2)
                    except subprocess.TimeoutExpired:proc.kill();proc.wait()
                if proc.poll() is None:continue
                job['log'].close();active.remove(job)
                final_report,final_orientation,final_log=(out/(job['name']+suffix) for suffix in ('.json','.jsonl','.log'))
                for original,target in ((job['report'],final_report),(job['orientation'],final_orientation),(job['logpath'],final_log)):
                    if original.exists():atomic_bytes(target,original.read_bytes())
                report=json.loads(final_report.read_text()) if final_report.exists() else {}
                receipt={'h_start':job['h'],'h_count':job['count'],'command':job['command'],
                         'returncode':proc.returncode,'wall_seconds':time.monotonic()-job['started'],
                         'source_sha256':source_hash,'binary_sha256':binary_hash,
                         'wrapper_sha256':digest(__file__),'report_path':str(final_report),
                         'orientation_path':str(final_orientation),'H_completed':report.get('H_completed',0),
                         'status':report.get('status','NO_REPORT'),'cpu_seconds':report.get('cpu_seconds'),
                         'orientation_sha256':digest(final_orientation) if final_orientation.exists() else None,
                         'replaces_invalid_artifact_receipt':job['original_receipt'],
                         'original_artifact_failure':job['reason'],'private_output_then_atomic_copy':True}
                save(out/(job['name']+'_receipt.json'),receipt)
                good=proc.returncode==0 and report.get('H_completed')==job['count'] and final_orientation.stat().st_size>0
                (completed if good else failed).append(receipt)
                print(json.dumps({'h_start':job['h'],'status':receipt['status'],'artifact_nonempty':good}),flush=True)
            state={'status':'RUNNING' if active or pending else 'COMPLETE_ARTIFACT_REPLAY' if not failed else 'FAILED_ARTIFACT_REPLAY',
                   'source_sha256':source_hash,'binary_sha256':binary_hash,'audit_input_sha256':digest(args.audit),
                   'elapsed_seconds':time.monotonic()-started,'completed_partitions':completed,'failed_partitions':failed,
                   'pending_count':len(pending),'active_count':len(active)}
            save(out/'campaign_state.json',state)
            if pending or active:time.sleep(1)
    return 0 if not failed else 1


if __name__=='__main__':
    raise SystemExit(main())
