"""Bounded CryptoMiniSat experiment with explicit native XOR redundancy.
Only exact original-coordinate SAT witnesses are accepted as Golay pairs.
"""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'third_party/python_packages'))
import pycryptosat
from cnf_golay import build_quad,decode
from verify_independent import verify_pair


def main():
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,required=True)
    p.add_argument('--kind',choices=['orientation','quad'],default='orientation')
    p.add_argument('--seconds',type=float,default=60);p.add_argument('--tag',required=True)
    a=p.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU,(int(a.seconds)+30,int(a.seconds)+35))
    resource.setrlimit(resource.RLIMIT_AS,(1536*1024**2,1536*1024**2))
    before=time.process_time();start=time.monotonic()
    sources={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in ['src/native_xor_search.py','src/cnf_golay.py','src/verify_independent.py']}
    c,meta=build_quad(a.n,orientation_only=a.kind=='orientation')
    cnf_path=ROOT/'certificates'/f'cms_{a.tag}.cnf';c.cnf.to_file(str(cnf_path))
    solver=pycryptosat.Solver(threads=1,time_limit=a.seconds,options={'maxmatrixrows':'20000'})
    for cl in c.cnf.clauses:solver.add_clause(cl)
    for lits,rhs in c.xors:
        positive=[]
        for lit in lits:
            if lit<0:rhs=not rhs
            positive.append(abs(lit))
        solver.add_xor_clause(positive,rhs)
    answer,assignment=solver.solve(time_limit=a.seconds)
    result={'n':a.n,'kind':a.kind,'solver':'pycryptosat5.17.0','threads':1,'source_sha256':sources,'formula_vars':c.cnf.nv,'formula_clauses':len(c.cnf.clauses),'native_xor_rows':len(c.xors),'answer':answer,'cpu_seconds':time.process_time()-before,'wall_seconds':time.monotonic()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'allowed_conclusion':'NO_CONCLUSION','proof_check':'NO_PROOF_LOG'}
    if answer:
        model=[i if val else -i for i,val in enumerate(assignment) if i]
        value=decode(model,meta)
        if a.kind=='orientation':
            result['orientation']=value;result['allowed_conclusion']='RELAXATION_SAT_ONLY'
        else:
            aa,bb=value;v=verify_pair(aa,bb,expected_n=a.n)
            if not v['aperiodic_golay']:raise ArithmeticError('invalid SAT witness')
            result['verification']=v;result['allowed_conclusion']='EXACT_PAIR_VERIFIED'
            (ROOT/'data/pairs'/f'cms_{a.tag}.json').write_text(json.dumps({'n':a.n,'A':aa,'B':bb},indent=2)+'\n')
    elif answer is False:result['allowed_conclusion']='UNSAT_SOLVER_REPORT_ONLY'
    (ROOT/'results'/f'cms_{a.tag}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':main()
