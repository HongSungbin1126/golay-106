"""Portable bounded primary replay, with private child outputs and strict audit.

Recommended for NEW reproductions. The original campaign and its artifact
repairs remain unchanged as historical evidence. This driver invokes the same
frozen native mathematical engine; it adds no mathematical pruning rule.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import tempfile
import time

from audit_fiber_campaign import audit_partition
from replay_invalid_fiber_artifacts import atomic_bytes, save


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(1000,1002))
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_FSIZE,(200*1024**2,200*1024**2))


def live_cpu(pid):
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        return (int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')
    except (FileNotFoundError,ProcessLookupError,PermissionError):return 0.0


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--p',type=int,default=53)
    p.add_argument('--tag',required=True)
    p.add_argument('--h-start',type=int,default=0)
    p.add_argument('--h-count',type=int,default=1<<25)
    p.add_argument('--chunk-size',type=int,default=1<<20)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--cpu-budget',type=float,default=7200)
    p.add_argument('--wall-seconds',type=float,default=1100)
    a=p.parse_args()
    if not (3<=a.p<=63 and a.p&1 and 1<=a.workers<=4 and a.chunk_size>0 and 0<a.wall_seconds<=1180 and a.cpu_budget>0):
        p.error('invalid target or resource limits')
    root=Path(__file__).resolve().parents[1];os.chdir(root)
    total=1<<((a.p-1)//2);end=a.h_start+a.h_count
    if not 0<=a.h_start<end<=total:p.error('invalid exact H interval')
    folder=Path('results')/a.tag;folder.mkdir(exist_ok=False)
    source=Path('src/exact_orientation_fibers_v2.cpp')
    binary=Path('src/exact_orientation_fibers_v2')
    source_hash,binary_hash=sha(source),sha(binary)
    configuration={'p':a.p,'n':2*a.p,'requested_h_range':[a.h_start,end],
                   'source_sha256':source_hash,'binary_sha256':binary_hash,
                   'controller_sha256':sha(__file__),
                   'audit_dependency_sha256':sha('src/audit_fiber_campaign.py'),
                   'transfer_dependency_sha256':sha('src/replay_invalid_fiber_artifacts.py'),
                   'workers':a.workers,'cpu_budget':a.cpu_budget,'wall_seconds':a.wall_seconds,
                   'started_utc':datetime.now(timezone.utc).isoformat(),
                   'scope':'FIRST_PARITY_ONLY; no original Golay conclusion'}
    save(folder/'configuration.json',configuration)
    pending=[(h,min(a.chunk_size,end-h)) for h in range(a.h_start,end,a.chunk_size)]
    active=[];completed=[];failed=[];stop=False
    start=time.monotonic();initial=resource.getrusage(resource.RUSAGE_CHILDREN)
    with tempfile.TemporaryDirectory(prefix='golay_primary_campaign_') as private:
        private=Path(private)
        while pending or active:
            usage=resource.getrusage(resource.RUSAGE_CHILDREN)
            cpu=usage.ru_utime+usage.ru_stime-initial.ru_utime-initial.ru_stime
            stop|=cpu+sum(live_cpu(j['proc'].pid) for j in active)>=a.cpu_budget or time.monotonic()-start>=a.wall_seconds
            while pending and len(active)<a.workers and not stop:
                h,count=pending.pop(0);name=f'h{h:09d}_count{count:09d}'
                report,orientation,logpath=(private/(name+ext) for ext in ('.json','.jsonl','.log'))
                command=[str(binary.resolve()),'--p',str(a.p),'--seconds','990','--h-start',str(h),'--h-limit',str(count),
                         '--output',str(report),'--orientations',str(orientation),'--source-sha256',source_hash]
                log=logpath.open('w');proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
                active.append({'proc':proc,'h':h,'count':count,'name':name,'report':report,'orientation':orientation,
                               'logpath':logpath,'log':log,'command':command,'started':time.monotonic()})
            for job in list(active):
                proc=job['proc']
                if proc.poll() is None and (stop or time.monotonic()-job['started']>1010):
                    proc.terminate()
                    try:proc.wait(timeout=2)
                    except subprocess.TimeoutExpired:proc.kill();proc.wait()
                if proc.poll() is None:continue
                job['log'].close();active.remove(job)
                outputs={}
                for key,ext in (('report','.json'),('orientation','.jsonl'),('logpath','.log')):
                    path=folder/(job['name']+ext);outputs[key]=path
                    if job[key].exists():atomic_bytes(path,job[key].read_bytes())
                report=json.loads(outputs['report'].read_text()) if outputs['report'].exists() else {}
                receipt={'h_start':job['h'],'h_count':job['count'],'command':job['command'],'returncode':proc.returncode,
                         'source_sha256':source_hash,'binary_sha256':binary_hash,'controller_sha256':configuration['controller_sha256'],
                         'report_path':str(outputs['report']),'orientation_path':str(outputs['orientation']),
                         'H_completed':report.get('H_completed',0),'status':report.get('status','NO_REPORT'),
                         'cpu_seconds':report.get('cpu_seconds'),'wall_seconds':time.monotonic()-job['started'],
                         'orientation_sha256':sha(outputs['orientation']) if outputs['orientation'].exists() else None}
                receipt_path=folder/(job['name']+'_receipt.json');save(receipt_path,receipt)
                try:
                    audit_partition(receipt_path,source_hash,binary_hash,a.p)
                    if sha(source)!=source_hash or sha(binary)!=binary_hash:raise ValueError('executable changed')
                    completed.append(receipt)
                except (ValueError,KeyError,OSError) as exc:
                    failed.append({**receipt,'audit_failure':str(exc)});stop=True
                print(json.dumps({'h_start':job['h'],'H_completed':receipt['H_completed'],'status':receipt['status']}),flush=True)
            usage=resource.getrusage(resource.RUSAGE_CHILDREN)
            cpu=usage.ru_utime+usage.ru_stime-initial.ru_utime-initial.ru_stime
            state={'status':'STOPPED_INCOMPLETE' if stop else 'RUNNING' if pending or active else 'REQUESTED_H_RANGE_COMPLETE',
                   'requested_h_range':[a.h_start,end],'completed_partitions':completed,'failed_partitions':failed,
                   'active_count':len(active),'pending_ranges':pending,'elapsed_wall_seconds':time.monotonic()-start,
                   'completed_child_cpu_seconds':cpu}
            save(folder/'campaign_state.json',state)
            if stop and not active:break
            if pending or active:time.sleep(1)
    return 0 if not stop and not failed else 1


if __name__=='__main__':raise SystemExit(main())
