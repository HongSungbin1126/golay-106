#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <string>
#include <sys/resource.h>
#include <vector>

// Exact enumeration of binary APERIODIC Golay pairs using the necessary
// mirror identity.  This is a complete finite solver when its entire q range
// completes.  An UNSAT return is a solver report until independently checked.
// Every returned witness is checked against the ORIGINAL integer equations.
using U = std::uint64_t;
using W = unsigned __int128;

struct Affine {
    bool consistent = true;
    U particular = 0;
    std::vector<U> basis;
    unsigned rank = 0;
};

static Affine solve_f2(const std::vector<U>& rows, unsigned vars) {
    Affine out;
    std::array<U, 63> pivot{};
    U mask = vars ? ((U(1) << vars) - 1) : 0;
    for (U r : rows) {
        while (r & mask) {
            unsigned p = __builtin_ctzll(r & mask);
            if (pivot[p]) r ^= pivot[p];
            else { pivot[p] = r; ++out.rank; break; }
        }
        if (!(r & mask) && ((r >> vars) & 1)) {
            out.consistent = false;
            return out;
        }
    }
    for (int p = int(vars)-1; p >= 0; --p) if (pivot[p]) {
        unsigned value = unsigned((pivot[p] >> vars) & 1)
                       ^ unsigned(__builtin_parityll(pivot[p] & out.particular & mask));
        if (value) out.particular |= U(1) << p;
    }
    for (unsigned f = 0; f < vars; ++f) if (!pivot[f]) {
        U b = U(1) << f;
        for (int p = int(vars)-1; p >= 0; --p) if (pivot[p]) {
            if (__builtin_parityll(pivot[p] & b & mask)) b |= U(1) << p;
        }
        out.basis.push_back(b);
    }
    return out;
}

static U reverse_bits(U x, unsigned m) {
    x = ((x & 0x5555555555555555ULL) << 1) | ((x >> 1) & 0x5555555555555555ULL);
    x = ((x & 0x3333333333333333ULL) << 2) | ((x >> 2) & 0x3333333333333333ULL);
    x = ((x & 0x0f0f0f0f0f0f0f0fULL) << 4) | ((x >> 4) & 0x0f0f0f0f0f0f0f0fULL);
    x = __builtin_bswap64(x);
    return x >> (64-m);
}

static unsigned pop(W x) {
    return __builtin_popcountll(U(x)) + __builtin_popcountll(U(x >> 64));
}

struct Edge { unsigned i, j; int diff, cross; U var_mask; };

int main(int argc, char** argv) {
    int n = 0; double seconds = 30; U q_start = 0, q_limit = 0;
    std::string orientation_path, source_sha256;
    for (int i=1; i<argc; ++i) {
        std::string a=argv[i];
        if (i+1 >= argc) { std::cerr << "missing value\n"; return 2; }
        if (a=="--n") n=std::stoi(argv[++i]);
        else if (a=="--seconds") seconds=std::stod(argv[++i]);
        else if (a=="--q-start") q_start=std::stoull(argv[++i]);
        else if (a=="--q-limit") q_limit=std::stoull(argv[++i]);
        else if (a=="--orientation-output") orientation_path=argv[++i];
        else if (a=="--source-sha256") source_sha256=argv[++i];
        else { std::cerr << "unknown argument\n"; return 2; }
    }
    if (n < 2 || n > 126 || n % 2 || seconds <= 0) {
        std::cerr << "requires an even 2 <= n <= 126 and positive CPU limit\n"; return 2;
    }
    const unsigned m=unsigned(n/2), vars=m-1;
    const U total_q=U(1)<<vars, half_mask=(U(1)<<m)-1;
    if (q_start >= total_q) { std::cerr << "q-start out of range\n"; return 2; }
    U q_end = q_limit ? q_start+std::min(q_limit,total_q-q_start) : total_q;
    std::ofstream orientation_out;
    if (!orientation_path.empty()) {
        orientation_out.open(orientation_path, std::ios::out | std::ios::trunc);
        if (!orientation_out) { std::cerr << "cannot open orientation output\n"; return 2; }
        orientation_out << "{\"record_type\":\"header\",\"format\":\"exact_orientation_v1\",\"n\":"
          << n << ",\"q_start\":" << q_start << ",\"q_end_exclusive\":" << q_end
          << ",\"q_enumeration\":\"binary_reflected_gray\""
          << ",\"source_sha256\":\"" << source_sha256 << "\"}\n";
        orientation_out.flush();
    }
    const U rhs_bit=U(1)<<vars;
    const auto wall_start=std::chrono::steady_clock::now();
    const std::clock_t cpu_start=std::clock();
    auto cpu = [&](){ return double(std::clock()-cpu_start)/CLOCKS_PER_SEC; };
    std::vector<Edge> edges;
    for (unsigned i=0; i<m; ++i) for (unsigned j=i+1; j<m; ++j) {
        U vm=(i ? U(1)<<(i-1) : 0) ^ (U(1)<<(j-1));
        edges.push_back({i,j,int(j-i),n-1-int(i+j),vm});
    }
    std::vector<U> rows(unsigned(n-1));
    // The first-stage augmented matrix is affine in the q bits.  Changing one
    // q bit exchanges each incident edge's diff/cross lag, so its delta is
    // independent of the other q bits.  This is the classical Gray-code update.
    std::vector<U> t_rows(unsigned(n-1), 0);
    std::vector<std::vector<U>> q_delta(vars, std::vector<U>(unsigned(n-1),0));
    for (const auto& e : edges) {
        U value=e.var_mask ^ rhs_bit;
        t_rows[e.diff-1] ^= value;
        for (unsigned i : {e.i,e.j}) if(i) {
            q_delta[i-1][e.diff-1] ^= value;
            q_delta[i-1][e.cross-1] ^= value;
        }
    }
    U initial_gray=q_start^(q_start>>1);
    for (unsigned i=0;i<vars;++i) if((initial_gray>>i)&1) {
        for(int k=0;k<n-1;++k)t_rows[k]^=q_delta[i][k];
    }
    std::vector<int> edge_lags(edges.size()), sign_sum(unsigned(n-1));
    std::array<U,63> t_null_hist{}, s_null_hist{};
    U q_done=0, q_consistent=0, t_examined=0, t_consistent=0;
    U sign_assignments=0, row_norm_rejections=0, exact_tests=0, events=0;
    bool found=false, timed_out=false;
    W wa=0, wb=0;
    auto check_budget=[&](){
        if ((++events & 1023)==0 && cpu() >= seconds) { timed_out=true; return false; }
        return true;
    };
    auto valid_original=[&](U q, U t, U u) {
        U rev_a=reverse_bits(u^t,m);
        U left_b=u^q, rev_b=reverse_bits((u^q^t)^half_mask,m);
        W a=W(u)|(W(rev_a)<<m), b=W(left_b)|(W(rev_b)<<m);
        int sa=n-2*int(pop(a)), sb=n-2*int(pop(b));
        if (sa*sa+sb*sb != 2*n) { ++row_norm_rejections; return false; }
        ++exact_tests;
        for (int k=1; k<n; ++k) {
            W mask=(W(1)<<(n-k))-1;
            unsigned h=pop((a^(a>>k))&mask)+pop((b^(b>>k))&mask);
            if (h != unsigned(n-k)) return false;
        }
        wa=a; wb=b; return true;
    };

    for (U qi=q_start; qi<q_end && !found && !timed_out; ++qi) {
        if (!check_budget()) break;
        if (qi && !(qi & ((U(1)<<22)-1))) {
            std::cerr << "{\"progress_q\":" << qi << ",\"cpu_seconds\":" << cpu()
                      << ",\"feasible_orientations\":" << t_examined << "}\n";
        }
        if(qi>q_start) {
            unsigned changed=__builtin_ctzll(qi);
            for(int k=0;k<n-1;++k)t_rows[k]^=q_delta[changed][k];
        }
        U q=(qi^(qi>>1))<<1; // q_0=+1; qi indexes a complete Gray traversal.
        Affine ts=solve_f2(t_rows,vars);
        if (!ts.consistent) { ++q_done; continue; }
        for (std::size_t z=0; z<edges.size(); ++z) {
            const auto& e=edges[z];
            edge_lags[z]=(((q>>e.i)^(q>>e.j))&1) ? e.cross : e.diff;
        }
        ++q_consistent; ++t_null_hist[ts.basis.size()];
        U t_small=ts.particular, t_total=U(1)<<ts.basis.size();
        for (U ti=0; ti<t_total && !found && !timed_out; ++ti) {
            if (ti) t_small ^= ts.basis[__builtin_ctzll(ti)];
            if (!check_budget()) break;
            U t=t_small<<1;
            ++t_examined;
            std::fill(rows.begin(),rows.end(),0);
            std::fill(sign_sum.begin(),sign_sum.end(),0);
            for (std::size_t z=0; z<edges.size(); ++z) {
                const auto& e=edges[z];
                if (((t>>e.i)^(t>>e.j))&1) continue;
                int lag=edge_lags[z];
                int sg=(lag==e.cross && ((t>>e.i)&1)) ? -1 : 1;
                rows[lag-1] ^= e.var_mask;
                sign_sum[lag-1] += sg;
            }
            for (int k=1; k<n; ++k) {
                if (sign_sum[k-1]%2) {
                    std::cerr << "internal error: odd active edge parity\n"; return 3;
                }
                if ((sign_sum[k-1]/2)%2) rows[k-1] ^= rhs_bit;
            }
            Affine ss=solve_f2(rows,vars);
            if (orientation_out) {
                orientation_out << "{\"record_type\":\"orientation\",\"n\":" << n
                  << ",\"q_index\":" << qi << ",\"q_bits_mask\":" << q
                  << ",\"t_bits_mask\":" << t
                  << ",\"sign_system_consistent\":" << (ss.consistent?"true":"false");
                if (ss.consistent) {
                    orientation_out << ",\"sign_particular_bits_mask\":" << (ss.particular<<1)
                      << ",\"sign_kernel_masks\":[";
                    for (std::size_t j=0;j<ss.basis.size();++j) {
                        if(j) orientation_out << ",";
                        orientation_out << (ss.basis[j]<<1);
                    }
                    orientation_out << "]";
                }
                orientation_out << "}\n";
                orientation_out.flush();
            }
            if (!ss.consistent) continue;
            ++t_consistent; ++s_null_hist[ss.basis.size()];
            U u_small=ss.particular, u_total=U(1)<<ss.basis.size();
            for (U ui=0; ui<u_total; ++ui) {
                if (ui) u_small ^= ss.basis[__builtin_ctzll(ui)];
                if (!check_budget()) break;
                ++sign_assignments;
                if (valid_original(q,t,u_small<<1)) { found=true; break; }
            }
        }
        if (!found && !timed_out) ++q_done;
    }
    double cpu_seconds=cpu();
    double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-wall_start).count();
    struct rusage ru{}; getrusage(RUSAGE_SELF,&ru);
    std::string result=found ? "SAT" : timed_out ? "TIMEOUT" :
        ((q_start==0 && q_end==total_q) ? "UNSAT" : "PARTITION_UNSAT");
    if (orientation_out) {
        orientation_out << "{\"record_type\":\"footer\",\"solver_report\":\"" << result
          << "\",\"q_completed\":" << q_done << ",\"feasible_orientations\":"
          << t_examined << "}\n";
    }
    std::cout << "{\n  \"solver\":\"exact_quad_f2_v3\",\n  \"n\":" << n
      << ",\n  \"q_enumeration\":\"binary_reflected_gray\""
      << ",\n  \"normalization\":\"MODE_P\",\n  \"solver_report\":\"" << result
      << "\",\n  \"certification\":\"NOT_INDEPENDENTLY_CERTIFIED\",\n"
      << "  \"q_start\":" << q_start << ",\n  \"q_end_exclusive\":" << q_end
      << ",\n  \"total_q_domain\":" << total_q << ",\n  \"q_completed\":" << q_done
      << ",\n  \"q_with_consistent_t_system\":" << q_consistent
      << ",\n  \"t_assignments_examined\":" << t_examined
      << ",\n  \"t_with_consistent_s_system\":" << t_consistent
      << ",\n  \"sign_assignments_examined\":" << sign_assignments
      << ",\n  \"row_norm_rejections\":" << row_norm_rejections
      << ",\n  \"original_equation_tests\":" << exact_tests
      << ",\n  \"cpu_seconds\":" << cpu_seconds
      << ",\n  \"wall_seconds\":" << wall
      << ",\n  \"max_rss_kib\":" << ru.ru_maxrss << ",\n";
    auto hist=[&](const char* key,const auto& h){
        std::cout << "  \"" << key << "\":{"; bool first=true;
        for(unsigned i=0;i<h.size();++i) if(h[i]) {
            if(!first)std::cout<<",";
            first=false;
            std::cout<<"\""<<i<<"\":"<<h[i];
        }
        std::cout << "},\n";
    };
    hist("t_nullity_histogram",t_null_hist); hist("s_nullity_histogram",s_null_hist);
    auto seq=[&](const char* key,W bits){
        std::cout << "  \""<<key<<"\":[";
        for(int i=0;i<n;++i){if(i)std::cout<<",";std::cout<<(((bits>>i)&1)?-1:1);}
        std::cout << "]";
    };
    if(found) {seq("A",wa);std::cout<<",\n";seq("B",wb);std::cout<<"\n";}
    else std::cout << "  \"A\":null,\n  \"B\":null\n";
    std::cout << "}\n";
    return 0;
}
