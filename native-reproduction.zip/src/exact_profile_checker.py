"""Independent, direct-integer check of a full finite profile certificate.

Completeness argument: replacing a sequence by its negative preserves every
aperiodic autocorrelation, hence each sequence may have its first entry +1.
The tail masks enumerate ALL such sequences exactly once.  Two sequences form
a Golay pair iff their complete correlation profiles are componentwise opposites.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path


def check(path):
    begin = time.process_time()
    raw = Path(path).read_bytes()
    obj = json.loads(raw)
    if obj.get("format") != "golay_exact_profile_v1":
        raise ValueError("unrecognized certificate format")
    n = obj.get("n")
    if type(n) is not int or not 1 <= n <= 20:
        raise ValueError("invalid or unsupported certificate length")
    if obj.get("claim") != "NO_BINARY_APERIODIC_PAIR_AT_THIS_LENGTH":
        raise ValueError("not an UNSAT certificate")
    rows = obj.get("profiles_in_tail_order")
    if not isinstance(rows, list) or len(rows) != 2**(n-1):
        raise ValueError("missing enumeration rows")
    actual = set()
    for mask, submitted in enumerate(rows):
        a = [1]
        for j in range(n-1):
            a.append(-1 if mask & (2**j) else 1)
        expected = []
        for distance in range(1, n):
            value = 0
            for left in range(n-distance):
                value += a[left]*a[left+distance]
            expected.append(value)
        if (not isinstance(submitted, list) or
            any(type(v) is not int for v in submitted) or submitted != expected):
            raise ValueError(f"incorrect correlation profile at tail mask {mask}")
        actual.add(tuple(expected))
    for p in actual:
        if tuple(-v for v in p) in actual:
            raise ValueError("opposite profiles exist: this length is NOT certified negative")
    return {"checker": "direct_profile_checker_v1", "result": "PASS",
            "n": n, "sequences_covered": len(rows), "unique_profiles": len(actual),
            "claim": "FIXED_LENGTH_NONEXISTENCE_CERTIFIED",
            "target_conjecture_status": "STILL_OPEN",
            "certificate_sha256": hashlib.sha256(raw).hexdigest(),
            "cpu_seconds": time.process_time()-begin}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("certificate", type=Path)
    args = ap.parse_args()
    print(json.dumps(check(args.certificate), indent=2))
