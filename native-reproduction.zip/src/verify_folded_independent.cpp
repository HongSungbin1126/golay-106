// Independent complete first-parity replay for n=2p, odd 3<=p<=63.
// Mathematical specification: proof/algebra_orientation_fibers.md, Appendix A.
// This file does not include or copy the native solver implementation.
// Differences: Q/U coordinates; multiplication-matrix inverse by row RREF;
// explicit affine consequences; scalar ANF-row elimination; reflection/popcount
// parity evaluator. Every residual quadratic equation is retained; if affine
// extraction stalls, both branches are searched. This is NOT a full Golay solver.
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <sys/resource.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace independent_folded {
using Word = std::uint64_t;
using Wide = unsigned __int128;

static Word low_bits(unsigned n) {
    if (n > 63) throw std::logic_error("invalid low-bit width");
    return (Word(1) << n) - 1;
}

// Byte-table reflection is distinct from the native bit-swap implementation.
static Word reverse_bits(Word value, unsigned width) {
    static const std::array<unsigned char, 256> table = [] {
        std::array<unsigned char, 256> a{};
        for (unsigned i = 0; i != 256; ++i) {
            unsigned x = i, y = 0;
            for (unsigned b = 0; b != 8; ++b) { y = 2*y + (x & 1); x >>= 1; }
            a[i] = static_cast<unsigned char>(y);
        }
        return a;
    }();
    if (!width || width > 63) throw std::logic_error("invalid reflection width");
    Word result = 0;
    for (unsigned b = 0; b != 8; ++b) {
        result = (result << 8) | table[value & 255];
        value >>= 8;
    }
    return result >> (64-width);
}

struct Point {
    Word q = 0, u = 0;  // u = q XOR t, in coefficient-bit notation.
};
static Point add(Point a, Point b) { return {a.q ^ b.q, a.u ^ b.u}; }
static Point combination(Word selector, const std::vector<Point>& directions) {
    Point result;
    for (unsigned j = 0; selector; ++j, selector >>= 1)
        if (selector & 1) result = add(result, directions[j]);
    return result;
}

struct AffineSolution {
    bool consistent = true;
    unsigned rank = 0;
    Word particular = 0;
    std::vector<Word> kernel;
};

// Scalar equation rows: low d bits are coefficients, bit d is the RHS.
// Full reduced row echelon form; no native column-preimage routine is reused.
static AffineSolution row_solve(std::vector<Word> rows, unsigned d) {
    if (d > 62) throw std::logic_error("affine dimension exceeds supported width");
    const Word coefficient_mask = low_bits(d);
    for (Word row : rows)
        if (row >> (d+1)) throw std::logic_error("bits beyond augmented row width");
    std::vector<unsigned> pivots;
    unsigned r = 0;
    for (unsigned col = 0; col < d; ++col) {
        unsigned chosen = r;
        while (chosen < rows.size() && !((rows[chosen] >> col) & 1)) ++chosen;
        if (chosen == rows.size()) continue;
        std::swap(rows[r], rows[chosen]);
        for (unsigned j = 0; j < rows.size(); ++j)
            if (j != r && ((rows[j] >> col) & 1)) rows[j] ^= rows[r];
        pivots.push_back(col);
        ++r;
    }
    AffineSolution result;
    result.rank = r;
    for (Word row : rows) {
        if (!(row & coefficient_mask) && ((row >> d) & 1)) {
            result.consistent = false;
            return result;
        }
    }
    std::vector<bool> pivot_column(d, false);
    for (unsigned j = 0; j < r; ++j) {
        pivot_column[pivots[j]] = true;
        if ((rows[j] >> d) & 1) result.particular |= Word(1) << pivots[j];
    }
    for (unsigned free_col = 0; free_col < d; ++free_col) {
        if (pivot_column[free_col]) continue;
        Word vector = Word(1) << free_col;
        for (unsigned j = 0; j < r; ++j)
            if ((rows[j] >> free_col) & 1) vector |= Word(1) << pivots[j];
        result.kernel.push_back(vector);
    }
    return result;
}

// Multiplication modulo J_p, using only bit shifts and XOR, for exact checks.
static Word ring_multiply(Word a, Word b, unsigned p) {
    const unsigned degree = p-1;
    const Word J = low_bits(p);
    if ((a >> degree) & 1) a ^= J;
    if ((b >> degree) & 1) b ^= J;
    Word result = 0;
    for (unsigned j = 0; j < degree; ++j) {
        if ((b >> j) & 1) result ^= a;
        a <<= 1;
        if ((a >> degree) & 1) a ^= J;
    }
    return result;
}

// Solve multiplication-by-H times inverse = 1 as a scalar row system.
// In a finite commutative quotient ring a right inverse is a unit inverse.
static bool inverse_by_rows(Word H, unsigned p, Word& inverse) {
    const unsigned d = p-1;
    const Word J = low_bits(p);
    Word column = H;
    if ((column >> d) & 1) column ^= J;
    std::vector<Word> rows(d, 0);
    for (unsigned j = 0; j < d; ++j) {
        Word remaining = column;
        while (remaining) {
            const unsigned i = __builtin_ctzll(remaining);
            rows[i] |= Word(1) << j;
            remaining &= remaining-1;
        }
        column <<= 1;
        if ((column >> d) & 1) column ^= J;
    }
    rows[0] |= Word(1) << d;
    AffineSolution solved = row_solve(std::move(rows), d);
    if (!solved.consistent) return false;
    if (!solved.kernel.empty())
        throw std::logic_error("inverse equation consistent but multiplication not bijective");
    inverse = solved.particular;
    if (ring_multiply(H, inverse, p) != 1)
        throw std::logic_error("row inverse failed independent ring-product check");
    return true;
}

class ParityEvaluator {
    struct CrossTerm { Word mask; unsigned amount; bool left; Wide lag_bit; };
    unsigned p_;
    std::vector<Word> same_masks_;
    std::vector<CrossTerm> cross_terms_;
public:
    explicit ParityEvaluator(unsigned p): p_(p), same_masks_(p) {
        for (unsigned k = 1; k < p; ++k) same_masks_[k] = low_bits(p-k);
        // Each sum s counts only i<j, once. Reflection aligns q_(s-i) at i.
        for (unsigned s = 1; s <= 2*p-3; ++s) {
            const unsigned begin = s >= p ? s-p+1 : 0;
            const unsigned end = (s-1)/2 + 1;
            if (end <= begin) continue;
            const Word mask = low_bits(end) ^ low_bits(begin);
            const bool left = s > p-1;
            const unsigned amount = left ? s-(p-1) : (p-1)-s;
            cross_terms_.push_back({mask, amount, left, Wide(1) << (2*p-2-s)});
        }
    }
    Wide operator()(Point a) const {
        const Word q = a.q, t = a.q ^ a.u;
        Wide result = 0;
        for (unsigned k = 1; k < p_; ++k) {
            const Word eligible = ~(q ^ (q >> k)) & ~(t ^ (t >> k)) & same_masks_[k];
            if (__builtin_parityll(eligible)) result ^= Wide(1) << (k-1);
        }
        const Word rq = reverse_bits(q, p_), rt = reverse_bits(t, p_);
        for (const CrossTerm& c : cross_terms_) {
            const Word aligned_q = c.left ? rq << c.amount : rq >> c.amount;
            const Word aligned_t = c.left ? rt << c.amount : rt >> c.amount;
            const Word eligible = (q ^ aligned_q) & ~(t ^ aligned_t) & c.mask;
            if (__builtin_parityll(eligible)) result ^= c.lag_bit;
        }
        return result;
    }
    Wide literal(Point a) const {
        Wide result = 0;
        Word t = a.q ^ a.u;
        for (unsigned i = 0; i < p_; ++i) for (unsigned j = i+1; j < p_; ++j) {
            if (((t >> i) & 1) != ((t >> j) & 1)) continue;
            unsigned lag = ((a.q >> i) & 1) == ((a.q >> j) & 1)
                         ? j-i : 2*p_-1-i-j;
            result ^= Wide(1) << (lag-1);
        }
        return result;
    }
};

struct Timeout : public std::exception {};
struct Statistics {
    Word h_examined = 0, unit_h = 0, nonunit_h = 0;
    Word parity_evaluations = 0, affine_nodes = 0, affine_reductions = 0;
    Word initial_inconsistent = 0, residual_inconsistent = 0, branch_nodes = 0;
    Word free_spaces = 0, solutions = 0;
};

// A scalar ANF equation row, with up to choose(62,2)=1891 nonlinear columns.
struct AnfRow {
    std::array<Word, 30> quadratic{};
    Word affine = 0;
};
struct LinearConsequences {
    std::vector<Word> rows;
    unsigned quadratic_rank = 0;
};

// Eliminate nonlinear monomial columns by elementary ROW operations.
// All rows that reduce to no nonlinear monomials yield affine consequences.
static LinearConsequences remove_nonlinear(std::vector<AnfRow> equations,
                                          unsigned monomials) {
    const unsigned words = (monomials + 63)/64;
    std::vector<int> pivot_owner(monomials, -1);
    std::vector<AnfRow> pivot_rows;
    LinearConsequences result;
    for (AnfRow row : equations) {
        while (true) {
            unsigned word = 0;
            while (word < words && !row.quadratic[word]) ++word;
            if (word == words) { result.rows.push_back(row.affine); break; }
            const unsigned pivot = 64*word + __builtin_ctzll(row.quadratic[word]);
            if (pivot_owner[pivot] < 0) {
                pivot_owner[pivot] = static_cast<int>(pivot_rows.size());
                pivot_rows.push_back(row);
                ++result.quadratic_rank;
                break;
            }
            const AnfRow& old = pivot_rows[pivot_owner[pivot]];
            for (unsigned w = word; w < words; ++w) row.quadratic[w] ^= old.quadratic[w];
            row.affine ^= old.affine;
        }
    }
    return result;
}

class Solver {
    friend struct SolverTestAccess;
    unsigned p_, m_;
    double cpu_limit_, wall_limit_;
    std::clock_t cpu_start_ = std::clock();
    std::chrono::steady_clock::time_point wall_start_ = std::chrono::steady_clock::now();
    ParityEvaluator parity_;
    std::vector<Point> original_directions_;

    Wide evaluate(Point point) {
        ++stats.parity_evaluations;
        if (!(stats.parity_evaluations & 63)) check_time();
        return parity_(point);
    }
    static void restrict_affine(Point& base, std::vector<Point>& directions,
                                const AffineSolution& solution) {
        base = add(base, combination(solution.particular, directions));
        std::vector<Point> next;
        next.reserve(solution.kernel.size());
        for (Word kernel : solution.kernel) next.push_back(combination(kernel, directions));
        directions = std::move(next);
    }
    void accept(Point point) {
        if ((point.q | point.u) & 1)
            throw std::logic_error("normalization failed on emitted point");
        if (parity_.literal(point))
            throw std::logic_error("emitted point failed literal edge parity");
        solutions.push_back(point);
        ++stats.solutions;
    }

    void solve_space(Point base, std::vector<Point> directions) {
        ++stats.affine_nodes;
        while (true) {
            check_time();
            const unsigned d = static_cast<unsigned>(directions.size());
            const Wide constant = evaluate(base);
            if (!d) {
                if (!constant) accept(base);
                return;
            }
            std::vector<Wide> linear(d);
            for (unsigned i = 0; i < d; ++i)
                linear[i] = evaluate(add(base, directions[i])) ^ constant;
            const unsigned monomials = d*(d-1)/2;
            const unsigned outputs = 2*p_-1;
            std::vector<AnfRow> rows(outputs);
            for (unsigned k = 0; k < outputs; ++k) {
                Word affine = ((constant >> k) & 1) ? Word(1) << d : 0;
                for (unsigned i = 0; i < d; ++i)
                    if ((linear[i] >> k) & 1) affine |= Word(1) << i;
                rows[k].affine = affine;
            }
            unsigned position = 0;
            for (unsigned i = 0; i < d; ++i) for (unsigned j = i+1; j < d; ++j) {
                Wide mixed = evaluate(add(add(base, directions[i]), directions[j]))
                           ^ linear[i] ^ linear[j] ^ constant;
                Word lower = static_cast<Word>(mixed);
                while (lower) {
                    unsigned k = __builtin_ctzll(lower);
                    rows[k].quadratic[position/64] |= Word(1) << (position%64);
                    lower &= lower-1;
                }
                Word upper = static_cast<Word>(mixed >> 64);
                while (upper) {
                    unsigned k = 64 + __builtin_ctzll(upper);
                    rows[k].quadratic[position/64] |= Word(1) << (position%64);
                    upper &= upper-1;
                }
                ++position;
            }
            LinearConsequences extracted = remove_nonlinear(std::move(rows), monomials);
            AffineSolution solution = row_solve(std::move(extracted.rows), d);
            const std::string stage = std::to_string(d) + "/"
                                    + std::to_string(extracted.quadratic_rank) + "/"
                                    + (solution.consistent ? std::to_string(solution.kernel.size())
                                                           : "INCONSISTENT");
            ++stage_histogram[stage];
            if (!solution.consistent) { ++stats.residual_inconsistent; return; }
            if (solution.kernel.size() < d) {
                restrict_affine(base, directions, solution);
                ++stats.affine_reductions;
                continue;
            }
            if (!extracted.quadratic_rank) {
                if (constant) throw std::logic_error("affine identity has nonzero constant");
                for (Wide c : linear)
                    if (c) throw std::logic_error("affine identity has nonzero linear part");
                ++stats.free_spaces;
                for (Word assignment = 0; assignment < (Word(1) << d); ++assignment) {
                    if (!(assignment & 1023)) check_time();
                    Point point = add(base, combination(assignment, directions));
                    if (evaluate(point)) throw std::logic_error("free space failed full parity");
                    accept(point);
                }
                return;
            }
            // No rank or nullity pattern is assumed. Both children are necessary.
            ++stats.branch_nodes;
            Point split = directions.back();
            directions.pop_back();
            solve_space(base, directions);
            solve_space(add(base, split), directions);
            return;
        }
    }

public:
    Statistics stats;
    std::map<std::string, Word> stage_histogram;
    std::vector<Point> solutions;
    Solver(unsigned p, double seconds, double wall_seconds)
        : p_(p), m_((p-1)/2), cpu_limit_(seconds), wall_limit_(wall_seconds), parity_(p) {
        for (unsigned block = 0; block < 2; ++block) {
            for (unsigned i = 1; i <= m_; ++i) {
                Word v = Word(1) << i;
                if (i != m_) v |= Word(1) << (p_-1-i);
                original_directions_.push_back(block == 0 ? Point{v, 0} : Point{0, v});
            }
        }
    }
    double cpu() const { return double(std::clock()-cpu_start_) / CLOCKS_PER_SEC; }
    double wall() const {
        return std::chrono::duration<double>(std::chrono::steady_clock::now()-wall_start_).count();
    }
    void check_time() const { if (cpu() >= cpu_limit_ || wall() >= wall_limit_) throw Timeout{}; }

    // Analytic derivative columns of F_k+F_(2p-k), k=1,...,p-1.
    // Low-bit masks are coefficient vectors for these p-1 scalar equations.
    std::vector<Word> initial_columns(Word H, Word G) const {
        const Word J = low_bits(p_);
        std::vector<Word> columns;
        columns.reserve(p_-1);
        for (Word X : {G, H}) {
            for (unsigned i = 1; i <= m_; ++i) {
                Wide V;
                if (i == m_) V = Wide(X) << m_;
                else {
                    const Word reduced = X ^ (((X >> i) & 1) ? J : 0);
                    V = (Wide(reduced) << i) ^ (Wide(reduced) << (p_-1-i));
                }
                columns.push_back(static_cast<Word>((V >> p_) ^ V) & low_bits(p_-1));
            }
        }
        return columns;
    }

    void solve_h(Word h) {
        check_time();
        if (h >= (Word(1) << m_)) throw std::logic_error("H index out of domain");
        solutions.clear();
        ++stats.h_examined;
        const Word J = low_bits(p_);
        const Word H = h | reverse_bits(h, p_);
        Word inverse = 0;
        if (!inverse_by_rows(H, p_, inverse)) {
            if (p_ == 53 && h != 0)
                throw std::logic_error("unexpected nonunit in irreducible p=53 quotient");
            ++stats.nonunit_h;
            return;
        }
        ++stats.unit_h;
        Word G = (inverse >> 1) ^ ((inverse & 1) ? (J >> 1) : 0);
        if ((G >> m_) & 1) G ^= J;
        if (reverse_bits(G, p_) != G || ((G >> m_) & 1))
            throw std::logic_error("inverse partner is not middle-zero palindromic");
        if (ring_multiply(2, ring_multiply(H, G, p_), p_) != 1)
            throw std::logic_error("folded inverse identity failed");

        Point base{H & ~low_bits(m_+1), G & ~low_bits(m_+1)};
        const Wide f0 = evaluate(base);
        // F_p is constant on this fiber. Test it instead of assuming trace facts.
        if ((f0 >> (p_-1)) & 1) { ++stats.initial_inconsistent; return; }
        const std::vector<Word> columns = initial_columns(H, G);
        const unsigned d = p_-1;
        std::vector<Word> rows(d, 0);
        for (unsigned k = 1; k < p_; ++k) {
            const bool rhs = ((f0 >> (k-1)) ^ (f0 >> (2*p_-k-1))) & 1;
            if (rhs) rows[k-1] |= Word(1) << d;
            for (unsigned i = 0; i < d; ++i)
                if ((columns[i] >> (k-1)) & 1) rows[k-1] |= Word(1) << i;
        }
        AffineSolution initial = row_solve(std::move(rows), d);
        ++stage_histogram["initial/" + std::to_string(d) + "/"
                          + (initial.consistent ? std::to_string(initial.kernel.size()) : "INCONSISTENT")];
        if (!initial.consistent) { ++stats.initial_inconsistent; return; }
        std::vector<Point> directions = original_directions_;
        restrict_affine(base, directions, initial);
        solve_space(base, std::move(directions));
        for (Point point : solutions) {
            if ((point.q ^ reverse_bits(point.q, p_)) != H
                || (point.u ^ reverse_bits(point.u, p_)) != G)
                throw std::logic_error("emitted point is outside declared folded fiber");
        }
    }
};

// Keep long-lived output descriptors outside the synchronized project tree.
// Copy only a closed complete or explicitly partial file, then rename atomically.
class AtomicText {
    std::string destination_, temporary_;
    bool closed_ = false, committed_ = false;
public:
    std::ofstream stream;
    explicit AtomicText(std::string destination): destination_(std::move(destination)) {
        char path[] = "/tmp/golay_independent_XXXXXX";
        const int fd = mkstemp(path);
        if (fd < 0) throw std::runtime_error("cannot create independent temporary output");
        close(fd);
        temporary_ = path;
        stream.open(temporary_, std::ios::out | std::ios::trunc);
        if (!stream) throw std::runtime_error("cannot open independent temporary output");
    }
    AtomicText(const AtomicText&) = delete;
    AtomicText& operator=(const AtomicText&) = delete;
    ~AtomicText() {
        if (stream.is_open()) stream.close();
        if (committed_) std::remove(temporary_.c_str());
        // On failure retain the /tmp file as recovery evidence.
    }
    void commit() {
        stream.flush();
        if (!stream) throw std::runtime_error("independent output flush failure");
        stream.close();
        closed_ = true;
        if (!stream || !std::filesystem::file_size(temporary_))
            throw std::runtime_error("independent output close or size failure");
        const std::string staging = destination_ + ".publish." + std::to_string(getpid());
        std::filesystem::copy_file(temporary_, staging, std::filesystem::copy_options::overwrite_existing);
        if (std::filesystem::file_size(staging) != std::filesystem::file_size(temporary_))
            throw std::runtime_error("independent publication size mismatch");
        std::filesystem::rename(staging, destination_);
        committed_ = true;
    }
};

static void write_statistics(std::ostream& out, const Statistics& s) {
    out << "{\"H_examined\":" << s.h_examined << ",\"unit_H\":" << s.unit_h
        << ",\"nonunit_H\":" << s.nonunit_h << ",\"parity_evaluations\":" << s.parity_evaluations
        << ",\"affine_nodes\":" << s.affine_nodes << ",\"affine_reductions\":" << s.affine_reductions
        << ",\"initial_inconsistent\":" << s.initial_inconsistent
        << ",\"residual_inconsistent\":" << s.residual_inconsistent
        << ",\"branch_nodes\":" << s.branch_nodes << ",\"free_spaces\":" << s.free_spaces
        << ",\"solutions_including_uncommitted_fiber\":" << s.solutions << "}";
}
static void write_histogram(std::ostream& out, const std::map<std::string, Word>& values) {
    out << "{";
    bool first = true;
    for (const auto& item : values) {
        if (!first) out << ",";
        first = false;
        out << "\"" << item.first << "\":" << item.second;
    }
    out << "}";
}

static Word parse_word(const std::string& value) {
    if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos)
        throw std::invalid_argument("nondecimal unsigned argument");
    std::size_t end = 0;
    Word result = std::stoull(value, &end);
    if (end != value.size()) throw std::invalid_argument("trailing unsigned argument data");
    return result;
}
static double parse_seconds(const std::string& value) {
    std::size_t end = 0;
    double result = std::stod(value, &end);
    if (end != value.size() || !std::isfinite(result) || result <= 0 || result > 1180)
        throw std::invalid_argument("seconds must be finite, positive, and <=1180");
    return result;
}

int run_main(int argc, char** argv) {
    unsigned p = 0;
    Word h_start = 0, h_limit = 0;
    double seconds = 60, wall_seconds = 1180;
    std::string output_path, orientation_path, source_hash;
    for (int i = 1; i < argc; ++i) {
        std::string key = argv[i];
        if (i+1 >= argc) throw std::invalid_argument("missing option value");
        const std::string value = argv[++i];
        if (key == "--p") {
            Word read_p = parse_word(value);
            if (read_p > 63) throw std::invalid_argument("p exceeds width");
            p = static_cast<unsigned>(read_p);
        } else if (key == "--h-start") h_start = parse_word(value);
        else if (key == "--h-limit") h_limit = parse_word(value);
        else if (key == "--seconds") seconds = parse_seconds(value);
        else if (key == "--wall-seconds") wall_seconds = parse_seconds(value);
        else if (key == "--output") output_path = value;
        else if (key == "--orientations") orientation_path = value;
        else if (key == "--source-sha256") source_hash = value;
        else throw std::invalid_argument("unknown argument: " + key);
    }
    if (p < 3 || p > 63 || !(p & 1) || output_path.empty() || orientation_path.empty()
        || output_path == orientation_path)
        throw std::invalid_argument("odd 3<=p<=63 and distinct report/orientation paths required");
    if (source_hash.size() != 64 || source_hash.find_first_not_of("0123456789abcdef") != std::string::npos)
        throw std::invalid_argument("source SHA256 is required");
    const Word total = Word(1) << ((p-1)/2);
    if (h_start >= total) throw std::invalid_argument("H start outside domain");
    const Word end = h_limit ? h_start + std::min(h_limit, total-h_start) : total;
    struct rlimit memory{rlim_t(1) << 30, rlim_t(1) << 30};
    if (setrlimit(RLIMIT_AS, &memory)) throw std::runtime_error("cannot enforce memory limit");
    struct rlimit cpu_limit{rlim_t(std::ceil(seconds))+3, rlim_t(std::ceil(seconds))+5};
    if (setrlimit(RLIMIT_CPU, &cpu_limit)) throw std::runtime_error("cannot enforce CPU limit");
    AtomicText orientations(orientation_path);
    orientations.stream << "{\"record_type\":\"header\",\"format\":\"independent_folded_orientations_v1\","
        << "\"scope\":\"first quad parity only\",\"p\":" << p << ",\"n\":" << 2*p
        << ",\"h_start\":" << h_start << ",\"h_end_exclusive\":" << end
        << ",\"source_sha256\":\"" << source_hash << "\"}\n";
    if (!orientations.stream) throw std::runtime_error("header write failed");
    Solver solver(p, seconds, wall_seconds);
    Word completed = 0, written = 0;
    bool timed_out = false;
    try {
        for (Word h = h_start; h < end; ++h) {
            solver.solve_h(h);
            for (Point point : solver.solutions) {
                orientations.stream << "{\"record_type\":\"orientation\",\"n\":" << 2*p
                    << ",\"h\":" << h << ",\"q_bits_mask\":" << point.q
                    << ",\"t_bits_mask\":" << (point.q ^ point.u) << "}\n";
                ++written;
            }
            if (!orientations.stream) throw std::runtime_error("orientation write failed");
            ++completed;
            if (!(completed & 4095))
                std::cerr << "{\"H_completed\":" << completed << ",\"cpu_seconds\":" << solver.cpu()
                          << ",\"written_orientations\":" << written << "}\n";
        }
    } catch (const Timeout&) { timed_out = true; }
    const std::string status = timed_out ? "TIMEOUT"
                              : (h_start == 0 && end == total ? "COMPLETE_H_DOMAIN" : "COMPLETE_H_PARTITION");
    orientations.stream << "{\"record_type\":\"footer\",\"status\":\"" << status
        << "\",\"h_start\":" << h_start << ",\"covered_end_exclusive\":" << h_start+completed
        << ",\"H_completed\":" << completed << ",\"orientation_records\":" << written << "}\n";
    orientations.commit();
    AtomicText report(output_path);
    struct rusage usage{};
    getrusage(RUSAGE_SELF, &usage);
    report.stream << "{\n\"solver\":\"independent_row_rref_QU_reflection_v1\",\n"
        << "\"scope\":\"first quad parity only; sign and original integer conditions remain\",\n"
        << "\"certification\":\"INDEPENDENT_IMPLEMENTATION_REPORT_NOT_FORMAL_KERNEL_PROOF\",\n"
        << "\"status\":\"" << status << "\",\n\"p\":" << p << ",\n\"n\":" << 2*p
        << ",\n\"total_H_domain\":" << total << ",\n\"h_start\":" << h_start
        << ",\n\"h_end_exclusive\":" << end << ",\n\"covered_end_exclusive\":" << h_start+completed
        << ",\n\"H_completed\":" << completed << ",\n\"orientation_records\":" << written
        << ",\n\"statistics\":";
    write_statistics(report.stream, solver.stats);
    report.stream << ",\n\"stage_histogram\":";
    write_histogram(report.stream, solver.stage_histogram);
    report.stream << ",\n\"cpu_seconds\":" << solver.cpu() << ",\n\"wall_seconds\":" << solver.wall()
        << ",\n\"peak_rss_kib\":" << usage.ru_maxrss
        << ",\n\"source_sha256\":\"" << source_hash << "\"\n}\n";
    report.commit();
    std::cout << "{\"status\":\"" << status << "\",\"H_completed\":" << completed
              << ",\"orientation_records\":" << written << ",\"cpu_seconds\":" << solver.cpu() << "}\n";
    return timed_out ? 4 : 0;
}
} // namespace independent_folded

#ifndef GOLAY_VERIFY_NO_MAIN
int main(int argc, char** argv) {
    try { return independent_folded::run_main(argc, argv); }
    catch (const std::exception& error) {
        std::cerr << "independent replay rejected: " << error.what() << "\n";
        return 2;
    }
}
#endif
