# Golay length 106: accepted-result reproducibility archive

Prepared 2026-11-05 for the paper **A computer-assisted nonexistence proof for binary Golay pairs of length 106**, SUNGBIN HONG.

This is a curated reproducibility archive, not the complete original private research bundle. It preserves the accepted mathematical sources, exact native sources, original campaigns, output records, sign certificates, and literal witnesses. Private research instructions, agent handoff files, original prompts/conversations, irrelevant SAT proof dumps, and third-party paper PDFs are not released. The original bundle's manifest is retained as `ORIGINAL_BUNDLE_MANIFEST.sha256` for provenance only. Some entries refer to intentionally omitted files; use the new `PUBLIC_MANIFEST.sha256` to verify this curated tree. The archive is not a formal proof of the entire result and does not establish priority or human peer review.

## Mathematical scope

For two ordered binary rows of length106, every positive-lag residual is the original integer non-wrapping sum

`r_k = sum(i=0..105-k) (a_i*a_(i+k) + b_i*b_(i+k))`.

The computer-assisted claim is no pair with every `r_k` divisible by64. Its corollary is nonexistence of an ordinary binary aperiodic Golay pair. It does not address periodic/complex pairs, other lengths, global energy optimality, or the general length conjecture. Publication priority is not established.

## Quick checks

Python3.10+ standard library is sufficient for the accepted checks. Do not run with `-O` or `-OO`; assertions are essential. `-B` avoids creating pycache. On ordinary installations, `-E` may additionally ignore Python environment overrides. It must not be used with a launcher that relies on PYTHONHOME.

From this archive root:

```sh
python3 -B src/audit_fiber_campaign.py \
  --campaign results/campaign_n106_first_parity \
  --campaign results/campaign_n106_artifact_replay \
  --output /tmp/golay-primary-recheck.json

python3 -B src/audit_independent_campaign.py \
  --output /tmp/golay-independent-recheck.json

python3 -B tests/exact_sign_space_audit.py \
  --n 106 \
  --orientations results/campaign_n106_first_parity_orientations.jsonl \
  --details results/exact_signs_n106_campaign_full_signs.jsonl \
  --summary results/exact_signs_n106_campaign_full_signs.json \
  --output /tmp/golay-sign-spaces-recheck.json

python3 -B src/exact_sign_character_certificate_check.py \
  --n 106 \
  --spaces results/exact_signs_n106_campaign_kernel_inventory.jsonl \
  --certificate results/algebra_sign_character_reductions.json \
  --affine-audit /tmp/golay-sign-spaces-recheck.json \
  --mod32-witnesses results/algebra_mod32_witnesses.json \
  --output /tmp/golay-characters-recheck.json
```

Expected: 64 accepted historical primary partitions; 64 complete independent partitions; all67,108,864 H indices covered; exact equality of the102 orientations;102 sign systems audited,94 inconsistent and8 complete affine spaces;8 checked character certificates;8 normalized modulo32 witnesses,64 raw orbit members. The ten damaged historical primary receipts are preserved and rejected, with their intervals covered by separate valid replacement records.

Quick archive audits inspect recorded ranges, hashes and output sets. They do not rerun all67million fibers or formally prove that an implementation omitted no solutions. The mathematical completeness argument and reviewed sources remain essential. The compact character checker proves only the supplied sign tail and explicitly does not establish global first-stage completeness.

## Important libc++ portability correction

The frozen primary source has an overload-name defect under Apple Clang/libc++: its initial call `remainder(U,U)` can select a floating mathematical overload instead of its polynomial helper. A negative result converted to unsigned128 is undefined behavior. The first Mac replay was rejected because it returned33,554,433 nonunits and42outputs, contradicting the one-nonunit requirement. It is preserved, not used as exclusion evidence.

For libc++/macOS use the separate corrected source in `preparation-validation/portable_source/`, which renames the helper to `poly_remainder`. An optional guarded AArch64 PMULL variant has exact-product regression tests. Read `preparation-validation/PORTABILITY_FINDING.md`; the corrected full result is accepted only if its strict final audit passes. Historical Linux/GCC sources, binaries and hashes are not rewritten. The algebra and independent matrix-based implementation are not replaced by this portability fix.

## Full native replay

Keep this evidence tree unchanged. Rebuild in a fresh copy. The historical source paths contain archived executables, and some wrappers/finalizers overwrite them or reports. Never run `src/finalize_research_claims.py` as a read-only check: it writes CLAIMS and final acceptance metadata.

`REPRODUCE.md` and `REPRODUCE_INDEPENDENT.md` document the historical Linux/GCC route, its unit/calibration checks, two half-domain campaigns, controller and watchdog. The accepted result does not need the Python SAT packages used by separate early experiments. The native code uses C++17 plus compiler/POSIX facilities; the full supervised controllers use Linux `/proc`. Supplied executables are Linux x86-64 ELF files, not native macOS programs. The native carryless arithmetic has an exact portable fallback.

`preparation-validation/`, when present, contains additional separate preparation checks and a fresh Apple-Clang arm64 primary replay. Consult its reports for actual completeness and scope; no timeout is a negative mathematical result. The exact-zero direct sign replay does not by itself establish the stronger modulo64 classification.

## Integrity and provenance

`CLAIMS.json` and the original release metadata are historical internal links. They do not authenticate a public timestamp or git history. The original git commit cannot be reconstructed from a bundle without `.git`. New public manifests identify exact released bytes, rather than pretending omitted private files were included.

The human contributor selected the problem and directed the research. Research and text were primarily AI-generated; no part is claimed to have been checked and understood by a human. Author-reported tools: ChatGPT (Chat), GPT-6 Pro, research; Gemini3.1 Pro, internal review; ChatGPT (Aside), GPT-6.1 Sol Max, internal review/material preparation. AI reviews are not human or external peer review. Private conversations are not included.

License: CC BY4.0, as far as applicable rights are held. See `LICENSE.md`.
